import { o as __toESM } from "./_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { a as Route$10 } from "./_ssr/router-CiLk3dI1.mjs";
import { n as Shell, o as getBusiness } from "./_ssr/shell-Dr3dYE06.mjs";
import { t as formatArs } from "./_ssr/money-DSc2EJ_o.mjs";
import { t as MarketMap } from "./_ssr/market-map-Be73bcVO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_businessId-Dg8dDiga.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BusinessPage() {
	const { businessId } = Route$10.useParams();
	const [business, setBusiness] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		getBusiness({ data: businessId }).then(setBusiness).catch((cause) => setError(cause instanceof Error ? cause.message : "No se encontró."));
	}, [businessId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error }) : null, business ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 md:grid-cols-[1fr_18rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					business.neighborhood,
					" · ",
					business.city,
					business.isDemo ? " · ejemplo de desarrollo" : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl",
				children: business.tradeName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: business.description || business.legalName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm",
				children: business.verified ? "Verificado por la plataforma" : "Todavía no verificado"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 grid gap-2",
				children: business.listings.map((listing) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between rounded-2xl border border-line px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/producto/$productId",
						params: { productId: listing.id },
						children: [listing.name, listing.brand ? ` · ${listing.brand}` : ""]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums",
						children: [
							formatArs(listing.priceCents),
							" / ",
							listing.unit
						]
					})]
				}, listing.id))
			})
		] }), business.lat !== null && business.lng !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-hidden rounded-card border border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketMap, {
				points: [{
					id: business.id,
					lat: business.lat,
					lng: business.lng,
					label: business.tradeName
				}],
				selectedId: business.id,
				onSelect: () => void 0
			})
		}) : null]
	}) : null] });
}
//#endregion
export { BusinessPage as component };
