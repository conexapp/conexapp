import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as Check, _ as Package, m as Search, t as X } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-BS1-Yv7g.mjs";
import { a as createSsrRpc, c as getMyAccount, h as useCurrentUserState, i as createBusiness, n as Shell, p as setBusinessLocation, t as RedirectToSignIn } from "./shell-Dr3dYE06.mjs";
import { n as parseArsToCents } from "./money-DSc2EJ_o.mjs";
import { t as ROSARIO } from "./geo-CF53TDu_.mjs";
import { f as submitQuote, l as listQuoteInbox } from "./trade-C_IUkqNG.mjs";
import { a as searchSellerTaxonomy, i as otherRoots, n as childrenOf, r as featuredTaxa } from "./seller-categories-Drkd9i-e.mjs";
import { i as glyph } from "./category-visual-G9mqIc48.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/panel-BdOuHa_1.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var listSellerTaxonomy = createServerFn({ method: "GET" }).handler(createSsrRpc("fb57c938a0d920117e6ee0ac48d85231042b7fdd76b1a234d4bca9335ee74d28"));
var setBusinessCategories = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.businessId) throw new Error("Falta el negocio.");
	if (!Array.isArray(input.categoryIds)) throw new Error("Elegí al menos una categoría.");
	return {
		businessId: input.businessId,
		categoryIds: input.categoryIds
	};
}).handler(createSsrRpc("bd7739e16b93213b4c6fe07b3805872e6830adf60597d48ed0b98b00a024120e"));
function SellerCategoryPicker({ selected, onChange, title = "¿Qué tipo de productos vendés?", hint = "Seleccioná una o varias categorías que representen los productos que ofrecés." }) {
	const titleId = (0, import_react.useId)();
	const [categories, setCategories] = (0, import_react.useState)([]);
	const [limit, setLimit] = (0, import_react.useState)(10);
	const [otherOpen, setOtherOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		listSellerTaxonomy().then((result) => {
			if (cancelled) return;
			setCategories(result.categories);
			setLimit(result.limit);
		}).catch(() => {
			if (!cancelled) setError("No se pudo cargar el catálogo de categorías.");
		});
		return () => {
			cancelled = true;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!otherOpen) return;
		function onKey(event) {
			if (event.key === "Escape") setOtherOpen(false);
		}
		document.addEventListener("keydown", onKey);
		return () => document.removeEventListener("keydown", onKey);
	}, [otherOpen]);
	function toggle(id) {
		if (selected.includes(id)) {
			onChange(selected.filter((item) => item !== id));
			setNotice(null);
			return;
		}
		if (selected.length >= limit) {
			setNotice(`Podés elegir hasta ${limit} categorías. Ese tope se cambia en la configuración de la plataforma.`);
			return;
		}
		setNotice(null);
		onChange([...selected, id]);
	}
	const featured = featuredTaxa(categories);
	const extras = otherRoots(categories);
	const hits = searchSellerTaxonomy(categories, query);
	const byId = new Map(categories.map((category) => [category.id, category]));
	const featuredIds = new Set(featured.map((category) => category.id));
	const otherSelected = selected.some((id) => !featuredIds.has(id));
	const atLimit = selected.length >= limit;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: hint
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm font-medium text-ink",
					children: [
						selected.length,
						" de ",
						limit
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Elegir un rubro no te impide publicar un producto de otro."
				})
			] }),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-2xl bg-sun/40 px-3 py-2 text-sm",
				children: error
			}) : null,
			categories.length === 0 && !error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-card" }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
				children: [featured.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryChoice, {
					category,
					selected: selected.includes(category.id),
					disabled: atLimit,
					onToggle: toggle
				}, category.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					"aria-pressed": otherOpen || otherSelected,
					onClick: () => setOtherOpen(true),
					className: `min-h-24 rounded-2xl border px-3 py-3 text-left ${otherSelected ? "border-teal bg-teal/10" : "border-line bg-card"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
							className: "size-5 text-olive",
							"aria-hidden": true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-2 flex items-start gap-1 text-sm font-semibold",
							children: [otherSelected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
								className: "mt-0.5 size-4 shrink-0 text-olive",
								"aria-hidden": true
							}) : null, "Otro"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block text-xs text-muted",
							children: "Buscar el resto del catálogo"
						})
					]
				})]
			}),
			selected.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-wrap gap-2",
				children: selected.map((id) => {
					const category = byId.get(id);
					const parent = category?.parentId ? byId.get(category.parentId) : void 0;
					const label = parent ? `${parent.name} → ${category?.name ?? id}` : category?.name ?? id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggle(id),
						className: "inline-flex min-h-11 items-center gap-2 rounded-full bg-sun px-3 text-sm font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-4",
							"aria-hidden": true
						}), label]
					}) }, id);
				})
			}) : null,
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: notice
			}) : null,
			otherOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 flex items-end justify-center bg-ink/40 sm:items-center sm:p-4",
				onClick: () => setOtherOpen(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "dialog",
					"aria-modal": "true",
					"aria-labelledby": titleId,
					className: "flex max-h-[92vh] w-full max-w-lg flex-col rounded-t-3xl bg-foam shadow-card sm:rounded-3xl",
					onClick: (event) => event.stopPropagation(),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3 border-b border-line px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								id: titleId,
								className: "text-lg font-semibold",
								children: "Buscá qué vendés"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "También encuentra subcategorías de las 10 principales."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setOtherOpen(false),
								className: "inline-flex size-11 items-center justify-center rounded-full hover:bg-paper",
								"aria-label": "Cerrar",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
									className: "size-5",
									"aria-hidden": true
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 items-center gap-2 rounded-full border border-line bg-card px-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									className: "size-4 text-teal",
									"aria-hidden": true
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									autoFocus: true,
									value: query,
									onChange: (event) => setQuery(event.target.value),
									placeholder: "Buscar categoría...",
									className: "min-w-0 flex-1 bg-transparent text-sm outline-none"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-h-0 flex-1 overflow-y-auto px-4 pb-3",
							children: query.trim().length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "grid gap-1",
								children: [hits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
									className: "py-6 text-center text-sm text-muted",
									children: "No hay categorías con ese texto."
								}) : null, hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceRow, {
									title: hit.parentName ? `${hit.parentName} → ${hit.name}` : hit.name,
									selected: selected.includes(hit.id),
									disabled: atLimit && !selected.includes(hit.id),
									onClick: () => toggle(hit.id)
								}) }, hit.id))]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-4",
								children: extras.map((root) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceRow, {
									title: root.name,
									selected: selected.includes(root.id),
									disabled: atLimit && !selected.includes(root.id),
									onClick: () => toggle(root.id)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-1 grid gap-1 pl-3",
									children: childrenOf(categories, root.id).map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceRow, {
										title: child.name,
										selected: selected.includes(child.id),
										disabled: atLimit && !selected.includes(child.id),
										onClick: () => toggle(child.id)
									}) }, child.id))
								})] }, root.id))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-t border-line p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setOtherOpen(false),
								className: "min-h-11 w-full rounded-full bg-ink text-sm font-semibold text-paper",
								children: "Listo"
							})
						})
					]
				})
			}) : null
		]
	});
}
function CategoryChoice({ category, selected, disabled, onToggle }) {
	const Icon = glyph(category.icon) ?? Package;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		"aria-pressed": selected,
		disabled: !selected && disabled,
		onClick: () => onToggle(category.id),
		className: `min-h-24 rounded-2xl border px-3 py-3 text-left disabled:opacity-50 ${selected ? "border-teal bg-teal/10" : "border-line bg-card"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5 text-olive",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mt-2 flex items-start gap-1 text-sm font-semibold",
			children: [selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: "mt-0.5 size-4 shrink-0 text-olive",
				"aria-hidden": true
			}) : null, category.name]
		})]
	});
}
function ChoiceRow({ title, selected, disabled, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled,
		"aria-pressed": selected,
		onClick,
		className: `flex min-h-11 w-full items-center justify-between gap-3 rounded-xl px-3 text-left text-sm disabled:opacity-50 ${selected ? "bg-sun" : "hover:bg-paper"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-medium",
			children: title
		}), selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
			className: "size-4 shrink-0",
			"aria-hidden": true
		}) : null]
	});
}
var listSellerPaymentLinks = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("663296a7af27f2e27ab0e04cfa55730d2c4211e61d501c3e03d2fc1803f1c988"));
var startSellerOAuth = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((businessId) => {
	if (typeof businessId !== "string" || businessId.length < 8 || businessId.length > 80) throw new Error("Negocio inválido.");
	return businessId;
}).handler(createSsrRpc("39a5a0011edbb27ec30d1bf8886eb2192cdd3d27c983825d9f110addab244344"));
var disconnectSellerPayments = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((businessId) => {
	if (typeof businessId !== "string" || businessId.length < 8) throw new Error("Negocio inválido.");
	return businessId;
}).handler(createSsrRpc("062d79fba039d0d8d6fd0cc73135f06f8f65615339c3467c57ca4b5f47f4d84a"));
function PanelPage() {
	const { user, isPending } = useCurrentUserState();
	const [account, setAccount] = (0, import_react.useState)(null);
	const [inbox, setInbox] = (0, import_react.useState)([]);
	const [payments, setPayments] = (0, import_react.useState)(null);
	const [tradeName, setTradeName] = (0, import_react.useState)("");
	const [legalName, setLegalName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [address, setAddress] = (0, import_react.useState)("");
	const [neighborhood, setNeighborhood] = (0, import_react.useState)("");
	const [categoryIds, setCategoryIds] = (0, import_react.useState)([]);
	const [editIds, setEditIds] = (0, import_react.useState)([]);
	const [businessId, setBusinessId] = (0, import_react.useState)("");
	const [lat, setLat] = (0, import_react.useState)(String(ROSARIO.lat));
	const [lng, setLng] = (0, import_react.useState)(String(ROSARIO.lng));
	function reload() {
		getMyAccount().then((next) => {
			setAccount(next);
			if (!businessId && next.businesses[0]) setBusinessId(next.businesses[0].id);
		});
		listQuoteInbox().then(setInbox).catch(() => setInbox([]));
		listSellerPaymentLinks().then(setPayments).catch(() => setPayments(null));
	}
	(0, import_react.useEffect)(() => {
		const current = account?.businesses.find((business) => business.id === businessId);
		setEditIds(current?.categoryIds ?? []);
	}, [account, businessId]);
	(0, import_react.useEffect)(() => {
		if (user) reload();
	}, [user]);
	if (!isPending && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 flex flex-wrap items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl",
				children: "Tu negocio"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm text-muted",
				children: "Cerca no carga productos. Los publica cada proveedor, después de que el negocio esté aprobado."
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/panel/productos",
				className: "inline-flex min-h-11 items-center rounded-full bg-copper px-4 text-ink",
				children: "Mis productos"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-2 rounded-card border border-line bg-foam p-4",
					onSubmit: (event) => {
						event.preventDefault();
						createBusiness({ data: {
							tradeName,
							legalName,
							phone,
							address,
							neighborhood,
							categoryIds
						} }).then((created) => {
							toast.success("Negocio enviado a revisión.");
							setBusinessId(created.id);
							reload();
						}).catch((error) => toast.error(error instanceof Error ? error.message : "No se creó."));
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl",
							children: "Alta"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: tradeName,
							onChange: (event) => setTradeName(event.target.value),
							placeholder: "Nombre comercial",
							className: "min-h-11 rounded-2xl border border-line px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: legalName,
							onChange: (event) => setLegalName(event.target.value),
							placeholder: "Razón social",
							className: "min-h-11 rounded-2xl border border-line px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: phone,
							onChange: (event) => setPhone(event.target.value),
							placeholder: "Teléfono",
							className: "min-h-11 rounded-2xl border border-line px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: address,
							onChange: (event) => setAddress(event.target.value),
							placeholder: "Dirección",
							className: "min-h-11 rounded-2xl border border-line px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: neighborhood,
							onChange: (event) => setNeighborhood(event.target.value),
							placeholder: "Barrio",
							className: "min-h-11 rounded-2xl border border-line px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SellerCategoryPicker, {
							selected: categoryIds,
							onChange: setCategoryIds
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: categoryIds.length === 0,
							className: "min-h-11 rounded-full bg-ember text-ink disabled:opacity-40",
							children: categoryIds.length === 0 ? "Continuar" : "Continuar →"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "text-sm text-muted",
							children: account?.businesses.map((business) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
								business.trade_name,
								" — ",
								business.status
							] }, business.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "grid gap-2 rounded-card border border-line bg-foam p-4",
					onSubmit: (event) => {
						event.preventDefault();
						setBusinessLocation({ data: {
							businessId,
							lat: Number(lat),
							lng: Number(lng),
							delivery: true,
							pickup: true
						} }).then(() => toast.success("Ubicación guardada.")).catch((error) => toast.error(error instanceof Error ? error.message : "No se guardó."));
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl",
							children: "Ubicación"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: businessId,
							onChange: (event) => setBusinessId(event.target.value),
							className: "min-h-11 rounded-2xl border border-line px-3",
							children: account?.businesses.map((business) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: business.id,
								children: business.trade_name
							}, business.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: lat,
								onChange: (event) => setLat(event.target.value),
								className: "min-h-11 rounded-2xl border border-line px-3"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: lng,
								onChange: (event) => setLng(event.target.value),
								className: "min-h-11 rounded-2xl border border-line px-3"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								"Latitud y longitud dentro de Rosario. El centro es ",
								ROSARIO.lat,
								", ",
								ROSARIO.lng,
								"."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "min-h-11 rounded-full bg-olive text-ink",
							children: "Guardar punto"
						})
					]
				}),
				businessId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-3 rounded-card border border-line bg-foam p-4 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SellerCategoryPicker, {
						selected: editIds,
						onChange: setEditIds,
						title: "Categorías de este negocio",
						hint: "Podés cambiarlas cuando quieras. No reemplazan la categoría de cada producto."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: editIds.length === 0,
						className: "min-h-11 rounded-full bg-ink px-4 text-paper disabled:opacity-40",
						onClick: () => {
							setBusinessCategories({ data: {
								businessId,
								categoryIds: editIds
							} }).then(() => {
								toast.success("Categorías guardadas.");
								reload();
							}).catch((error) => toast.error(error instanceof Error ? error.message : "No se guardaron."));
						},
						children: "Guardar categorías"
					})]
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 grid gap-3 rounded-card border border-line bg-foam p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Mercado Pago"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "Cada negocio conecta su propia cuenta. Cerca no muestra el token. Sin esa conexión no se puede cobrar."
				}),
				payments?.missing.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: [
						"No se puede conectar todavía. Falta: ",
						payments.missing.join(", "),
						"."
					]
				}) : null,
				payments?.warning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: payments.warning
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: payments?.businesses.map((business) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-line px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: business.tradeName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: business.connected ? `Conectado${business.liveMode === false ? " · modo de prueba" : ""}.` : business.status === "refresh_failed" ? "Hay que reconectar. El token no se pudo renovar." : "Sin conectar."
						})] }), business.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-full border border-line px-4",
							onClick: () => {
								disconnectSellerPayments({ data: business.businessId }).then((result) => {
									toast.success(result.message);
									reload();
								}).catch((error) => toast.error(error instanceof Error ? error.message : "No se desconectó."));
							},
							children: "Desconectar"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-full bg-ink px-4 text-paper",
							onClick: () => {
								startSellerOAuth({ data: business.businessId }).then((result) => {
									if (result.url) {
										window.location.href = result.url;
										return;
									}
									const missing = result.missing.length ? ` Falta: ${result.missing.join(", ")}.` : "";
									toast.message(`${result.message}${missing}`);
								}).catch((error) => toast.error(error instanceof Error ? error.message : "No se abrió Mercado Pago."));
							},
							children: "Conectar Mercado Pago"
						})]
					}, business.businessId))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Solicitudes de tus publicaciones"
				}),
				inbox.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No hay solicitudes abiertas para productos publicados."
				}) : null,
				inbox.map((request) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuoteReply, {
					request,
					onDone: reload
				}, request.id))
			]
		})
	] });
}
function QuoteReply({ request, onDone }) {
	const [price, setPrice] = (0, import_react.useState)("");
	const [shipping, setShipping] = (0, import_react.useState)("0");
	const [hours, setHours] = (0, import_react.useState)(48);
	const [notes, setNotes] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "grid gap-2 rounded-card border border-line bg-foam p-4",
		onSubmit: (event) => {
			event.preventDefault();
			const unitPriceCents = parseArsToCents(price);
			const shippingCents = parseArsToCents(shipping) ?? (shipping === "0" ? 0 : null);
			if (!unitPriceCents || shippingCents === null) {
				toast.error("Revisá los importes.");
				return;
			}
			submitQuote({ data: {
				requestId: request.id,
				businessId: request.business_id,
				unitPriceCents,
				quantity: request.quantity,
				shippingCents,
				leadTimeHours: hours,
				notes
			} }).then(() => {
				toast.success("Cotización enviada.");
				onDone();
			}).catch((error) => toast.error(error instanceof Error ? error.message : "No se envió."));
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xl",
				children: request.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Cantidad pedida: ",
					request.quantity,
					". ",
					request.notes
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: price,
				onChange: (event) => setPrice(event.target.value),
				placeholder: "Precio unitario",
				className: "min-h-11 rounded-2xl border border-line px-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: shipping,
				onChange: (event) => setShipping(event.target.value),
				placeholder: "Envío (0 si no cobra)",
				className: "min-h-11 rounded-2xl border border-line px-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "number",
				value: hours,
				onChange: (event) => setHours(Number(event.target.value)),
				className: "min-h-11 rounded-2xl border border-line px-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: notes,
				onChange: (event) => setNotes(event.target.value),
				placeholder: "Condiciones",
				className: "min-h-11 rounded-2xl border border-line px-3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "min-h-11 rounded-full bg-copper text-ink",
				children: "Enviar cotización"
			})
		]
	});
}
//#endregion
export { PanelPage as component };
