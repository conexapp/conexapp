import { T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell } from "./shell-Dr3dYE06.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cotizar-D2slIjrG.js
var import_jsx_runtime = require_jsx_runtime();
function CotizarPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-4xl",
			children: "Pedir cotización"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-xl text-sm text-muted",
			children: "La cotización es sobre la publicación de un proveedor, no sobre un producto genérico de Cerca. Buscá, abrí la publicación y pedila desde ahí."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "mt-4 inline-flex min-h-11 items-center rounded-full bg-ink px-4 text-paper",
			children: "Ir a buscar"
		})
	] });
}
//#endregion
export { CotizarPage as component };
