import { o as __toESM } from "../_runtime.mjs";
import { C as useNavigate, Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as SlidersHorizontal, i as Truck, m as Search, o as Store, z as BadgeCheck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as Route$19 } from "./router-CiLk3dI1.mjs";
import { d as loadDevelopmentSeed, f as searchMarketplace, h as useCurrentUserState, l as getPlatformStatus, n as Shell, o as getBusiness } from "./shell-Dr3dYE06.mjs";
import { n as parseArsToCents, t as formatArs } from "./money-DSc2EJ_o.mjs";
import { n as validMapPoint, t as MarketMap } from "./market-map-Be73bcVO.mjs";
import { n as browseCategories, r as categoryIcon, t as CategoryCard } from "./category-visual-G9mqIc48.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BSenasUS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const search = Route$19.useSearch();
	const navigate = useNavigate();
	const { user } = useCurrentUserState();
	const [q, setQ] = (0, import_react.useState)(search.q ?? "");
	const [category, setCategory] = (0, import_react.useState)(search.categoria ?? "");
	const [sort, setSort] = (0, import_react.useState)("price_asc");
	const [delivery, setDelivery] = (0, import_react.useState)(false);
	const [pickup, setPickup] = (0, import_react.useState)(false);
	const [maxPrice, setMaxPrice] = (0, import_react.useState)("");
	const [maxKm, setMaxKm] = (0, import_react.useState)("");
	const [filtersOpen, setFiltersOpen] = (0, import_react.useState)(false);
	const [result, setResult] = (0, import_react.useState)(null);
	const [demoAllowed, setDemoAllowed] = (0, import_react.useState)(false);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [placeLabel, setPlaceLabel] = (0, import_react.useState)(null);
	const [spots, setSpots] = (0, import_react.useState)({});
	const [loading, setLoading] = (0, import_react.useState)(true);
	async function execute(nextQ, nextCategory) {
		setLoading(true);
		try {
			const data = await searchMarketplace({ data: {
				q: nextQ,
				category: nextCategory,
				sort,
				delivery,
				pickup,
				inStock: true,
				maxPriceCents: maxPrice ? parseArsToCents(maxPrice) : null,
				maxDistanceKm: maxKm ? Number(maxKm) : null
			} });
			setResult(data);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "No se pudo buscar.");
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		getPlatformStatus().then((status) => setDemoAllowed(status.demoSeedAllowed));
	}, []);
	(0, import_react.useEffect)(() => {
		const nextQ = search.q ?? "";
		const nextCategory = search.categoria ?? "";
		setQ(nextQ);
		setCategory(nextCategory);
		execute(nextQ, nextCategory);
	}, [search.q, search.categoria]);
	const suppliers = (0, import_react.useMemo)(() => {
		const seen = /* @__PURE__ */ new Map();
		for (const listing of result?.listings ?? []) {
			const current = seen.get(listing.businessId);
			if (!current) seen.set(listing.businessId, {
				id: listing.businessId,
				name: listing.businessName,
				neighborhood: listing.neighborhood,
				distanceKm: listing.distanceKm,
				verified: listing.verified,
				count: 1,
				lat: listing.lat,
				lng: listing.lng,
				categories: [listing.categoryName]
			});
			else {
				current.count += 1;
				if (!current.categories.includes(listing.categoryName)) current.categories.push(listing.categoryName);
				if (current.lat === null && listing.lat !== null) current.lat = listing.lat;
				if (current.lng === null && listing.lng !== null) current.lng = listing.lng;
			}
		}
		return [...seen.values()];
	}, [result]);
	const points = (0, import_react.useMemo)(() => {
		const next = [];
		for (const supplier of suppliers) {
			const override = Object.prototype.hasOwnProperty.call(spots, supplier.id) ? spots[supplier.id] : void 0;
			const spot = override === void 0 ? validMapPoint(supplier.lat, supplier.lng) : override;
			if (!spot) continue;
			next.push({
				id: supplier.id,
				lat: spot.lat,
				lng: spot.lng,
				label: supplier.name,
				place: supplier.neighborhood?.trim() ? supplier.neighborhood.trim() : null,
				distanceKm: supplier.distanceKm,
				categories: supplier.categories
			});
		}
		return next;
	}, [suppliers, spots]);
	(0, import_react.useEffect)(() => {
		setSpots({});
		setPlaceLabel(null);
	}, [result]);
	(0, import_react.useEffect)(() => {
		if (selected && !suppliers.some((supplier) => supplier.id === selected)) {
			setSelected(null);
			setPlaceLabel(null);
		}
	}, [selected, suppliers]);
	(0, import_react.useEffect)(() => {
		if (!selected) return;
		let cancelled = false;
		getBusiness({ data: selected }).then((business) => {
			if (cancelled) return;
			const spot = validMapPoint(business.lat, business.lng);
			setSpots((current) => ({
				...current,
				[selected]: spot
			}));
			const parts = [
				business.addressLine,
				business.neighborhood,
				business.city
			].map((part) => typeof part === "string" ? part.trim() : "").filter((part) => part.length > 0);
			setPlaceLabel(parts.length > 0 ? parts.join(" · ") : null);
			if (!spot) setSelected(null);
		}).catch(() => {
			if (!cancelled) setPlaceLabel(null);
		});
		return () => {
			cancelled = true;
		};
	}, [selected, result]);
	const listings = result?.listings ?? [];
	const activeCategoryName = result?.categories.find((item) => item.slug === category)?.name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "overflow-hidden rounded-3xl border border-line bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 bg-sun" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 px-5 py-8 md:px-10 md:py-12 lg:grid-cols-[minmax(0,1.2fr)_minmax(16rem,0.8fr)] lg:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold text-olive",
						children: "Marketplace de Rosario"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 max-w-xl text-4xl leading-tight font-semibold tracking-tight md:text-5xl",
						children: "Todo lo que necesitás, cerca tuyo."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-lg text-base text-muted",
						children: "Encontrá proveedores, compará ofertas y comprá de forma segura."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-6 flex flex-col gap-2 sm:flex-row",
						onSubmit: (event) => {
							event.preventDefault();
							navigate({
								to: "/",
								search: {
									q: q.trim() || void 0,
									categoria: category || void 0
								},
								hash: "productos"
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-14 flex-1 items-center gap-3 rounded-full border border-line bg-paper px-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "size-5 text-teal",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: q,
								onChange: (event) => setQ(event.target.value),
								placeholder: "¿Qué estás buscando?",
								className: "min-w-0 flex-1 bg-transparent text-base outline-none"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "min-h-14 rounded-full bg-ember px-8 text-base font-semibold text-ink",
							children: "Buscar"
						})]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "grid grid-cols-3 gap-2 rounded-2xl bg-paper p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Publicaciones",
							value: loading ? "…" : String(listings.length)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Proveedores",
							value: loading ? "…" : String(suppliers.length)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Ciudad",
							value: "Rosario"
						})
					]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold",
					children: "Explorá por categoría"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/categorias",
					className: "inline-flex min-h-11 items-center text-sm font-semibold text-olive",
					children: "Ver todas las categorías"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5",
				children: browseCategories(result?.categories ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryCard, {
					slug: item.slug,
					name: item.name,
					icon: item.icon,
					active: category === item.slug,
					onSelect: () => {
						const next = category === item.slug ? void 0 : item.slug;
						navigate({
							to: "/",
							search: {
								q: q.trim() || void 0,
								categoria: next
							},
							hash: "productos"
						});
					}
				}, item.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "productos",
			className: "mt-10 scroll-mt-36",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-semibold",
						children: "Productos disponibles cerca"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [activeCategoryName ? activeCategoryName : "Publicaciones activas de proveedores aprobados", search.q ? ` · “${search.q}”` : ""]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-card px-4 text-sm font-medium",
						onClick: () => setFiltersOpen((open) => !open),
						"aria-expanded": filtersOpen,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
							className: "size-4",
							"aria-hidden": true
						}), "Filtros"]
					})]
				}),
				filtersOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mb-4 grid gap-2 rounded-2xl bg-card p-4 shadow-card sm:grid-cols-2 lg:grid-cols-6",
					onSubmit: (event) => {
						event.preventDefault();
						navigate({
							to: "/",
							search: {
								q: q.trim() || void 0,
								categoria: category || void 0
							},
							hash: "productos"
						});
						execute(q.trim(), category);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: category,
							onChange: (event) => setCategory(event.target.value),
							className: "min-h-11 rounded-full border border-line bg-paper px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Todas las categorías"
							}), result?.categories.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: item.slug,
								children: item.name
							}, item.id))]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: sort,
							onChange: (event) => setSort(event.target.value),
							className: "min-h-11 rounded-full border border-line bg-paper px-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "price_asc",
									children: "Menor precio"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "price_desc",
									children: "Mayor precio"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "distance",
									children: "Más cerca del centro"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: maxPrice,
							onChange: (event) => setMaxPrice(event.target.value),
							placeholder: "Precio máximo",
							className: "min-h-11 rounded-full border border-line bg-paper px-3 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: maxKm,
							onChange: (event) => setMaxKm(event.target.value),
							placeholder: "Km máx.",
							className: "min-h-11 rounded-full border border-line bg-paper px-3 text-sm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-2 rounded-full border border-line px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: delivery,
								onChange: (event) => setDelivery(event.target.checked)
							}), "Entrega"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-2 rounded-full border border-line px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: pickup,
								onChange: (event) => setPickup(event.target.checked)
							}), "Retiro"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "min-h-11 rounded-full bg-teal px-4 text-sm font-semibold text-ink sm:col-span-2 lg:col-span-1",
							children: "Aplicar"
						})
					]
				}) : null,
				loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 lg:grid-cols-4",
					children: Array.from({ length: 4 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72 rounded-2xl bg-card shadow-card" }, index))
				}) : null,
				!loading && listings.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-card p-6 shadow-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl font-semibold",
							children: "Todavía no hay productos publicados en esta búsqueda."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm text-muted",
							children: "Cerca no precarga un catálogo. Un proveedor crea su negocio, lo aprueban y publica sus propios productos."
						}),
						demoAllowed && user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-4 min-h-11 rounded-full border border-ink px-4 text-sm font-medium",
							onClick: () => {
								loadDevelopmentSeed().then(() => {
									toast.success("Ejemplos guardados como desarrollo. No aparecen en la búsqueda pública.");
									return execute(q, category);
								}).catch((error) => toast.error(error instanceof Error ? error.message : "No se pudo cargar."));
							},
							children: "Cargar ejemplos de desarrollo"
						}) : null
					]
				}) : null,
				!loading && listings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4",
					children: listings.map((listing) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { listing }, listing.id))
				}) : null
			]
		}),
		(result?.comparisons.length ?? 0) > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold",
					children: "Mismo producto, varios proveedores"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Solo se agrupan si cada proveedor usó la misma ancla de catálogo."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid gap-3",
					children: result?.comparisons.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl bg-card p-4 shadow-card",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-semibold",
							children: group.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex gap-3 overflow-x-auto pb-1",
							children: listings.filter((listing) => group.listingIds.includes(listing.id)).map((listing) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/producto/$productId",
								params: { productId: listing.id },
								className: "w-56 shrink-0 rounded-2xl bg-paper p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-semibold",
										children: listing.businessName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-2xl tabular-nums",
										children: formatArs(listing.priceCents)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted",
										children: ["/ ", listing.unit]
									})
								]
							}, listing.id))
						})]
					}, group.standardProductId))
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "proveedores",
			className: "mt-10 scroll-mt-36",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-semibold",
					children: "Proveedores cerca tuyo"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Ubicación real de los negocios que aparecen en esta búsqueda."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 md:grid-cols-[minmax(0,1fr)_minmax(16rem,22rem)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 lg:max-h-80 lg:overflow-y-auto",
					children: [
						loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-28 rounded-2xl bg-card shadow-card" }) : null,
						!loading && suppliers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl bg-card p-4 shadow-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-semibold",
								children: "No hay proveedores en esta búsqueda."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Cuando un negocio aprobado publique productos, va a aparecer en esta lista y, si tiene coordenadas, en el mapa."
							})]
						}) : null,
						suppliers.map((supplier) => {
							const located = points.some((point) => point.id === supplier.id);
							const active = selected === supplier.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: `flex flex-col gap-2 rounded-2xl bg-card p-4 shadow-card ${active ? "ring-2 ring-teal" : ""}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									disabled: !located,
									onClick: () => setSelected(supplier.id),
									className: "flex items-start gap-3 text-left disabled:cursor-default",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid size-11 shrink-0 place-items-center rounded-xl bg-teal/10 text-olive",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, {
											className: "size-5",
											"aria-hidden": true
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-semibold",
											children: supplier.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "mt-1 block text-sm text-muted",
											children: [
												supplier.neighborhood ? supplier.neighborhood : null,
												supplier.neighborhood && supplier.distanceKm !== null ? " · " : "",
												supplier.distanceKm !== null ? `${supplier.distanceKm} km` : "",
												!located ? `${supplier.neighborhood || supplier.distanceKm !== null ? " · " : ""}sin ubicación en el mapa` : ""
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "mt-1 block text-sm",
											children: [
												supplier.count,
												" ",
												supplier.count === 1 ? "publicación" : "publicaciones",
												supplier.verified ? " · verificado" : ""
											]
										})
									] })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/negocio/$businessId",
									params: { businessId: supplier.id },
									className: "inline-flex min-h-11 items-center self-start rounded-full bg-paper px-4 text-sm font-semibold",
									children: "Ver proveedor"
								})]
							}, supplier.id);
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketMap, {
					points,
					selectedId: selected,
					onSelect: setSelected,
					popup: true,
					detailPlace: placeLabel,
					emptyNote: loading ? null : suppliers.length === 0 ? "Todavía no hay proveedores para marcar." : points.length === 0 ? "Estos proveedores todavía no tienen una ubicación válida." : null
				})]
			})]
		})
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card px-2 py-3 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 font-display text-lg font-semibold tabular-nums",
			children: value
		})]
	});
}
function ProductCard({ listing }) {
	const Icon = categoryIcon(listing.categorySlug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col overflow-hidden rounded-2xl bg-card shadow-card",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/producto/$productId",
			params: { productId: listing.id },
			className: "relative block aspect-square bg-paper",
			children: listing.imageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: listing.imageUrl,
				alt: "",
				className: "h-full w-full object-cover outline outline-1 -outline-offset-1 outline-black/10"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-full place-items-center text-olive",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					className: "size-10",
					"aria-hidden": true
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-1 p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-muted",
					children: listing.brand || listing.categoryName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "line-clamp-2 text-sm font-semibold",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/producto/$productId",
						params: { productId: listing.id },
						children: listing.name
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-xl leading-none font-semibold tabular-nums",
					children: formatArs(listing.priceCents)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: ["/ ", listing.unit]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 truncate text-sm",
					children: listing.businessName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate text-xs text-muted",
					children: [listing.neighborhood ?? "Rosario", listing.distanceKm !== null ? ` · ${listing.distanceKm} km` : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex flex-wrap gap-1",
					children: [
						listing.delivery ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-full bg-sun px-2 py-1 text-xs font-medium text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Truck, {
								className: "size-3",
								"aria-hidden": true
							}), "Entrega"]
						}) : null,
						listing.pickup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-paper px-2 py-1 text-xs font-medium",
							children: "Retiro"
						}) : null,
						listing.verified ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1 rounded-full bg-teal/15 px-2 py-1 text-xs font-medium text-olive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
								className: "size-3",
								"aria-hidden": true
							}), "Verificado"]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/producto/$productId",
					params: { productId: listing.id },
					className: "mt-3 inline-flex min-h-11 items-center justify-center rounded-full bg-ember text-sm font-semibold text-ink",
					children: "Ver producto"
				})
			]
		})]
	});
}
//#endregion
export { Home as component };
