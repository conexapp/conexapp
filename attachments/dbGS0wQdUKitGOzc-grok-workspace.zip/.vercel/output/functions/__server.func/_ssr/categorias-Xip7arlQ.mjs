import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as searchMarketplace, n as Shell } from "./shell-Dr3dYE06.mjs";
import { t as CategoryCard } from "./category-visual-G9mqIc48.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/categorias-Xip7arlQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CategoriesPage() {
	const [categories, setCategories] = (0, import_react.useState)([]);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		searchMarketplace({ data: {} }).then((result) => setCategories(result.categories)).finally(() => setReady(true));
	}, []);
	const roots = categories.filter((category) => category.parentId === null);
	const children = (parentId) => categories.filter((category) => category.parentId === parentId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-4xl",
			children: "Todas las categorías"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm text-muted",
			children: "El catálogo sale de la base. Una categoría sin publicaciones no inventa productos."
		}),
		!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-6 h-40 rounded-2xl bg-card shadow-card" }) : null,
		ready && roots.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 rounded-2xl bg-card p-4 text-sm shadow-card",
			children: "Todavía no hay categorías activas."
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-6",
			children: roots.map((root) => {
				const nested = children(root.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-[12rem_1fr] sm:items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryCard, {
						slug: root.slug,
						name: root.name,
						icon: root.icon
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: nested.length > 0 ? `${nested.length} subcategorías` : "Sin subcategorías"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							search: { categoria: root.slug },
							hash: "productos",
							className: "mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-olive",
							children: "Ver publicaciones"
						}),
						nested.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 flex flex-wrap gap-2",
							children: nested.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								search: { categoria: child.slug },
								hash: "productos",
								className: "inline-flex min-h-11 items-center rounded-full bg-card px-3 text-sm shadow-card",
								children: child.name
							}) }, child.id))
						}) : null
					] })]
				}) }, root.id);
			})
		})
	] });
}
//#endregion
export { CategoriesPage as component };
