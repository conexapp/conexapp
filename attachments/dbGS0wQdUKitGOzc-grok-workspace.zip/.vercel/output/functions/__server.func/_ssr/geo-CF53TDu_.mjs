//#region node_modules/.nitro/vite/services/ssr/assets/geo-CF53TDu_.js
var ROSARIO = {
	lat: -32.944242,
	lng: -60.650539
};
function distanceKm(lat1, lng1, lat2, lng2) {
	const r = 6371;
	const dLat = (lat2 - lat1) * Math.PI / 180;
	const dLng = (lng2 - lng1) * Math.PI / 180;
	const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
	return 2 * r * Math.asin(Math.min(1, Math.sqrt(a)));
}
//#endregion
export { distanceKm as n, ROSARIO as t };
