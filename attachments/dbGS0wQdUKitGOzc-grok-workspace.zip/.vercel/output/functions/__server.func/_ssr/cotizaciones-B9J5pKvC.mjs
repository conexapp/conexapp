import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { h as useCurrentUserState, n as Shell, t as RedirectToSignIn } from "./shell-Dr3dYE06.mjs";
import { t as formatArs } from "./money-DSc2EJ_o.mjs";
import { s as listMyQuoteRequests, t as acceptQuote } from "./trade-C_IUkqNG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cotizaciones-B9J5pKvC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuotesPage() {
	const { user, isPending } = useCurrentUserState();
	const [data, setData] = (0, import_react.useState)(null);
	function reload() {
		listMyQuoteRequests().then(setData).catch((error) => toast.error(error instanceof Error ? error.message : "No se pudieron leer."));
	}
	(0, import_react.useEffect)(() => {
		if (user) reload();
	}, [user]);
	if (!isPending && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "mb-4 text-4xl",
		children: "Cotizaciones"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4",
		children: [data?.requests.map((request) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "rounded-card border border-line bg-foam p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl",
						children: request.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-muted",
						children: request.status
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						request.quantity,
						" · ",
						request.delivery_required ? request.address_line : "retiro"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2",
					children: data.quotes.filter((quote) => quote.request_id === request.id).map((quote) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center justify-between gap-2 border-t border-line pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: quote.trade_name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								formatArs(quote.unitPriceCents),
								" × ",
								quote.quantity,
								quote.shippingCents ? ` + envío ${formatArs(quote.shippingCents)}` : "",
								quote.lead_time_hours !== null ? ` · ${quote.lead_time_hours} h` : "",
								" · ",
								quote.status
							]
						})] }), quote.status === "submitted" && request.status !== "accepted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "min-h-11 rounded-full bg-ink px-4 text-paper",
							onClick: () => {
								acceptQuote({ data: {
									quoteId: quote.id,
									idempotencyKey: crypto.randomUUID()
								} }).then((order) => {
									toast.success("Cotización aceptada. El pedido quedó pendiente de pago: no se cobró nada.");
									window.location.href = `/pedidos/${order.orderId}`;
								}).catch((error) => toast.error(error instanceof Error ? error.message : "No se aceptó."));
							},
							children: ["Aceptar ", formatArs(quote.totalCents)]
						}) : null]
					}, quote.id))
				}),
				data.quotes.every((quote) => quote.request_id !== request.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "Todavía no hay respuestas."
				}) : null
			]
		}, request.id)), data && data.requests.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-muted",
			children: ["No pediste cotizaciones. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/cotizar",
				className: "text-copper",
				children: "Empezar"
			})]
		}) : null]
	})] });
}
//#endregion
export { QuotesPage as component };
