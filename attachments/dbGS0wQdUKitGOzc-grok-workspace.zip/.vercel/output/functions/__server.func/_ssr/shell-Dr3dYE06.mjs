import { o as __toESM } from "../_runtime.mjs";
import { n as assertString } from "./helpers-wEAdpef7.mjs";
import { a as hasGateSessionMarker } from "./server-BWq9NAA0.mjs";
import { C as useNavigate, Q as require_react, S as Navigate, T as require_jsx_runtime, m as useRouterState, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as ShoppingBag, m as Search, y as MapPin } from "../_libs/lucide-react.mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { i as signOut, t as authClient } from "./client-IWHfIGH2.mjs";
import { t as authMiddleware } from "./middleware-BS1-Yv7g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-Dr3dYE06.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/** Render children only when a user is present (real session, or the disabled-auth dev user). */
function SignedIn({ children }) {
	const { user } = useCurrentUserState();
	return user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children }) : null;
}
/**
* Render children only once we KNOW the visitor is signed out (`isPending` has
* cleared and there is no user). Hidden while the session is still loading.
*/
function SignedOut({ children }) {
	const { user, isPending } = useCurrentUserState();
	if (isPending || user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid size-8 place-items-center rounded-full bg-teal/15 text-sm font-semibold text-olive",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm text-olive underline-offset-4 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Saliendo…" : "Salir"
			})
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getMyAccount = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("4aba93c8662aeff5a995730eae5280b597f453d9df364fbab0e5bcd9b3c092c0"));
var updateMyPhone = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((phone) => {
	const value = assertString(phone, "Teléfono", 30);
	if (!/^[0-9+\s()-]{8,30}$/.test(value)) throw new Error("Teléfono argentino inválido.");
	return value;
}).handler(createSsrRpc("ae8d45090271869dc24f27778ba1febaaf6770f9494d2e536e22cd112c376fe5"));
var claimAdminIfNone = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("09cbe489c341db73d7abaeae69d4e349f73e30314550014224a3ef143acc8d46"));
var createBusiness = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => ({
	tradeName: assertString(input?.tradeName, "Nombre comercial", 80),
	legalName: assertString(input?.legalName, "Razón social", 120),
	phone: assertString(input?.phone, "Teléfono", 30),
	address: assertString(input?.address, "Dirección", 160),
	neighborhood: assertString(input?.neighborhood, "Barrio", 80),
	categoryIds: Array.isArray(input?.categoryIds) ? input.categoryIds : []
})).handler(createSsrRpc("c3ab414d4fa41a17c10b6fe5f4ba285042f6c46200e868db660c87ced6e8a65e"));
var setBusinessLocation = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => {
	if (!input?.businessId) throw new Error("Falta el negocio.");
	if (typeof input.lat !== "number" || typeof input.lng !== "number") throw new Error("Marcá el punto en el mapa.");
	if (input.lat < -33.2 || input.lat > -32.7 || input.lng < -60.9 || input.lng > -60.4) throw new Error("El punto tiene que estar en el área de Rosario.");
	return {
		businessId: input.businessId,
		lat: input.lat,
		lng: input.lng,
		delivery: input.delivery === true,
		pickup: input.pickup !== false
	};
}).handler(createSsrRpc("bc2419c21c0938f4f49eeacc128c1b19f8b96ea62abe3a5e7e6e60a35a8687eb"));
createServerFn({ method: "GET" }).handler(createSsrRpc("48e541d21fb027f1f61e19b16e087a25efac3da8ff006201b813cd85d565e0e2"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((input) => input).handler(createSsrRpc("08fba208bf348b1a61fc39c4a1c3029884ae5d837b102a3148995e1b821b12d6"));
var loadDevelopmentSeed = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("566256237164e949f12dd8a4dcbf5f6dbc4bffcbe7f08ffa786c06f29fd62701"));
var listNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("b566c1f8f028153ebeb77917e06004b3fc531022277a1ad52c4c78e17b8397a2"));
function cleanSearch(input) {
	const sort = input.sort;
	return {
		q: typeof input.q === "string" ? input.q.trim().slice(0, 80) : "",
		category: typeof input.category === "string" ? input.category : "",
		maxPriceCents: typeof input.maxPriceCents === "number" && input.maxPriceCents > 0 ? Math.round(input.maxPriceCents) : null,
		maxDistanceKm: typeof input.maxDistanceKm === "number" && input.maxDistanceKm > 0 ? input.maxDistanceKm : null,
		delivery: input.delivery === true,
		pickup: input.pickup === true,
		inStock: input.inStock !== false,
		sort: sort === "price_desc" || sort === "distance" || sort === "price_asc" ? sort : "price_asc"
	};
}
var searchMarketplace = createServerFn({ method: "GET" }).validator((input) => cleanSearch(input ?? {})).handler(createSsrRpc("595a8ab801994b6292bc300a91b651e567e2daae81ed0471d75b56f838b3f92d"));
var getListing = createServerFn({ method: "GET" }).validator((listingId) => {
	if (typeof listingId !== "string" || listingId.length > 80) throw new Error("Publicación inválida.");
	return listingId;
}).handler(createSsrRpc("5e3c309d39c92021bb234d83940e34ecd99decd8e2a7617d1813c18486ed7202"));
var getBusiness = createServerFn({ method: "GET" }).validator((businessId) => {
	if (typeof businessId !== "string" || businessId.length > 80) throw new Error("Negocio inválido.");
	return businessId;
}).handler(createSsrRpc("2cca906b0777e366fa01707ff8f41e6326b7a6364c15a7cb94b3fd62ba2b305f"));
var getPlatformStatus = createServerFn({ method: "GET" }).handler(createSsrRpc("eb7a6e2652b1acce69d022bec5bb992294f4ce36f090057ad803bae6f6247612"));
function Shell({ children }) {
	const navigate = useNavigate();
	const { user } = useCurrentUserState();
	const locationSearch = useRouterState({ select: (state) => state.location.search });
	const activeCategory = typeof locationSearch?.categoria === "string" ? locationSearch.categoria : "";
	const [categories, setCategories] = (0, import_react.useState)([]);
	const [headerQ, setHeaderQ] = (0, import_react.useState)(typeof locationSearch?.q === "string" ? locationSearch.q : "");
	const [isAdmin, setIsAdmin] = (0, import_react.useState)(false);
	const [canClaimAdmin, setCanClaimAdmin] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof locationSearch?.q === "string") setHeaderQ(locationSearch.q);
	}, [locationSearch?.q]);
	(0, import_react.useEffect)(() => {
		searchMarketplace({ data: {} }).then((result) => setCategories(result.categories)).catch(() => setCategories([]));
	}, []);
	(0, import_react.useEffect)(() => {
		if (!user) {
			setIsAdmin(false);
			setCanClaimAdmin(false);
			return;
		}
		getMyAccount().then((account) => {
			setIsAdmin(account.platformRole === "admin");
			setCanClaimAdmin(account.canClaimAdmin);
		}).catch(() => {
			setIsAdmin(false);
			setCanClaimAdmin(false);
		});
	}, [user]);
	function submitSearch(event) {
		event.preventDefault();
		navigate({
			to: "/",
			search: {
				q: headerQ.trim() || void 0,
				categoria: void 0
			},
			hash: "productos"
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-40 bg-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-line",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-7xl items-center gap-3 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								search: {
									q: void 0,
									categoria: void 0
								},
								className: "shrink-0 leading-none",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-2xl font-semibold tracking-tight text-olive",
									children: "Cerca"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "hidden shrink-0 items-center gap-1 text-sm text-muted sm:inline-flex",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
									className: "size-4 text-teal",
									"aria-hidden": true
								}), "Rosario"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
								onSubmit: submitSearch,
								className: "mx-4 hidden min-w-0 max-w-xl flex-1 md:flex",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-h-11 min-w-0 flex-1 items-center gap-2 rounded-full border border-line bg-paper px-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
										className: "size-4 shrink-0 text-muted",
										"aria-hidden": true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: headerQ,
										onChange: (event) => setHeaderQ(event.target.value),
										placeholder: "Buscar productos o proveedores",
										className: "min-w-0 flex-1 bg-transparent text-sm outline-none"
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
								className: "ml-auto flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/",
										hash: "proveedores",
										search: {
											q: void 0,
											categoria: void 0
										},
										className: "hidden min-h-11 items-center rounded-full px-3 text-sm font-medium hover:bg-paper lg:inline-flex",
										children: "Proveedores"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/cotizar",
										className: "hidden min-h-11 items-center rounded-full px-3 text-sm font-medium hover:bg-paper lg:inline-flex",
										children: "Necesito esto"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
											className: "flex min-h-11 list-none items-center gap-1.5 rounded-full px-3 text-sm font-medium hover:bg-paper",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
												className: "size-4",
												"aria-hidden": true
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "hidden sm:inline",
												children: "Carrito"
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute right-0 z-50 mt-2 w-72 rounded-2xl bg-card p-4 shadow-card",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-display text-lg font-semibold",
													children: "Sin carrito armado"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-sm text-muted",
													children: "El pedido nace cuando aceptás una cotización. No se mezcla mercadería de varios proveedores en un mismo pago."
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "mt-3 grid gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
														to: "/cotizaciones",
														className: "inline-flex min-h-11 items-center rounded-full bg-paper px-4 text-sm font-medium",
														children: "Mis cotizaciones"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
														to: "/pedidos",
														className: "inline-flex min-h-11 items-center rounded-full bg-ember px-4 text-sm font-semibold text-ink",
														children: "Mis pedidos"
													})]
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/login",
										className: "inline-flex min-h-11 items-center rounded-full bg-ink px-4 text-sm font-semibold text-paper",
										children: "Entrar"
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
											className: "flex min-h-11 list-none items-center rounded-full px-3 text-sm font-medium hover:bg-paper",
											children: "Cuenta"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "absolute right-0 z-50 mt-2 grid w-64 gap-1 rounded-2xl bg-card p-2 shadow-card",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
													to: "/cuenta",
													className: "inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper",
													children: "Mi cuenta"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
													to: "/panel",
													className: "inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper",
													children: "Mi negocio"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
													to: "/cotizaciones",
													className: "inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper",
													children: "Mis cotizaciones"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
													to: "/pedidos",
													className: "inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper",
													children: "Mis pedidos"
												}),
												isAdmin || canClaimAdmin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
													to: "/admin",
													className: "inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper",
													children: "Administración"
												}) : null
											]
										})]
									}) })
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
						onSubmit: submitSearch,
						className: "px-4 pb-3 md:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-2 rounded-full border border-line bg-paper px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "size-4 text-muted",
								"aria-hidden": true
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: headerQ,
								onChange: (event) => setHeaderQ(event.target.value),
								placeholder: "Buscar productos o proveedores",
								className: "min-w-0 flex-1 bg-transparent text-sm outline-none"
							})]
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-7xl items-center gap-2 overflow-x-auto px-4 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/categorias",
								className: "inline-flex min-h-11 shrink-0 items-center rounded-full bg-ink px-4 text-sm font-semibold text-paper",
								children: "Todas las categorías"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/cotizar",
								className: "inline-flex min-h-11 shrink-0 items-center rounded-full px-3 text-sm font-medium hover:bg-paper lg:hidden",
								children: "Necesito esto"
							}),
							(() => {
								const featured = categories.filter((item) => item.featured && !item.parentId);
								return (featured.length > 0 ? featured : categories.filter((item) => !item.parentId)).map((item) => {
									const active = activeCategory === item.slug;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/",
										search: {
											q: void 0,
											categoria: item.slug
										},
										hash: "productos",
										className: `inline-flex min-h-11 shrink-0 items-center rounded-full px-3 text-sm font-medium ${active ? "bg-sun text-ink" : "hover:bg-paper"}`,
										children: item.name
									}, item.id);
								});
							})()
						]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-7xl px-4 py-6",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4 text-sm text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cerca no da la razón de antemano. La protección sigue la evidencia que quedó en el pedido." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/proteccion",
						className: "font-semibold text-ink",
						children: "Cerca Protección"
					})]
				})
			})
		]
	});
}
//#endregion
export { createSsrRpc as a, getMyAccount as c, loadDevelopmentSeed as d, searchMarketplace as f, useCurrentUserState as h, createBusiness as i, getPlatformStatus as l, updateMyPhone as m, Shell as n, getBusiness as o, setBusinessLocation as p, claimAdminIfNone as r, getListing as s, RedirectToSignIn as t, listNotifications as u };
