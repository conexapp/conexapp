//#region node_modules/.nitro/vite/services/ssr/assets/text-6B5QLHgg.js
function fold(value) {
	return value.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase().replace(/\s+/g, " ").trim();
}
function slugify(value) {
	return fold(value).replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 72) || "item";
}
function likeContains(value) {
	return `%${fold(value).replace(/[\\%_]/g, "\\$&")}%`;
}
//#endregion
export { likeContains as n, slugify as r, fold as t };
