import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as LocateFixed, t as X } from "../_libs/lucide-react.mjs";
import { t as ROSARIO } from "./geo-CF53TDu_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/market-map-Be73bcVO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function validMapPoint(lat, lng) {
	if (lat === null || lng === null) return null;
	if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
	if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
	return {
		lat,
		lng
	};
}
function MarketMap({ points, selectedId, onSelect, popup = false, detailPlace = null, emptyNote = null }) {
	const node = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const layerRef = (0, import_react.useRef)(null);
	const onSelectRef = (0, import_react.useRef)(onSelect);
	const [ready, setReady] = (0, import_react.useState)(false);
	const focused = (0, import_react.useRef)(null);
	onSelectRef.current = onSelect;
	(0, import_react.useEffect)(() => {
		const nodeEl = node.current;
		if (!nodeEl) return;
		let removed = false;
		let map = null;
		(async () => {
			const L = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (removed || !node.current || mapRef.current) return;
			map = L.map(node.current, {
				scrollWheelZoom: false,
				zoomControl: true
			}).setView([ROSARIO.lat, ROSARIO.lng], 12);
			L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
				attribution: "&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> contributors",
				maxZoom: 19,
				subdomains: "abc"
			}).addTo(map);
			layerRef.current = L.layerGroup().addTo(map);
			map.on("click", () => onSelectRef.current(null));
			const enableWheel = () => map?.scrollWheelZoom.enable();
			const disableWheel = () => map?.scrollWheelZoom.disable();
			map.getContainer().addEventListener("mouseenter", enableWheel);
			map.getContainer().addEventListener("mouseleave", disableWheel);
			mapRef.current = map;
			const redraw = () => map?.invalidateSize();
			redraw();
			window.setTimeout(redraw, 80);
			window.setTimeout(redraw, 400);
			if (!removed) setReady(true);
		})();
		const observer = new ResizeObserver(() => mapRef.current?.invalidateSize());
		observer.observe(nodeEl);
		return () => {
			removed = true;
			observer.disconnect();
			mapRef.current?.remove();
			mapRef.current = null;
			layerRef.current = null;
			setReady(false);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		const layer = layerRef.current;
		if (!ready || !map || !layer) return;
		let dead = false;
		(async () => {
			const L = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (dead) return;
			layer.clearLayers();
			for (const point of points) {
				const spot = validMapPoint(point.lat, point.lng);
				if (!spot) continue;
				const selected = point.id === selectedId;
				const marker = L.marker([spot.lat, spot.lng], {
					icon: L.divIcon({
						className: "cerca-pin-wrap",
						html: `<span class="cerca-pin${selected ? " is-selected" : ""}"></span>`,
						iconSize: [28, 28],
						iconAnchor: [14, 14]
					}),
					keyboard: true,
					title: point.label
				});
				marker.on("click", (event) => {
					L.DomEvent.stopPropagation(event);
					onSelectRef.current(point.id);
				});
				marker.addTo(layer);
			}
			const selected = points.find((point) => point.id === selectedId);
			const spot = selected ? validMapPoint(selected.lat, selected.lng) : null;
			if (selected && spot) {
				const previous = focused.current;
				if (!previous || previous.id !== selected.id || previous.lat !== spot.lat || previous.lng !== spot.lng) map.panTo([spot.lat, spot.lng]);
				focused.current = {
					id: selected.id,
					lat: spot.lat,
					lng: spot.lng
				};
			} else focused.current = null;
		})();
		return () => {
			dead = true;
		};
	}, [
		points,
		selectedId,
		ready
	]);
	const selected = points.find((point) => point.id === selectedId) ?? null;
	const place = detailPlace ?? selected?.place ?? null;
	function recenter() {
		mapRef.current?.setView([ROSARIO.lat, ROSARIO.lng], 12);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "cerca-map relative h-80 min-h-80 w-full overflow-hidden rounded-2xl bg-paper",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: node,
				className: "absolute inset-0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: recenter,
				className: "absolute top-3 right-3 z-[500] inline-flex min-h-11 items-center gap-1 rounded-full bg-card px-3 text-sm font-semibold text-ink shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, {
					className: "size-4 text-olive",
					"aria-hidden": true
				}), "Rosario"]
			}),
			points.length === 0 && emptyNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "pointer-events-none absolute inset-x-3 bottom-3 z-[500] rounded-2xl bg-card/95 px-3 py-2 text-sm text-ink shadow-card",
				children: emptyNote
			}) : null,
			popup && selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-3 bottom-3 z-[500] rounded-2xl bg-card p-3 shadow-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold",
							children: selected.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": "Cerrar",
							onClick: () => onSelect(null),
							className: "grid size-11 shrink-0 place-items-center rounded-full hover:bg-paper",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
								className: "size-4",
								"aria-hidden": true
							})
						})]
					}),
					place ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: place
					}) : null,
					selected.categories && selected.categories.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: selected.categories.join(" · ")
					}) : null,
					typeof selected.distanceKm === "number" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [selected.distanceKm, " km del centro"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/negocio/$businessId",
						params: { businessId: selected.id },
						className: "mt-2 inline-flex min-h-11 items-center rounded-full bg-ember px-4 text-sm font-semibold text-ink",
						children: "Ver proveedor"
					})
				]
			}) : null
		]
	});
}
//#endregion
export { validMapPoint as n, MarketMap as t };
