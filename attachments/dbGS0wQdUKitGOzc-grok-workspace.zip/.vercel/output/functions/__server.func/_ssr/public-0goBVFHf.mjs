import { f as sql, i as dbSource, t as asInt } from "./helpers-wEAdpef7.mjs";
import { l as readMercadoPagoEnv, s as missingMercadoPagoCredentials } from "./mercadopago-BrD8R2__.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { n as distanceKm, t as ROSARIO } from "./geo-CF53TDu_.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { n as likeContains, t as fold } from "./text-6B5QLHgg.mjs";
import { t as comparableGroups } from "./listings-C06er98N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/public-0goBVFHf.js
var cartoVoyager = {
	id: "carto-voyager",
	url: "https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
	attribution: "&copy; OpenStreetMap &copy; CARTO",
	maxZoom: 19
};
function activeMapTiles() {
	return cartoVoyager;
}
function cleanSearch(input) {
	const sort = input.sort;
	return {
		q: typeof input.q === "string" ? input.q.trim().slice(0, 80) : "",
		category: typeof input.category === "string" ? input.category : "",
		maxPriceCents: typeof input.maxPriceCents === "number" && input.maxPriceCents > 0 ? Math.round(input.maxPriceCents) : null,
		maxDistanceKm: typeof input.maxDistanceKm === "number" && input.maxDistanceKm > 0 ? input.maxDistanceKm : null,
		delivery: input.delivery === true,
		pickup: input.pickup === true,
		inStock: input.inStock !== false,
		sort: sort === "price_desc" || sort === "distance" || sort === "price_asc" ? sort : "price_asc"
	};
}
function imageUrl(key) {
	if (!key || !/^listings\/[0-9a-f-]{36}\/[0-9a-f-]{36}$/.test(key)) return null;
	return `/api/media/${key}`;
}
var searchMarketplace_createServerFn_handler = createServerRpc({
	id: "595a8ab801994b6292bc300a91b651e567e2daae81ed0471d75b56f838b3f92d",
	name: "searchMarketplace",
	filename: "src/lib/cerca/server/public.ts"
}, (opts) => searchMarketplace.__executeServer(opts));
var searchMarketplace = createServerFn({ method: "GET" }).validator((input) => cleanSearch(input ?? {})).handler(searchMarketplace_createServerFn_handler, async ({ data }) => {
	const db = await sql();
	const like = data.q ? likeContains(data.q) : "%";
	const foldedCategory = data.category ? fold(data.category) : "";
	let listings = (await db`
      select
        l.id, l.name, l.slug, l.brand, l.sku, l.unit, l.description, l.price_cents::text, l.stock_units,
        l.delivery, l.pickup, l.shipping_cents::text, l.lead_time_hours,
        c.name as category_name, c.slug as category_slug,
        l.standard_product_id, s.name as standard_name,
        b.id as business_id, b.trade_name, b.slug as business_slug, b.lat, b.lng, b.neighborhood,
        b.verified_at::text as verified_at,
        (select count(*)::int from orders ord where ord.business_id = b.id and ord.status = 'COMPLETED') as completed_orders,
        (select count(*)::int from orders ord where ord.business_id = b.id and ord.status = 'CANCELLED') as cancelled_orders,
        (select avg(r.rating)::float8 from reviews r where r.business_id = b.id) as avg_rating,
        (select count(*)::int from reviews r where r.business_id = b.id) as review_count,
        (
          select i.storage_key from listing_images i
          where i.listing_id = l.id and i.status = 'ready'
          order by i.is_primary desc, i.position
          limit 1
        ) as image_key
      from listings l
      join businesses b on b.id = l.business_id and b.status = 'active' and b.is_demo = false
      join categories c on c.id = l.category_id and c.active = true
      left join categories parent on parent.id = c.parent_id
      left join standard_products s on s.id = l.standard_product_id and s.active = true
      where l.status = 'published'
        and l.is_demo = false
        and l.stock_units > 0
        and (${data.q} = '' or l.search_text ilike ${like} escape '\\' or b.search_text ilike ${like} escape '\\')
        and (
          ${foldedCategory} = ''
          or c.slug = ${foldedCategory}
          or parent.slug = ${foldedCategory}
        )
    `).map((row) => {
		const distance = row.lat === null || row.lng === null ? null : Math.round(distanceKm(ROSARIO.lat, ROSARIO.lng, row.lat, row.lng) * 10) / 10;
		return {
			id: row.id,
			name: row.name,
			slug: row.slug,
			brand: row.brand,
			sku: row.sku,
			unit: row.unit,
			description: row.description,
			priceCents: asInt(row.price_cents),
			stockUnits: row.stock_units,
			delivery: row.delivery,
			pickup: row.pickup,
			shippingCents: asInt(row.shipping_cents),
			leadTimeHours: row.lead_time_hours,
			categoryName: row.category_name,
			categorySlug: row.category_slug,
			standardProductId: row.standard_product_id,
			standardProductName: row.standard_name,
			businessId: row.business_id,
			businessName: row.trade_name,
			businessSlug: row.business_slug,
			lat: row.lat,
			lng: row.lng,
			neighborhood: row.neighborhood,
			distanceKm: distance,
			verified: Boolean(row.verified_at),
			completedOrders: row.completed_orders,
			cancelledOrders: row.cancelled_orders,
			avgRating: row.avg_rating,
			reviewCount: row.review_count,
			imageUrl: imageUrl(row.image_key)
		};
	});
	if (data.delivery) listings = listings.filter((listing) => listing.delivery);
	if (data.pickup) listings = listings.filter((listing) => listing.pickup);
	if (data.maxPriceCents !== null) listings = listings.filter((listing) => listing.priceCents <= data.maxPriceCents);
	if (data.maxDistanceKm !== null) listings = listings.filter((listing) => listing.distanceKm !== null && listing.distanceKm <= data.maxDistanceKm);
	listings.sort((a, b) => {
		if (data.sort === "distance") return (a.distanceKm ?? 999) - (b.distanceKm ?? 999);
		if (data.sort === "price_desc") return b.priceCents - a.priceCents;
		return a.priceCents - b.priceCents;
	});
	const nameByAnchor = new Map(listings.map((listing) => [listing.standardProductId, listing.standardProductName]));
	const comparisons = comparableGroups(listings).map((group) => ({
		...group,
		name: nameByAnchor.get(group.standardProductId) ?? "Ofertas comparables"
	}));
	const categories = await db`
      select id, slug, name, parent_id, is_featured, sort_order, icon
      from categories
      where active = true
      order by is_featured desc, sort_order, name
    `;
	return {
		listings,
		comparisons,
		categories: categories.map((row) => ({
			id: row.id,
			slug: row.slug,
			name: row.name,
			parentId: row.parent_id,
			featured: row.is_featured === true,
			sortOrder: row.sort_order,
			icon: row.icon
		})),
		origin: ROSARIO
	};
});
var getListing_createServerFn_handler = createServerRpc({
	id: "5e3c309d39c92021bb234d83940e34ecd99decd8e2a7617d1813c18486ed7202",
	name: "getListing",
	filename: "src/lib/cerca/server/public.ts"
}, (opts) => getListing.__executeServer(opts));
var getListing = createServerFn({ method: "GET" }).validator((listingId) => {
	if (typeof listingId !== "string" || listingId.length > 80) throw new Error("Publicación inválida.");
	return listingId;
}).handler(getListing_createServerFn_handler, async ({ data }) => {
	const result = await searchMarketplace({ data: { inStock: true } });
	const listing = result.listings.find((item) => item.id === data || item.slug === data);
	if (!listing) throw new Error("Esa publicación no está a la venta.");
	const comparable = result.comparisons.find((group) => group.listingIds.includes(listing.id));
	const siblings = comparable ? result.listings.filter((item) => comparable.listingIds.includes(item.id) && item.id !== listing.id) : [];
	const images = await (await sql())`
      select storage_key, is_primary from listing_images
      where listing_id = ${listing.id} and status = 'ready'
      order by is_primary desc, position
    `;
	return {
		...listing,
		images: images.map((image) => imageUrl(image.storage_key)).filter((url) => Boolean(url)),
		siblings
	};
});
var getBusiness_createServerFn_handler = createServerRpc({
	id: "2cca906b0777e366fa01707ff8f41e6326b7a6364c15a7cb94b3fd62ba2b305f",
	name: "getBusiness",
	filename: "src/lib/cerca/server/public.ts"
}, (opts) => getBusiness.__executeServer(opts));
var getBusiness = createServerFn({ method: "GET" }).validator((businessId) => {
	if (typeof businessId !== "string" || businessId.length > 80) throw new Error("Negocio inválido.");
	return businessId;
}).handler(getBusiness_createServerFn_handler, async ({ data }) => {
	const db = await sql();
	const business = (await db`
      select id, trade_name, legal_name, slug, description, status, address_line, neighborhood,
        city, lat, lng, offers_delivery, offers_pickup, is_demo, verified_at::text, phone
      from businesses
      where (id = ${data} or slug = ${data}) and status = 'active' and is_demo = false
    `)[0];
	if (!business) throw new Error("Ese proveedor no está publicado.");
	const listings = await db`
      select id, name, unit, price_cents::text, stock_units, brand
      from listings
      where business_id = ${business.id} and status = 'published' and is_demo = false and stock_units > 0
      order by name
    `;
	return {
		id: business.id,
		tradeName: business.trade_name,
		legalName: business.legal_name,
		slug: business.slug,
		description: business.description,
		addressLine: business.address_line,
		neighborhood: business.neighborhood,
		city: business.city,
		lat: business.lat,
		lng: business.lng,
		offersDelivery: business.offers_delivery,
		offersPickup: business.offers_pickup,
		isDemo: business.is_demo,
		verified: Boolean(business.verified_at),
		phone: business.phone,
		listings: listings.map((listing) => ({
			id: listing.id,
			name: listing.name,
			unit: listing.unit,
			brand: listing.brand,
			priceCents: asInt(listing.price_cents),
			stockUnits: listing.stock_units
		}))
	};
});
var getPlatformStatus_createServerFn_handler = createServerRpc({
	id: "eb7a6e2652b1acce69d022bec5bb992294f4ce36f090057ad803bae6f6247612",
	name: "getPlatformStatus",
	filename: "src/lib/cerca/server/public.ts"
}, (opts) => getPlatformStatus.__executeServer(opts));
var getPlatformStatus = createServerFn({ method: "GET" }).handler(getPlatformStatus_createServerFn_handler, async () => {
	const payments = missingMercadoPagoCredentials(readMercadoPagoEnv());
	const emailMissing = [!process.env.RESEND_API_KEY ? "RESEND_API_KEY" : null, !process.env.RESEND_FROM ? "RESEND_FROM" : null].filter((item) => Boolean(item));
	const pepperReady = Boolean(process.env.CERCA_DELIVERY_PEPPER && process.env.CERCA_DELIVERY_PEPPER.length >= 16);
	const { storageMode, readStorageEnv } = await import("./storage-7VkTqUL3.mjs").then((n) => n.s);
	const mode = storageMode();
	return {
		database: dbSource === "pglite" ? "embedded_preview" : "postgres",
		demoSeedAllowed: dbSource === "pglite",
		city: "Rosario",
		payments: {
			provider: "mercadopago_split_1_1",
			configured: payments.length === 0,
			missing: payments
		},
		email: {
			configured: emailMissing.length === 0,
			missing: emailMissing
		},
		maps: activeMapTiles(),
		deliveryPepperReady: pepperReady || dbSource === "pglite",
		storage: {
			mode,
			configured: mode === "r2",
			developmentOnly: mode === "local",
			missing: mode === "r2" ? [] : [
				"S3_ENDPOINT",
				"S3_BUCKET",
				"S3_ACCESS_KEY",
				"S3_SECRET_KEY"
			],
			note: mode === "r2" ? "Las imágenes van a Cloudflare R2." : mode === "local" ? "Desarrollo: las imágenes se guardan en disco local, no en la base. En producción hace falta R2." : "No hay almacenamiento. No se puede publicar un producto con fotos.",
			endpointHost: readStorageEnv().endpoint ? "configured" : null
		},
		adminBootstrap: process.env.CERCA_BOOTSTRAP_ADMIN_EMAIL?.trim() ? "configured" : dbSource === "pglite" ? "dev_claim" : "missing",
		devMailbox: dbSource === "pglite" && !(process.env.RESEND_API_KEY?.trim() && process.env.RESEND_FROM?.trim())
	};
});
//#endregion
export { getBusiness_createServerFn_handler, getListing_createServerFn_handler, getPlatformStatus_createServerFn_handler, searchMarketplace_createServerFn_handler };
