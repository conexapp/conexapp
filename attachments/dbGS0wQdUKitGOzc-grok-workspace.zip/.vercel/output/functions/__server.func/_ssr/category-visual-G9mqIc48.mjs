import { T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Dumbbell, B as Baby, C as HeartPulse, D as Gift, E as Guitar, F as Briefcase, I as BrickWall, L as Boxes, N as Car, O as Gem, P as Building2, R as BookOpen, S as Landmark, T as Hammer, _ as Package, c as Sparkles, g as Paintbrush, h as PawPrint, j as Droplets, k as Factory, l as Sofa, n as Wrench, p as Shirt, r as UtensilsCrossed, s as Sprout, u as Smartphone, v as Mountain, w as HardHat, x as Layers } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category-visual-G9mqIc48.js
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	construccion: HardHat,
	"cementos-y-cales": Boxes,
	mamposteria: BrickWall,
	aridos: Mountain,
	hierros: Layers,
	fijaciones: Wrench,
	aislacion: Layers,
	pinturas: Paintbrush,
	sanitarios: Droplets
};
var GLYPHS = {
	technology: Smartphone,
	fashion: Shirt,
	home: Sofa,
	food: UtensilsCrossed,
	sports: Dumbbell,
	vehicles: Car,
	beauty: Sparkles,
	tools: Hammer,
	kids: Baby,
	pets: PawPrint,
	property: Building2,
	industry: Factory,
	agro: Sprout,
	health: HeartPulse,
	music: Guitar,
	books: BookOpen,
	jewelry: Gem,
	antiques: Landmark,
	parties: Gift,
	services: Briefcase
};
function glyph(icon) {
	if (!icon) return null;
	return GLYPHS[icon] ?? null;
}
function categoryIcon(slug) {
	return ICONS[slug] ?? Package;
}
var HOME_CATEGORY_LIMIT = 6;
function browseCategories(categories) {
	const featured = categories.filter((category) => category.featured && !category.parentId);
	if (featured.length > 0) return featured;
	return categories.filter((category) => !category.parentId).slice(0, HOME_CATEGORY_LIMIT);
}
function CategoryCard({ slug, name, icon, active = false, onSelect }) {
	const Glyph = glyph(icon) ?? categoryIcon(slug);
	const className = `group relative flex aspect-[4/3] w-full overflow-hidden rounded-2xl bg-[#e7f6f3] text-left shadow-card ring-2 ring-transparent transition hover:-translate-y-0.5 hover:ring-teal ${active ? "ring-ember" : ""}`;
	const body = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "grid flex-1 place-items-center text-olive",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glyph, {
			className: "size-14",
			"aria-hidden": true
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent px-3 pt-8 pb-3 text-sm font-semibold text-white",
		children: name
	})] });
	if (onSelect) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick: onSelect,
		className,
		children: body
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/",
		search: { categoria: slug },
		hash: "productos",
		className,
		children: body
	});
}
//#endregion
export { glyph as i, browseCategories as n, categoryIcon as r, CategoryCard as t };
