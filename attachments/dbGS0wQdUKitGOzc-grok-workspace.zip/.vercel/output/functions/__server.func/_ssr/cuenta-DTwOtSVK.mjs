import { o as __toESM } from "../_runtime.mjs";
import { Q as require_react, T as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { c as getMyAccount, h as useCurrentUserState, m as updateMyPhone, n as Shell, t as RedirectToSignIn, u as listNotifications } from "./shell-Dr3dYE06.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cuenta-DTwOtSVK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AccountPage() {
	const { user, isPending } = useCurrentUserState();
	const [account, setAccount] = (0, import_react.useState)(null);
	const [phone, setPhone] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		getMyAccount().then((next) => {
			setAccount(next);
			setPhone(next.phone);
		});
		listNotifications().then(setNotes);
	}, [user]);
	if (!isPending && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-4xl",
			children: "Cuenta"
		}),
		account ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-4 grid max-w-md gap-2",
			onSubmit: (event) => {
				event.preventDefault();
				updateMyPhone({ data: phone }).then(() => toast.success("Teléfono guardado.")).catch((error) => toast.error(error instanceof Error ? error.message : "No se guardó."));
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: account.name }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: account.email
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm",
					children: ["Rol de plataforma: ", account.platformRole]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: phone,
					onChange: (event) => setPhone(event.target.value),
					placeholder: "Teléfono",
					className: "min-h-12 rounded-2xl border border-line px-3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "min-h-11 rounded-full bg-ink text-paper",
					children: "Guardar teléfono"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: account.businesses.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"Lo que vendés se elige en ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/panel",
							className: "font-semibold text-ink",
							children: "Mi negocio"
						}),
						"."
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"Para vender, ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/panel",
							className: "font-semibold text-ink",
							children: "creá tu negocio"
						}),
						" y marcá una o varias categorías."
					] })
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 grid gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Avisos"
				}),
				notes.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "No hay avisos. El email sale solo si Resend está configurado; si no, queda el aviso interno."
				}) : null,
				notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: note.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: note.body
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: ["Email: ", note.email_status]
						})
					]
				}, note.id))
			]
		})
	] });
}
//#endregion
export { AccountPage as component };
