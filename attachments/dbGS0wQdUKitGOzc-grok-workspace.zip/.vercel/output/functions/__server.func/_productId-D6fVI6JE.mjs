import { o as __toESM } from "./_runtime.mjs";
import { C as useNavigate, Q as require_react, T as require_jsx_runtime, x as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { r as Route$6 } from "./_ssr/router-CiLk3dI1.mjs";
import { h as useCurrentUserState, n as Shell, s as getListing } from "./_ssr/shell-Dr3dYE06.mjs";
import { t as formatArs } from "./_ssr/money-DSc2EJ_o.mjs";
import { a as createQuoteRequest } from "./_ssr/trade-C_IUkqNG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_productId-D6fVI6JE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { productId } = Route$6.useParams();
	const navigate = useNavigate();
	const { user } = useCurrentUserState();
	const [listing, setListing] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [quantity, setQuantity] = (0, import_react.useState)(1);
	const [address, setAddress] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [delivery, setDelivery] = (0, import_react.useState)(true);
	const [photo, setPhoto] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		getListing({ data: productId }).then((next) => {
			setListing(next);
			setDelivery(next.delivery);
		}).catch((cause) => setError(cause instanceof Error ? cause.message : "No se encontró."));
	}, [productId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error }) : null, listing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "grid gap-6 md:grid-cols-[minmax(0,1fr)_22rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [listing.images[photo] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: listing.images[photo],
			alt: listing.name,
			className: "aspect-square w-full rounded-card border border-line object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid aspect-square place-items-center rounded-card border border-line bg-foam text-muted",
			children: "Sin foto"
		}), listing.images.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 flex gap-2 overflow-x-auto",
			children: listing.images.map((url, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setPhoto(index),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: url,
					alt: "",
					className: "h-16 w-16 rounded-xl object-cover"
				})
			}, url))
		}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: listing.categoryName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-4xl",
				children: listing.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-muted",
				children: [
					listing.brand,
					" ",
					listing.sku ? `· SKU ${listing.sku}` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 font-display text-4xl tabular-nums",
				children: [
					formatArs(listing.priceCents),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-lg text-muted",
						children: ["/ ", listing.unit]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm",
				children: [
					"Stock ",
					listing.stockUnits,
					". ",
					listing.delivery ? "Entrega" : "Sin entrega",
					". ",
					listing.pickup ? "Retiro" : "Sin retiro",
					"."
				]
			}),
			listing.delivery ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Envío publicado: ",
					formatArs(listing.shippingCents),
					". El plazo estimado es ",
					listing.leadTimeHours ?? "a confirmar",
					" horas."
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl",
				children: listing.description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm",
				children: [
					"Proveedor: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/negocio/$businessId",
						params: { businessId: listing.businessId },
						className: "text-olive",
						children: listing.businessName
					}),
					listing.reviewCount > 0 && listing.avgRating !== null ? ` · ${listing.avgRating.toFixed(1)}` : " · sin calificaciones"
				]
			}),
			listing.siblings.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl",
					children: "Otras ofertas de la misma ancla"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 grid gap-1 text-sm",
					children: listing.siblings.map((sibling) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/producto/$productId",
						params: { productId: sibling.id },
						children: [
							sibling.businessName,
							" · ",
							formatArs(sibling.priceCents),
							" · stock ",
							sibling.stockUnits
						]
					}) }, sibling.id))
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-4 grid gap-2",
				onSubmit: (event) => {
					event.preventDefault();
					if (!user) {
						navigate({ to: "/login" });
						return;
					}
					createQuoteRequest({ data: {
						listingId: listing.id,
						quantity,
						notes,
						address,
						delivery
					} }).then(async () => {
						toast.success("Solicitud enviada a este proveedor.");
						await navigate({ to: "/cotizaciones" });
					}).catch((cause) => toast.error(cause instanceof Error ? cause.message : "No se envió."));
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl",
						children: "Pedir cotización"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "number",
						min: 1,
						max: listing.stockUnits,
						value: quantity,
						onChange: (event) => setQuantity(Number(event.target.value)),
						className: "min-h-11 rounded-2xl border border-line px-3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: delivery,
							onChange: (event) => setDelivery(event.target.checked)
						}), "Quiero entrega"]
					}),
					delivery ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: address,
						onChange: (event) => setAddress(event.target.value),
						placeholder: "Dirección en Rosario",
						className: "min-h-11 rounded-2xl border border-line px-3"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: notes,
						onChange: (event) => setNotes(event.target.value),
						placeholder: "Aclaraciones",
						className: "min-h-20 rounded-2xl border border-line px-3 py-2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "min-h-11 rounded-full bg-copper text-ink",
						children: user ? "Enviar al proveedor" : "Entrá para cotizar"
					})
				]
			})
		] })]
	}) : null] });
}
//#endregion
export { ProductPage as component };
