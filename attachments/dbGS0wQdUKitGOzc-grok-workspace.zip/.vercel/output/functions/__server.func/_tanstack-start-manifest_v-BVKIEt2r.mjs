//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BVKIEt2r.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/categorias",
			"/cotizaciones",
			"/cotizar",
			"/cuenta",
			"/login",
			"/proteccion",
			"/restablecer",
			"/negocio/$businessId",
			"/pedidos/$orderId",
			"/producto/$productId",
			"/panel/",
			"/pedidos/",
			"/api/auth/$",
			"/api/media/$",
			"/panel/productos/$listingId",
			"/panel/productos/",
			"/api/payments/mercadopago/callback",
			"/api/payments/mercadopago/"
		],
		preloads: [
			"/assets/index-BQ2DH5Z7.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/react-Cvdyeg_0.js",
			"/assets/preload-helper-D46jHsBr.js",
			"/assets/lazyRouteComponent-NkIs74su.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BQ2DH5Z7.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/market-map-vh-t_kPv.css"],
		preloads: [
			"/assets/routes-BG938SyN.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/category-visual-BcnX6FIh.js",
			"/assets/market-map-INtxeJN5.js",
			"/assets/money-Cpog6LoH.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-CrGdKmRU.js", "/assets/shell-CvtbMNdu.js"]
	},
	"/categorias": {
		filePath: "/workspace/src/routes/categorias.tsx",
		children: void 0,
		preloads: [
			"/assets/categorias--0qZXzpU.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/category-visual-BcnX6FIh.js"
		]
	},
	"/cotizaciones": {
		filePath: "/workspace/src/routes/cotizaciones.tsx",
		children: void 0,
		preloads: [
			"/assets/cotizaciones-V7Y20-NB.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/trade-BtObTqbk.js",
			"/assets/money-Cpog6LoH.js"
		]
	},
	"/cotizar": {
		filePath: "/workspace/src/routes/cotizar.tsx",
		children: void 0,
		preloads: ["/assets/cotizar-iiKw9UYh.js", "/assets/shell-CvtbMNdu.js"]
	},
	"/cuenta": {
		filePath: "/workspace/src/routes/cuenta.tsx",
		children: void 0,
		preloads: ["/assets/cuenta-BcQmkNSx.js", "/assets/shell-CvtbMNdu.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-eh232SIG.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/client-BXBH9Po-.js"
		]
	},
	"/proteccion": {
		filePath: "/workspace/src/routes/proteccion.tsx",
		children: void 0,
		preloads: ["/assets/proteccion-BMtxIWRo.js", "/assets/shell-CvtbMNdu.js"]
	},
	"/restablecer": {
		filePath: "/workspace/src/routes/restablecer.tsx",
		children: void 0,
		preloads: [
			"/assets/restablecer-CCdveDQ9.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/client-BXBH9Po-.js"
		]
	},
	"/negocio/$businessId": {
		filePath: "/workspace/src/routes/negocio/$businessId.tsx",
		children: void 0,
		css: ["/assets/market-map-vh-t_kPv.css"],
		preloads: [
			"/assets/_businessId-DuzAPFVR.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/market-map-INtxeJN5.js",
			"/assets/money-Cpog6LoH.js"
		]
	},
	"/pedidos/$orderId": {
		filePath: "/workspace/src/routes/pedidos/$orderId.tsx",
		children: void 0,
		preloads: [
			"/assets/_orderId-NmtBiC3m.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/trade-BtObTqbk.js",
			"/assets/money-Cpog6LoH.js"
		]
	},
	"/producto/$productId": {
		filePath: "/workspace/src/routes/producto/$productId.tsx",
		children: void 0,
		preloads: [
			"/assets/_productId-CwmXQKCa.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/trade-BtObTqbk.js",
			"/assets/money-Cpog6LoH.js"
		]
	},
	"/panel/": {
		filePath: "/workspace/src/routes/panel/index.tsx",
		children: void 0,
		preloads: [
			"/assets/panel-Y5abj976.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/category-visual-BcnX6FIh.js",
			"/assets/geo-Be8eYLHL.js",
			"/assets/trade-BtObTqbk.js",
			"/assets/money-Cpog6LoH.js"
		]
	},
	"/pedidos/": {
		filePath: "/workspace/src/routes/pedidos/index.tsx",
		children: void 0,
		preloads: [
			"/assets/pedidos-C-_HsIvu.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/trade-BtObTqbk.js",
			"/assets/money-Cpog6LoH.js"
		]
	},
	"/panel/productos/$listingId": {
		filePath: "/workspace/src/routes/panel/productos/$listingId.tsx",
		children: void 0,
		preloads: [
			"/assets/_listingId-W0bWWiL0.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/money-Cpog6LoH.js",
			"/assets/listings-Dz4WPPh1.js"
		]
	},
	"/panel/productos/": {
		filePath: "/workspace/src/routes/panel/productos/index.tsx",
		children: void 0,
		preloads: [
			"/assets/productos-TKSFjMHA.js",
			"/assets/shell-CvtbMNdu.js",
			"/assets/money-Cpog6LoH.js",
			"/assets/listings-Dz4WPPh1.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
