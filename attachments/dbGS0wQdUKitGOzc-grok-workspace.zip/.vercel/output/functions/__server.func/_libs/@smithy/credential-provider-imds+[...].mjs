import { r as __exportAll } from "../../_runtime.mjs";
import { d as require_config, o as require_protocols } from "../@aws-sdk/checksums+[...].mjs";
import node_http from "node:http";
//#region node_modules/@smithy/credential-provider-imds/dist-es/remoteProvider/ImdsCredentials.js
var import_config = require_config();
var isImdsCredentials = (arg) => Boolean(arg) && typeof arg === "object" && typeof arg.AccessKeyId === "string" && typeof arg.SecretAccessKey === "string" && typeof arg.Token === "string" && typeof arg.Expiration === "string";
var fromImdsCredentials = (creds) => ({
	accessKeyId: creds.AccessKeyId,
	secretAccessKey: creds.SecretAccessKey,
	sessionToken: creds.Token,
	expiration: new Date(creds.Expiration),
	...creds.AccountId && { accountId: creds.AccountId }
});
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/remoteProvider/RemoteProviderInit.js
var DEFAULT_TIMEOUT = 1e3;
var providerConfigFromInit = ({ maxRetries = 0, timeout = DEFAULT_TIMEOUT }) => ({
	maxRetries,
	timeout
});
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/remoteProvider/httpRequest.js
function httpRequest(options) {
	return new Promise((resolve, reject) => {
		const req = node_http.request({
			method: "GET",
			...options,
			hostname: options.hostname?.replace(/^\[(.+)\]$/, "$1")
		});
		req.on("error", (err) => {
			reject(Object.assign(new import_config.ProviderError("Unable to connect to instance metadata service"), err));
			req.destroy();
		});
		req.on("timeout", () => {
			reject(new import_config.ProviderError("TimeoutError from instance metadata service"));
			req.destroy();
		});
		req.on("response", (res) => {
			const { statusCode = 400 } = res;
			if (statusCode < 200 || 300 <= statusCode) {
				reject(Object.assign(new import_config.ProviderError("Error response received from instance metadata service"), { statusCode }));
				req.destroy();
			}
			const chunks = [];
			res.on("data", (chunk) => {
				chunks.push(chunk);
			});
			res.on("end", () => {
				resolve(Buffer.concat(chunks));
				req.destroy();
			});
		});
		req.end();
	});
}
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/remoteProvider/retry.js
var retry = (toRetry, maxRetries) => {
	let promise = toRetry();
	for (let i = 0; i < maxRetries; i++) promise = promise.catch(toRetry);
	return promise;
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/fromContainerMetadata.js
var ENV_CMDS_FULL_URI = "AWS_CONTAINER_CREDENTIALS_FULL_URI";
var ENV_CMDS_RELATIVE_URI = "AWS_CONTAINER_CREDENTIALS_RELATIVE_URI";
var ENV_CMDS_AUTH_TOKEN = "AWS_CONTAINER_AUTHORIZATION_TOKEN";
var fromContainerMetadata = (init = {}) => {
	const { timeout, maxRetries } = providerConfigFromInit(init);
	return () => retry(async () => {
		const requestOptions = await getCmdsUri({ logger: init.logger });
		const credsResponse = JSON.parse(await requestFromEcsImds(timeout, requestOptions));
		if (!isImdsCredentials(credsResponse)) throw new import_config.CredentialsProviderError("Invalid response received from instance metadata service.", { logger: init.logger });
		return fromImdsCredentials(credsResponse);
	}, maxRetries);
};
var requestFromEcsImds = async (timeout, options) => {
	if (process.env["AWS_CONTAINER_AUTHORIZATION_TOKEN"]) options.headers = {
		...options.headers,
		Authorization: process.env[ENV_CMDS_AUTH_TOKEN]
	};
	return (await httpRequest({
		...options,
		timeout
	})).toString();
};
var CMDS_IP = "169.254.170.2";
var GREENGRASS_HOSTS = /* @__PURE__ */ new Set(["localhost", "127.0.0.1"]);
var GREENGRASS_PROTOCOLS = /* @__PURE__ */ new Set(["http:", "https:"]);
var getCmdsUri = async ({ logger }) => {
	if (process.env["AWS_CONTAINER_CREDENTIALS_RELATIVE_URI"]) return {
		hostname: CMDS_IP,
		path: process.env[ENV_CMDS_RELATIVE_URI]
	};
	if (process.env["AWS_CONTAINER_CREDENTIALS_FULL_URI"]) {
		let parsed;
		try {
			parsed = new URL(process.env[ENV_CMDS_FULL_URI]);
		} catch {
			throw new import_config.CredentialsProviderError(`${process.env[ENV_CMDS_FULL_URI]} is not a valid container metadata service URL`, {
				tryNextLink: false,
				logger
			});
		}
		if (!parsed.hostname || !GREENGRASS_HOSTS.has(parsed.hostname)) throw new import_config.CredentialsProviderError(`${parsed.hostname} is not a valid container metadata service hostname`, {
			tryNextLink: false,
			logger
		});
		if (!parsed.protocol || !GREENGRASS_PROTOCOLS.has(parsed.protocol)) throw new import_config.CredentialsProviderError(`${parsed.protocol} is not a valid container metadata service protocol`, {
			tryNextLink: false,
			logger
		});
		return {
			protocol: parsed.protocol,
			hostname: parsed.hostname,
			path: parsed.pathname + parsed.search,
			port: parsed.port ? parseInt(parsed.port, 10) : void 0
		};
	}
	throw new import_config.CredentialsProviderError(`The container metadata credential provider cannot be used unless the ${ENV_CMDS_RELATIVE_URI} or ${ENV_CMDS_FULL_URI} environment variable is set`, {
		tryNextLink: false,
		logger
	});
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/error/InstanceMetadataV1FallbackError.js
var InstanceMetadataV1FallbackError = class InstanceMetadataV1FallbackError extends import_config.CredentialsProviderError {
	tryNextLink;
	name = "InstanceMetadataV1FallbackError";
	constructor(message, tryNextLink = true) {
		super(message, tryNextLink);
		this.tryNextLink = tryNextLink;
		Object.setPrototypeOf(this, InstanceMetadataV1FallbackError.prototype);
	}
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/config/Endpoint.js
var import_protocols = require_protocols();
var Endpoint;
(function(Endpoint) {
	Endpoint["IPv4"] = "http://169.254.169.254";
	Endpoint["IPv6"] = "http://[fd00:ec2::254]";
})(Endpoint || (Endpoint = {}));
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/config/EndpointConfigOptions.js
var ENV_ENDPOINT_NAME = "AWS_EC2_METADATA_SERVICE_ENDPOINT";
var CONFIG_ENDPOINT_NAME = "ec2_metadata_service_endpoint";
var ENDPOINT_CONFIG_OPTIONS = {
	environmentVariableSelector: (env) => env[ENV_ENDPOINT_NAME],
	configFileSelector: (profile) => profile[CONFIG_ENDPOINT_NAME],
	default: void 0
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/config/EndpointMode.js
var EndpointMode;
(function(EndpointMode) {
	EndpointMode["IPv4"] = "IPv4";
	EndpointMode["IPv6"] = "IPv6";
})(EndpointMode || (EndpointMode = {}));
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/config/EndpointModeConfigOptions.js
var ENV_ENDPOINT_MODE_NAME = "AWS_EC2_METADATA_SERVICE_ENDPOINT_MODE";
var CONFIG_ENDPOINT_MODE_NAME = "ec2_metadata_service_endpoint_mode";
var ENDPOINT_MODE_CONFIG_OPTIONS = {
	environmentVariableSelector: (env) => env[ENV_ENDPOINT_MODE_NAME],
	configFileSelector: (profile) => profile[CONFIG_ENDPOINT_MODE_NAME],
	default: EndpointMode.IPv4
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/utils/getInstanceMetadataEndpoint.js
var getInstanceMetadataEndpoint = async () => (0, import_protocols.parseUrl)(await getFromEndpointConfig() || await getFromEndpointModeConfig());
var getFromEndpointConfig = async () => (0, import_config.loadConfig)(ENDPOINT_CONFIG_OPTIONS)();
var getFromEndpointModeConfig = async () => {
	const endpointMode = await (0, import_config.loadConfig)(ENDPOINT_MODE_CONFIG_OPTIONS)();
	switch (endpointMode) {
		case EndpointMode.IPv4: return Endpoint.IPv4;
		case EndpointMode.IPv6: return Endpoint.IPv6;
		default: throw new Error(`Unsupported endpoint mode: ${endpointMode}. Select from ${Object.values(EndpointMode)}`);
	}
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/utils/getExtendedInstanceMetadataCredentials.js
var STATIC_STABILITY_REFRESH_INTERVAL_SECONDS = 300;
var STATIC_STABILITY_REFRESH_INTERVAL_JITTER_WINDOW_SECONDS = 300;
var getExtendedInstanceMetadataCredentials = (credentials, logger) => {
	const refreshInterval = STATIC_STABILITY_REFRESH_INTERVAL_SECONDS + Math.floor(Math.random() * STATIC_STABILITY_REFRESH_INTERVAL_JITTER_WINDOW_SECONDS);
	const newExpiration = new Date(Date.now() + refreshInterval * 1e3);
	logger.warn(`Attempting credential expiration extension due to a credential service availability issue. A refresh of these credentials will be attempted after ${new Date(newExpiration)}.\nFor more information, please visit: https://docs.aws.amazon.com/sdkref/latest/guide/feature-static-credentials.html`);
	const originalExpiration = credentials.originalExpiration ?? credentials.expiration;
	return {
		...credentials,
		...originalExpiration ? { originalExpiration } : {},
		expiration: newExpiration
	};
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/utils/staticStabilityProvider.js
var staticStabilityProvider = (provider, options = {}) => {
	const logger = options?.logger || console;
	let pastCredentials;
	return async () => {
		let credentials;
		try {
			credentials = await provider();
			if (credentials.expiration && credentials.expiration.getTime() < Date.now()) credentials = getExtendedInstanceMetadataCredentials(credentials, logger);
		} catch (e) {
			if (pastCredentials) {
				logger.warn("Credential renew failed: ", e);
				credentials = getExtendedInstanceMetadataCredentials(pastCredentials, logger);
			} else throw e;
		}
		pastCredentials = credentials;
		return credentials;
	};
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/fromInstanceMetadata.js
var IMDS_PATH = "/latest/meta-data/iam/security-credentials/";
var IMDS_TOKEN_PATH = "/latest/api/token";
var AWS_EC2_METADATA_V1_DISABLED = "AWS_EC2_METADATA_V1_DISABLED";
var PROFILE_AWS_EC2_METADATA_V1_DISABLED = "ec2_metadata_v1_disabled";
var X_AWS_EC2_METADATA_TOKEN = "x-aws-ec2-metadata-token";
var fromInstanceMetadata = (init = {}) => staticStabilityProvider(getInstanceMetadataProvider(init), { logger: init.logger });
var getInstanceMetadataProvider = (init = {}) => {
	let disableFetchToken = false;
	const { logger, profile } = init;
	const { timeout, maxRetries } = providerConfigFromInit(init);
	const getCredentials = async (maxRetries, options) => {
		if (disableFetchToken || options.headers?.[X_AWS_EC2_METADATA_TOKEN] == null) {
			let fallbackBlockedFromProfile = false;
			let fallbackBlockedFromProcessEnv = false;
			const configValue = await (0, import_config.loadConfig)({
				environmentVariableSelector: (env) => {
					const envValue = env[AWS_EC2_METADATA_V1_DISABLED];
					fallbackBlockedFromProcessEnv = !!envValue && envValue !== "false";
					if (envValue === void 0) throw new import_config.CredentialsProviderError(`${AWS_EC2_METADATA_V1_DISABLED} not set in env, checking config file next.`, { logger: init.logger });
					return fallbackBlockedFromProcessEnv;
				},
				configFileSelector: (profile) => {
					const profileValue = profile[PROFILE_AWS_EC2_METADATA_V1_DISABLED];
					fallbackBlockedFromProfile = !!profileValue && profileValue !== "false";
					return fallbackBlockedFromProfile;
				},
				default: false
			}, { profile })();
			if (init.ec2MetadataV1Disabled || configValue) {
				const causes = [];
				if (init.ec2MetadataV1Disabled) causes.push("credential provider initialization (runtime option ec2MetadataV1Disabled)");
				if (fallbackBlockedFromProfile) causes.push(`config file profile (${PROFILE_AWS_EC2_METADATA_V1_DISABLED})`);
				if (fallbackBlockedFromProcessEnv) causes.push(`process environment variable (${AWS_EC2_METADATA_V1_DISABLED})`);
				throw new InstanceMetadataV1FallbackError(`AWS EC2 Metadata v1 fallback has been blocked by AWS SDK configuration in the following: [${causes.join(", ")}].`);
			}
		}
		const imdsProfile = (await retry(async () => {
			let profile;
			try {
				profile = await getProfile(options);
			} catch (err) {
				if (err.statusCode === 401) disableFetchToken = false;
				throw err;
			}
			return profile;
		}, maxRetries)).trim();
		return retry(async () => {
			let creds;
			try {
				creds = await getCredentialsFromProfile(imdsProfile, options, init);
			} catch (err) {
				if (err.statusCode === 401) disableFetchToken = false;
				throw err;
			}
			return creds;
		}, maxRetries);
	};
	return async () => {
		const endpoint = await getInstanceMetadataEndpoint();
		if (disableFetchToken) {
			logger?.debug("AWS SDK Instance Metadata", "using v1 fallback (no token fetch)");
			return getCredentials(maxRetries, {
				...endpoint,
				timeout
			});
		} else {
			let token;
			try {
				token = (await getMetadataToken({
					...endpoint,
					timeout
				})).toString();
			} catch (error) {
				if (error?.statusCode === 400) throw Object.assign(error, { message: "EC2 Metadata token request returned error" });
				else if (error.message === "TimeoutError" || [
					403,
					404,
					405
				].includes(error.statusCode)) disableFetchToken = true;
				logger?.debug("AWS SDK Instance Metadata", "using v1 fallback (initial)");
				return getCredentials(maxRetries, {
					...endpoint,
					timeout
				});
			}
			return getCredentials(maxRetries, {
				...endpoint,
				headers: { [X_AWS_EC2_METADATA_TOKEN]: token },
				timeout
			});
		}
	};
};
var getMetadataToken = async (options) => httpRequest({
	...options,
	path: IMDS_TOKEN_PATH,
	method: "PUT",
	headers: { "x-aws-ec2-metadata-token-ttl-seconds": "21600" }
});
var getProfile = async (options) => (await httpRequest({
	...options,
	path: IMDS_PATH
})).toString();
var getCredentialsFromProfile = async (profile, options, init) => {
	const credentialsResponse = JSON.parse((await httpRequest({
		...options,
		path: IMDS_PATH + profile
	})).toString());
	if (!isImdsCredentials(credentialsResponse)) throw new import_config.CredentialsProviderError("Invalid response received from instance metadata service.", { logger: init.logger });
	return fromImdsCredentials(credentialsResponse);
};
//#endregion
//#region node_modules/@smithy/credential-provider-imds/dist-es/index.js
var dist_es_exports = /* @__PURE__ */ __exportAll({
	DEFAULT_MAX_RETRIES: () => 0,
	DEFAULT_TIMEOUT: () => DEFAULT_TIMEOUT,
	ENV_CMDS_AUTH_TOKEN: () => ENV_CMDS_AUTH_TOKEN,
	ENV_CMDS_FULL_URI: () => ENV_CMDS_FULL_URI,
	ENV_CMDS_RELATIVE_URI: () => ENV_CMDS_RELATIVE_URI,
	fromContainerMetadata: () => fromContainerMetadata,
	fromInstanceMetadata: () => fromInstanceMetadata
});
//#endregion
export { dist_es_exports as t };
