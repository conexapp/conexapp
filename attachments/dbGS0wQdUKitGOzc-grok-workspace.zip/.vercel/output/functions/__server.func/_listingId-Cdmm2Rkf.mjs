import { o as __toESM } from "./_runtime.mjs";
import { C as useNavigate, Q as require_react, T as require_jsx_runtime } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { n as Route$2 } from "./_ssr/router-CiLk3dI1.mjs";
import { c as getMyAccount, h as useCurrentUserState, n as Shell, t as RedirectToSignIn } from "./_ssr/shell-Dr3dYE06.mjs";
import { n as parseArsToCents, t as formatArs } from "./_ssr/money-DSc2EJ_o.mjs";
import { a as listListingOptions, c as prepareListingImage, d as saveListingImage, f as setListingStatus, i as getMyListing, l as publishListing, m as updateListing, n as createListing, p as setPrimaryImage, r as deleteListingImage, s as moveListingImage, t as confirmListingImage, u as removeListing } from "./_ssr/listings-BiGD_4Eb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_listingId-Cdmm2Rkf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EditorPage() {
	const { listingId } = Route$2.useParams();
	const creating = listingId === "nuevo";
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [options, setOptions] = (0, import_react.useState)(null);
	const [businessId, setBusinessId] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [brand, setBrand] = (0, import_react.useState)("");
	const [model, setModel] = (0, import_react.useState)("");
	const [sku, setSku] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [categoryId, setCategoryId] = (0, import_react.useState)("");
	const [standardProductId, setStandardProductId] = (0, import_react.useState)("");
	const [price, setPrice] = (0, import_react.useState)("");
	const [unit, setUnit] = (0, import_react.useState)("unidad");
	const [stock, setStock] = (0, import_react.useState)(0);
	const [minStock, setMinStock] = (0, import_react.useState)(0);
	const [pickup, setPickup] = (0, import_react.useState)(true);
	const [delivery, setDelivery] = (0, import_react.useState)(false);
	const [shipping, setShipping] = (0, import_react.useState)("0");
	const [hours, setHours] = (0, import_react.useState)(48);
	const [status, setStatus] = (0, import_react.useState)("draft");
	const [images, setImages] = (0, import_react.useState)([]);
	function payload(priceCents, shippingCents) {
		return {
			businessId,
			name,
			description,
			brand,
			model,
			sku,
			categoryId,
			standardProductId: standardProductId || null,
			priceCents,
			unit,
			referenceUnit: "",
			referencePriceCents: null,
			stockUnits: stock,
			minStock,
			pickup,
			delivery,
			shippingCents,
			leadTimeHours: hours
		};
	}
	async function reload(id = listingId) {
		if (id === "nuevo") return;
		const listing = await getMyListing({ data: id });
		setBusinessId(listing.business_id);
		setName(listing.name);
		setBrand(listing.brand);
		setModel(listing.model);
		setSku(listing.sku);
		setDescription(listing.description);
		setCategoryId(listing.category_id);
		setStandardProductId(listing.standard_product_id ?? "");
		setPrice(centsToInput(listing.priceCents));
		setUnit(listing.unit);
		setStock(listing.stock_units);
		setMinStock(listing.min_stock);
		setPickup(listing.pickup);
		setDelivery(listing.delivery);
		setShipping(centsToInput(listing.shippingCents));
		setHours(listing.lead_time_hours ?? 48);
		setStatus(listing.status);
		setImages(listing.images);
	}
	(0, import_react.useEffect)(() => {
		if (!user) return;
		listListingOptions().then(setOptions);
		getMyAccount().then((account) => {
			if (creating && account.businesses[0]) setBusinessId(account.businesses[0].id);
		});
		if (!creating) reload().catch((error) => toast.error(error instanceof Error ? error.message : "No se pudo abrir."));
	}, [user, listingId]);
	if (!isPending && !user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	async function save(publish) {
		const priceCents = parseArsToCents(price);
		const shippingCents = parseArsToCents(shipping) ?? (shipping.trim() === "0" ? 0 : null);
		if (!priceCents || shippingCents === null) {
			toast.error("Revisá precio y envío.");
			return;
		}
		const body = payload(priceCents, shippingCents);
		try {
			if (creating) {
				const created = await createListing({ data: body });
				toast.success("Borrador guardado. Ahora podés subir las fotos.");
				await navigate({
					to: "/panel/productos/$listingId",
					params: { listingId: created.id }
				});
				return;
			}
			const updated = await updateListing({ data: {
				listingId,
				...body
			} });
			setStatus(updated.status);
			if (publish) {
				const published = await publishListing({ data: listingId });
				setStatus(published.status);
				toast.success("Producto publicado.");
			} else toast.success("Cambios guardados. Los pedidos anteriores no cambian.");
			await reload();
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "No se guardó.");
		}
	}
	async function upload(file) {
		if (creating) {
			toast.error("Guardá el borrador antes de subir fotos.");
			return;
		}
		const prepared = await prepareListingImage({ data: {
			listingId,
			contentType: file.type || "application/octet-stream",
			byteSize: file.size
		} });
		if (prepared.mode === "direct") {
			const base64 = await fileToBase64(file);
			await saveListingImage({ data: {
				imageId: prepared.imageId,
				base64
			} });
		} else {
			if (!(await fetch(prepared.uploadUrl, {
				method: "PUT",
				headers: prepared.headers,
				body: file
			})).ok) throw new Error("El almacenamiento rechazó la imagen.");
			await confirmListingImage({ data: prepared.imageId });
		}
		await reload();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: creating ? "Nuevo borrador" : `Estado: ${status}`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mb-4 text-4xl",
			children: creating ? "Agregar producto" : name || "Editar producto"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				save(false);
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusinessSelect, {
					businessId,
					onChange: setBusinessId,
					disabled: !creating
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					required: true,
					value: name,
					onChange: (event) => setName(event.target.value),
					placeholder: "Nombre del producto",
					className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: brand,
							onChange: (event) => setBrand(event.target.value),
							placeholder: "Marca",
							className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: model,
							onChange: (event) => setModel(event.target.value),
							placeholder: "Modelo",
							className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: sku,
							onChange: (event) => setSku(event.target.value),
							placeholder: "SKU / código interno",
							className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: description,
					onChange: (event) => setDescription(event.target.value),
					placeholder: "Descripción",
					className: "min-h-28 rounded-2xl border border-line bg-foam px-3 py-2"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					required: true,
					value: categoryId,
					onChange: (event) => setCategoryId(event.target.value),
					className: "min-h-11 rounded-2xl border border-line bg-foam px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Categoría"
					}), options?.categories.map((category) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: category.id,
						children: [
							category.parent_name,
							" → ",
							category.name
						]
					}, category.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: standardProductId,
					onChange: (event) => setStandardProductId(event.target.value),
					className: "min-h-11 rounded-2xl border border-line bg-foam px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Sin ancla de comparación"
					}), options?.standards.map((standard) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: standard.id,
						children: [
							standard.name,
							" (",
							standard.unit,
							") — no es tu producto"
						]
					}, standard.id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-2 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: price,
							onChange: (event) => setPrice(event.target.value),
							placeholder: "Precio, por ejemplo 10500",
							className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							value: unit,
							onChange: (event) => setUnit(event.target.value),
							placeholder: "Unidad: bolsa, m3, unidad",
							className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: 0,
							value: stock,
							onChange: (event) => setStock(Number(event.target.value)),
							className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: 0,
							value: minStock,
							onChange: (event) => setMinStock(Number(event.target.value)),
							placeholder: "Stock mínimo",
							className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: pickup,
						onChange: (event) => setPickup(event.target.checked)
					}), "Retiro en el local"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex min-h-11 items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: delivery,
						onChange: (event) => setDelivery(event.target.checked)
					}), "Envío"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: shipping,
					onChange: (event) => setShipping(event.target.value),
					placeholder: "Costo de envío",
					className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "number",
					min: 0,
					value: hours,
					onChange: (event) => setHours(Number(event.target.value)),
					className: "min-h-11 rounded-2xl border border-line bg-foam px-3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [
						"Almacenamiento: ",
						options?.storage === "r2" ? "Cloudflare R2" : options?.storage === "local" ? "disco local de desarrollo" : "no configurado",
						". JPEG, PNG o WebP, hasta 4 MB y 8 fotos."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "min-h-11 rounded-full bg-ink px-4 text-paper",
						children: "Guardar borrador"
					}), !creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-full bg-copper px-4 text-ink",
						onClick: () => void save(true),
						children: "Publicar"
					}) : null]
				})
			]
		}),
		!creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 grid gap-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl",
					children: "Imágenes"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "image/jpeg,image/png,image/webp",
					className: "text-sm",
					onChange: (event) => {
						const file = event.target.files?.[0];
						event.target.value = "";
						if (!file) return;
						upload(file).catch((error) => toast.error(error instanceof Error ? error.message : "No se subió."));
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: images.map((image) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center gap-2 rounded-2xl border border-line p-2",
						children: [
							image.url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: image.url,
								alt: "",
								className: "h-16 w-16 rounded-xl object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: "Pendiente"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: image.isPrimary ? "Principal" : image.status
							}),
							image.status === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-10 rounded-full border border-line px-3",
								onClick: () => void setPrimaryImage({ data: image.id }).then(() => reload()),
								children: "Principal"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-10 rounded-full border border-line px-3",
								onClick: () => void moveListingImage({ data: {
									imageId: image.id,
									direction: "up"
								} }).then(() => reload()),
								children: "Subir"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-10 rounded-full border border-line px-3",
								onClick: () => void moveListingImage({ data: {
									imageId: image.id,
									direction: "down"
								} }).then(() => reload()),
								children: "Bajar"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "min-h-10 rounded-full border border-line px-3",
								onClick: () => void deleteListingImage({ data: image.id }).then(() => reload()).catch((error) => toast.error(error instanceof Error ? error.message : "No se borró.")),
								children: "Quitar"
							})
						]
					}, image.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						status === "published" || status === "out_of_stock" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-full border border-ink px-4",
							onClick: () => void setListingStatus({ data: {
								listingId,
								action: "pause"
							} }).then(() => reload()),
							children: "Pausar"
						}) : null,
						status === "paused" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-full bg-olive px-4 text-ink",
							onClick: () => void setListingStatus({ data: {
								listingId,
								action: "reactivate"
							} }).then(() => reload()).catch((error) => toast.error(error instanceof Error ? error.message : "No se reactivó.")),
							children: "Reactivar"
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "min-h-11 rounded-full border border-line px-4",
							onClick: () => {
								removeListing({ data: listingId }).then(async (result) => {
									toast.message(result.message);
									if (result.deleted) await navigate({ to: "/panel/productos" });
									else await reload();
								}).catch((error) => toast.error(error instanceof Error ? error.message : "No se eliminó."));
							},
							children: "Eliminar"
						})
					]
				}),
				price ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Precio actual de la publicación: ",
						formatArs(parseArsToCents(price) ?? 0),
						". Un pedido ya creado conserva el precio del momento de la compra."
					]
				}) : null
			]
		}) : null
	] });
}
function BusinessSelect({ businessId, onChange, disabled }) {
	const [businesses, setBusinesses] = (0, import_react.useState)([]);
	(0, import_react.useEffect)(() => {
		getMyAccount().then((account) => setBusinesses(account.businesses));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		required: true,
		value: businessId,
		onChange: (event) => onChange(event.target.value),
		className: "min-h-11 rounded-2xl border border-line bg-foam px-3",
		disabled,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			children: "Elegí el negocio"
		}), businesses.map((business) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
			value: business.id,
			children: [
				business.trade_name,
				" (",
				business.status,
				")"
			]
		}, business.id))]
	});
}
function centsToInput(cents) {
	const whole = Math.trunc(cents / 100);
	const frac = Math.abs(cents % 100);
	if (frac === 0) return String(whole);
	return `${whole},${String(frac).padStart(2, "0")}`;
}
function fileToBase64(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onerror = () => reject(/* @__PURE__ */ new Error("No se pudo leer la imagen."));
		reader.onload = () => {
			const encoded = String(reader.result ?? "").split(",")[1];
			if (!encoded) reject(/* @__PURE__ */ new Error("No se pudo leer la imagen."));
			else resolve(encoded);
		};
		reader.readAsDataURL(file);
	});
}
//#endregion
export { EditorPage as component };
