# Cerca

Marketplace de proveedores para Rosario. La primera vertical es ferretería y materiales de construcción.

Propuesta: encontrar proveedores cerca, comparar ofertas del mismo producto y comprar con protección.

## Qué está operativo

- Cuentas reales (email y contraseña, Google, X), perfiles y roles.
- Catálogo canónico separado de la oferta de cada proveedor.
- Alta de negocio, ubicación, precio y stock. Un negocio nuevo no se publica hasta que un administrador lo aprueba.
- Búsqueda con filtros y mapa de proveedores activos.
- Cotizaciones: solicitud, respuesta, aceptación y pedido en `PENDING_PAYMENT`.
- Comisión configurable, congelada en cada pedido.
- Estados de pedido con reglas en el servidor, código de entrega de un solo uso e historial.
- Disputas con motivo, texto y mensajes. El reembolso no se simula.
- Pagos: Mercado Pago Split 1:1 queda preparado y falla cerrado si faltan credenciales.

## Qué no está conectado

Mercado Pago, Resend y almacenamiento de fotos. La pantalla Administración lo dice con las variables que faltan. No hay un botón de “pago exitoso”.

## Datos de ejemplo

El catálogo (cemento, ladrillos, etc.) es la taxonomía inicial del rubro. Los negocios de ejemplo solo se pueden cargar en la base de desarrollo, quedan marcados y no tienen clave para entrar.

## Documentación

[docs/ARQUITECTURA.md](docs/ARQUITECTURA.md)
