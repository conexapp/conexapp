import { createServerFn } from "@tanstack/react-start";
import { dbSource } from "@/lib/db";
import { distanceKm, ROSARIO } from "../domain/geo";
import { comparableGroups } from "../domain/listings";
import { fold, likeContains } from "../domain/text";
import { missingMercadoPagoCredentials, readMercadoPagoEnv } from "../payments/mercadopago";
import { activeMapTiles } from "../maps";
import { asInt, sql } from "./helpers";

export type ListingHit = {
  id: string;
  name: string;
  slug: string;
  brand: string;
  sku: string;
  unit: string;
  description: string;
  priceCents: number;
  stockUnits: number;
  delivery: boolean;
  pickup: boolean;
  shippingCents: number;
  leadTimeHours: number | null;
  categoryName: string;
  categorySlug: string;
  standardProductId: string | null;
  standardProductName: string | null;
  businessId: string;
  businessName: string;
  businessSlug: string;
  lat: number | null;
  lng: number | null;
  neighborhood: string | null;
  distanceKm: number | null;
  verified: boolean;
  completedOrders: number;
  cancelledOrders: number;
  avgRating: number | null;
  reviewCount: number;
  imageUrl: string | null;
};

export type SearchResult = {
  listings: ListingHit[];
  comparisons: Array<{ standardProductId: string; name: string; listingIds: string[] }>;
  categories: Array<{
    id: string;
    slug: string;
    name: string;
    parentId: string | null;
    featured: boolean;
    sortOrder: number;
    icon: string | null;
  }>;
  origin: { lat: number; lng: number };
};

type SearchInput = {
  q?: string;
  category?: string;
  maxPriceCents?: number | null;
  maxDistanceKm?: number | null;
  delivery?: boolean;
  pickup?: boolean;
  inStock?: boolean;
  sort?: "price_asc" | "price_desc" | "distance";
};

function cleanSearch(input: SearchInput): Required<SearchInput> {
  const sort = input.sort;
  return {
    q: typeof input.q === "string" ? input.q.trim().slice(0, 80) : "",
    category: typeof input.category === "string" ? input.category : "",
    maxPriceCents:
      typeof input.maxPriceCents === "number" && input.maxPriceCents > 0
        ? Math.round(input.maxPriceCents)
        : null,
    maxDistanceKm:
      typeof input.maxDistanceKm === "number" && input.maxDistanceKm > 0
        ? input.maxDistanceKm
        : null,
    delivery: input.delivery === true,
    pickup: input.pickup === true,
    inStock: input.inStock !== false,
    sort: sort === "price_desc" || sort === "distance" || sort === "price_asc" ? sort : "price_asc",
  };
}

function imageUrl(key: string | null): string | null {
  if (!key || !/^listings\/[0-9a-f-]{36}\/[0-9a-f-]{36}$/.test(key)) return null;
  return `/api/media/${key}`;
}

export const searchMarketplace = createServerFn({ method: "GET" })
  .validator((input: SearchInput) => cleanSearch(input ?? {}))
  .handler(async ({ data }): Promise<SearchResult> => {
    const db = await sql();
    const like = data.q ? likeContains(data.q) : "%";
    const foldedCategory = data.category ? fold(data.category) : "";
    const rows = await db<{
      id: string;
      name: string;
      slug: string;
      brand: string;
      sku: string;
      unit: string;
      description: string;
      price_cents: string;
      stock_units: number;
      delivery: boolean;
      pickup: boolean;
      shipping_cents: string;
      lead_time_hours: number | null;
      category_name: string;
      category_slug: string;
      standard_product_id: string | null;
      standard_name: string | null;
      business_id: string;
      trade_name: string;
      business_slug: string;
      lat: number | null;
      lng: number | null;
      neighborhood: string | null;
      verified_at: string | null;
      completed_orders: number;
      cancelled_orders: number;
      avg_rating: number | null;
      review_count: number;
      image_key: string | null;
    }>`
      select
        l.id, l.name, l.slug, l.brand, l.sku, l.unit, l.description, l.price_cents::text, l.stock_units,
        l.delivery, l.pickup, l.shipping_cents::text, l.lead_time_hours,
        c.name as category_name, c.slug as category_slug,
        l.standard_product_id, s.name as standard_name,
        b.id as business_id, b.trade_name, b.slug as business_slug, b.lat, b.lng, b.neighborhood,
        b.verified_at::text as verified_at,
        (select count(*)::int from orders ord where ord.business_id = b.id and ord.status = 'COMPLETED') as completed_orders,
        (select count(*)::int from orders ord where ord.business_id = b.id and ord.status = 'CANCELLED') as cancelled_orders,
        (select avg(r.rating)::float8 from reviews r where r.business_id = b.id) as avg_rating,
        (select count(*)::int from reviews r where r.business_id = b.id) as review_count,
        (
          select i.storage_key from listing_images i
          where i.listing_id = l.id and i.status = 'ready'
          order by i.is_primary desc, i.position
          limit 1
        ) as image_key
      from listings l
      join businesses b on b.id = l.business_id and b.status = 'active' and b.is_demo = false
      join categories c on c.id = l.category_id and c.active = true
      left join categories parent on parent.id = c.parent_id
      left join standard_products s on s.id = l.standard_product_id and s.active = true
      where l.status = 'published'
        and l.is_demo = false
        and l.stock_units > 0
        and (${data.q} = '' or l.search_text ilike ${like} escape '\\' or b.search_text ilike ${like} escape '\\')
        and (
          ${foldedCategory} = ''
          or c.slug = ${foldedCategory}
          or parent.slug = ${foldedCategory}
        )
    `;

    let listings: ListingHit[] = rows.map((row) => {
      const distance =
        row.lat === null || row.lng === null
          ? null
          : Math.round(distanceKm(ROSARIO.lat, ROSARIO.lng, row.lat, row.lng) * 10) / 10;
      return {
        id: row.id,
        name: row.name,
        slug: row.slug,
        brand: row.brand,
        sku: row.sku,
        unit: row.unit,
        description: row.description,
        priceCents: asInt(row.price_cents),
        stockUnits: row.stock_units,
        delivery: row.delivery,
        pickup: row.pickup,
        shippingCents: asInt(row.shipping_cents),
        leadTimeHours: row.lead_time_hours,
        categoryName: row.category_name,
        categorySlug: row.category_slug,
        standardProductId: row.standard_product_id,
        standardProductName: row.standard_name,
        businessId: row.business_id,
        businessName: row.trade_name,
        businessSlug: row.business_slug,
        lat: row.lat,
        lng: row.lng,
        neighborhood: row.neighborhood,
        distanceKm: distance,
        verified: Boolean(row.verified_at),
        completedOrders: row.completed_orders,
        cancelledOrders: row.cancelled_orders,
        avgRating: row.avg_rating,
        reviewCount: row.review_count,
        imageUrl: imageUrl(row.image_key),
      };
    });

    if (data.delivery) listings = listings.filter((listing) => listing.delivery);
    if (data.pickup) listings = listings.filter((listing) => listing.pickup);
    if (data.maxPriceCents !== null) listings = listings.filter((listing) => listing.priceCents <= data.maxPriceCents!);
    if (data.maxDistanceKm !== null) {
      listings = listings.filter((listing) => listing.distanceKm !== null && listing.distanceKm <= data.maxDistanceKm!);
    }
    listings.sort((a, b) => {
      if (data.sort === "distance") return (a.distanceKm ?? 999) - (b.distanceKm ?? 999);
      if (data.sort === "price_desc") return b.priceCents - a.priceCents;
      return a.priceCents - b.priceCents;
    });

    const nameByAnchor = new Map(listings.map((listing) => [listing.standardProductId, listing.standardProductName]));
    const comparisons = comparableGroups(listings).map((group) => ({
      ...group,
      name: nameByAnchor.get(group.standardProductId) ?? "Ofertas comparables",
    }));

    const categories = await db<{
      id: string;
      slug: string;
      name: string;
      parent_id: string | null;
      is_featured: boolean;
      sort_order: number;
      icon: string | null;
    }>`
      select id, slug, name, parent_id, is_featured, sort_order, icon
      from categories
      where active = true
      order by is_featured desc, sort_order, name
    `;

    return {
      listings,
      comparisons,
      categories: categories.map((row) => ({
        id: row.id,
        slug: row.slug,
        name: row.name,
        parentId: row.parent_id,
        featured: row.is_featured === true,
        sortOrder: row.sort_order,
        icon: row.icon,
      })),
      origin: ROSARIO,
    };
  });

export const getListing = createServerFn({ method: "GET" })
  .validator((listingId: string) => {
    if (typeof listingId !== "string" || listingId.length > 80) throw new Error("Publicación inválida.");
    return listingId;
  })
  .handler(async ({ data }) => {
    const result = await searchMarketplace({ data: { inStock: true } });
    const listing = result.listings.find((item) => item.id === data || item.slug === data);
    if (!listing) throw new Error("Esa publicación no está a la venta.");
    const comparable = result.comparisons.find((group) => group.listingIds.includes(listing.id));
    const siblings = comparable
      ? result.listings.filter((item) => comparable.listingIds.includes(item.id) && item.id !== listing.id)
      : [];
    const db = await sql();
    const images = await db<{ storage_key: string; is_primary: boolean }>`
      select storage_key, is_primary from listing_images
      where listing_id = ${listing.id} and status = 'ready'
      order by is_primary desc, position
    `;
    return {
      ...listing,
      images: images.map((image) => imageUrl(image.storage_key)).filter((url): url is string => Boolean(url)),
      siblings,
    };
  });

export const getBusiness = createServerFn({ method: "GET" })
  .validator((businessId: string) => {
    if (typeof businessId !== "string" || businessId.length > 80) throw new Error("Negocio inválido.");
    return businessId;
  })
  .handler(async ({ data }) => {
    const db = await sql();
    const rows = await db<{
      id: string;
      trade_name: string;
      legal_name: string;
      slug: string;
      description: string;
      status: string;
      address_line: string | null;
      neighborhood: string | null;
      city: string;
      lat: number | null;
      lng: number | null;
      offers_delivery: boolean;
      offers_pickup: boolean;
      is_demo: boolean;
      verified_at: string | null;
      phone: string | null;
    }>`
      select id, trade_name, legal_name, slug, description, status, address_line, neighborhood,
        city, lat, lng, offers_delivery, offers_pickup, is_demo, verified_at::text, phone
      from businesses
      where (id = ${data} or slug = ${data}) and status = 'active' and is_demo = false
    `;
    const business = rows[0];
    if (!business) throw new Error("Ese proveedor no está publicado.");
    const listings = await db<{
      id: string;
      name: string;
      unit: string;
      price_cents: string;
      stock_units: number;
      brand: string;
    }>`
      select id, name, unit, price_cents::text, stock_units, brand
      from listings
      where business_id = ${business.id} and status = 'published' and is_demo = false and stock_units > 0
      order by name
    `;
    return {
      id: business.id,
      tradeName: business.trade_name,
      legalName: business.legal_name,
      slug: business.slug,
      description: business.description,
      addressLine: business.address_line,
      neighborhood: business.neighborhood,
      city: business.city,
      lat: business.lat,
      lng: business.lng,
      offersDelivery: business.offers_delivery,
      offersPickup: business.offers_pickup,
      isDemo: business.is_demo,
      verified: Boolean(business.verified_at),
      phone: business.phone,
      listings: listings.map((listing) => ({
        id: listing.id,
        name: listing.name,
        unit: listing.unit,
        brand: listing.brand,
        priceCents: asInt(listing.price_cents),
        stockUnits: listing.stock_units,
      })),
    };
  });

export const getPlatformStatus = createServerFn({ method: "GET" }).handler(async () => {
  const payments = missingMercadoPagoCredentials(readMercadoPagoEnv());
  const emailMissing = [
    !process.env.RESEND_API_KEY ? "RESEND_API_KEY" : null,
    !process.env.RESEND_FROM ? "RESEND_FROM" : null,
  ].filter((item): item is string => Boolean(item));
  const pepperReady = Boolean(process.env.CERCA_DELIVERY_PEPPER && process.env.CERCA_DELIVERY_PEPPER.length >= 16);
  const { storageMode, readStorageEnv } = await import("../storage");
  const mode = storageMode();
  return {
    database: dbSource === "pglite" ? "embedded_preview" : "postgres",
    demoSeedAllowed: dbSource === "pglite",
    city: "Rosario",
    payments: {
      provider: "mercadopago_split_1_1",
      configured: payments.length === 0,
      missing: payments,
    },
    email: { configured: emailMissing.length === 0, missing: emailMissing },
    maps: activeMapTiles(),
    deliveryPepperReady: pepperReady || dbSource === "pglite",
    storage: {
      mode,
      configured: mode === "r2",
      developmentOnly: mode === "local",
      missing: mode === "r2" ? [] : ["S3_ENDPOINT", "S3_BUCKET", "S3_ACCESS_KEY", "S3_SECRET_KEY"],
      note:
        mode === "r2"
          ? "Las imágenes van a Cloudflare R2."
          : mode === "local"
            ? "Desarrollo: las imágenes se guardan en disco local, no en la base. En producción hace falta R2."
            : "No hay almacenamiento. No se puede publicar un producto con fotos.",
      endpointHost: readStorageEnv().endpoint ? "configured" : null,
    },
    adminBootstrap: process.env.CERCA_BOOTSTRAP_ADMIN_EMAIL?.trim()
      ? "configured"
      : dbSource === "pglite"
        ? "dev_claim"
        : "missing",
    devMailbox: dbSource === "pglite" && !(process.env.RESEND_API_KEY?.trim() && process.env.RESEND_FROM?.trim()),
  };
});
