/**
 * Proveedor de mapa desacoplado del SDK.
 * Hoy: teselas CARTO/OSM, sin clave, válidas para desarrollo.
 * Producción con tráfico real: reemplazar por MapTiler o Mapbox
 * (misma interfaz: url + attribution). No usar el tile público de OSM
 * como dependencia comercial.
 */
export type MapTileProvider = {
  id: string;
  url: string;
  attribution: string;
  maxZoom: number;
};

export const cartoVoyager: MapTileProvider = {
  id: "carto-voyager",
  url: "https://basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
  attribution: "&copy; OpenStreetMap &copy; CARTO",
  maxZoom: 19,
};

export function activeMapTiles(): MapTileProvider {
  return cartoVoyager;
}
