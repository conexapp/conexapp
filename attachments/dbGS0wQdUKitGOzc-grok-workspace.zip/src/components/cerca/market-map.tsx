import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { LocateFixed, X } from "lucide-react";
import { ROSARIO } from "@/lib/cerca/domain/geo";
import "leaflet/dist/leaflet.css";

export type MapPoint = {
  id: string;
  lat: number;
  lng: number;
  label: string;
  place?: string | null;
  distanceKm?: number | null;
  categories?: string[];
};

export function validMapPoint(lat: number | null, lng: number | null): { lat: number; lng: number } | null {
  if (lat === null || lng === null) return null;
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat, lng };
}

export function MarketMap({
  points,
  selectedId,
  onSelect,
  popup = false,
  detailPlace = null,
  emptyNote = null,
}: {
  points: MapPoint[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  popup?: boolean;
  detailPlace?: string | null;
  emptyNote?: string | null;
}) {
  const node = useRef<HTMLDivElement>(null);
  const mapRef = useRef<import("leaflet").Map | null>(null);
  const layerRef = useRef<import("leaflet").LayerGroup | null>(null);
  const onSelectRef = useRef(onSelect);
  const [ready, setReady] = useState(false);
  const focused = useRef<{ id: string; lat: number; lng: number } | null>(null);
  onSelectRef.current = onSelect;

  useEffect(() => {
    const nodeEl = node.current;
    if (!nodeEl) return;
    let removed = false;
    let map: import("leaflet").Map | null = null;
    void (async () => {
      const L = await import("leaflet");
      if (removed || !node.current || mapRef.current) return;
      map = L.map(node.current, {
        scrollWheelZoom: false,
        zoomControl: true,
      }).setView([ROSARIO.lat, ROSARIO.lng], 12);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
        subdomains: "abc",
      }).addTo(map);
      layerRef.current = L.layerGroup().addTo(map);
      map.on("click", () => onSelectRef.current(null));
      const enableWheel = () => map?.scrollWheelZoom.enable();
      const disableWheel = () => map?.scrollWheelZoom.disable();
      map.getContainer().addEventListener("mouseenter", enableWheel);
      map.getContainer().addEventListener("mouseleave", disableWheel);
      mapRef.current = map;
      const redraw = () => map?.invalidateSize();
      redraw();
      window.setTimeout(redraw, 80);
      window.setTimeout(redraw, 400);
      if (!removed) setReady(true);
    })();
    const observer = new ResizeObserver(() => mapRef.current?.invalidateSize());
    observer.observe(nodeEl);
    return () => {
      removed = true;
      observer.disconnect();
      mapRef.current?.remove();
      mapRef.current = null;
      layerRef.current = null;
      setReady(false);
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const layer = layerRef.current;
    if (!ready || !map || !layer) return;
    let dead = false;
    void (async () => {
      const L = await import("leaflet");
      if (dead) return;
      layer.clearLayers();
      for (const point of points) {
        const spot = validMapPoint(point.lat, point.lng);
        if (!spot) continue;
        const selected = point.id === selectedId;
        const marker = L.marker([spot.lat, spot.lng], {
          icon: L.divIcon({
            className: "cerca-pin-wrap",
            html: `<span class="cerca-pin${selected ? " is-selected" : ""}"></span>`,
            iconSize: [28, 28],
            iconAnchor: [14, 14],
          }),
          keyboard: true,
          title: point.label,
        });
        marker.on("click", (event) => {
          L.DomEvent.stopPropagation(event);
          onSelectRef.current(point.id);
        });
        marker.addTo(layer);
      }
      const selected = points.find((point) => point.id === selectedId);
      const spot = selected ? validMapPoint(selected.lat, selected.lng) : null;
      if (selected && spot) {
        const previous = focused.current;
        if (!previous || previous.id !== selected.id || previous.lat !== spot.lat || previous.lng !== spot.lng) {
          map.panTo([spot.lat, spot.lng]);
        }
        focused.current = { id: selected.id, lat: spot.lat, lng: spot.lng };
      } else {
        focused.current = null;
      }
    })();
    return () => {
      dead = true;
    };
  }, [points, selectedId, ready]);

  const selected = points.find((point) => point.id === selectedId) ?? null;
  const place = detailPlace ?? selected?.place ?? null;

  function recenter() {
    mapRef.current?.setView([ROSARIO.lat, ROSARIO.lng], 12);
  }

  return (
    <div className="cerca-map relative h-80 min-h-80 w-full overflow-hidden rounded-2xl bg-paper">
      <div ref={node} className="absolute inset-0" />
      <button
        type="button"
        onClick={recenter}
        className="absolute top-3 right-3 z-[500] inline-flex min-h-11 items-center gap-1 rounded-full bg-card px-3 text-sm font-semibold text-ink shadow-card"
      >
        <LocateFixed className="size-4 text-olive" aria-hidden />
        Rosario
      </button>
      {points.length === 0 && emptyNote ? (
        <p className="pointer-events-none absolute inset-x-3 bottom-3 z-[500] rounded-2xl bg-card/95 px-3 py-2 text-sm text-ink shadow-card">
          {emptyNote}
        </p>
      ) : null}
      {popup && selected ? (
        <div className="absolute inset-x-3 bottom-3 z-[500] rounded-2xl bg-card p-3 shadow-card">
          <div className="flex items-start justify-between gap-2">
            <p className="font-semibold">{selected.label}</p>
            <button
              type="button"
              aria-label="Cerrar"
              onClick={() => onSelect(null)}
              className="grid size-11 shrink-0 place-items-center rounded-full hover:bg-paper"
            >
              <X className="size-4" aria-hidden />
            </button>
          </div>
          {place ? <p className="text-sm text-muted">{place}</p> : null}
          {selected.categories && selected.categories.length > 0 ? (
            <p className="mt-1 text-sm">{selected.categories.join(" · ")}</p>
          ) : null}
          {typeof selected.distanceKm === "number" ? (
            <p className="mt-1 text-sm text-muted">{selected.distanceKm} km del centro</p>
          ) : null}
          <Link
            to="/negocio/$businessId"
            params={{ businessId: selected.id }}
            className="mt-2 inline-flex min-h-11 items-center rounded-full bg-ember px-4 text-sm font-semibold text-ink"
          >
            Ver proveedor
          </Link>
        </div>
      ) : null}
    </div>
  );
}
