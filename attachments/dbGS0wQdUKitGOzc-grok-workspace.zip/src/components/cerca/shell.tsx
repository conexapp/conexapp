import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { MapPin, Search, ShoppingBag } from "lucide-react";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getMyAccount } from "@/lib/cerca/server/account";
import { searchMarketplace } from "@/lib/cerca/server/public";

type Category = { id: string; slug: string; name: string; parentId?: string | null; featured?: boolean; sortOrder?: number };

export function Shell({ children }: { children: ReactNode }) {
  const navigate = useNavigate();
  const { user } = useCurrentUserState();
  const locationSearch = useRouterState({
    select: (state) => state.location.search as { q?: string; categoria?: string },
  });
  const activeCategory = typeof locationSearch?.categoria === "string" ? locationSearch.categoria : "";
  const [categories, setCategories] = useState<Category[]>([]);
  const [headerQ, setHeaderQ] = useState(typeof locationSearch?.q === "string" ? locationSearch.q : "");
  const [isAdmin, setIsAdmin] = useState(false);
  const [canClaimAdmin, setCanClaimAdmin] = useState(false);

  useEffect(() => {
    if (typeof locationSearch?.q === "string") setHeaderQ(locationSearch.q);
  }, [locationSearch?.q]);

  useEffect(() => {
    void searchMarketplace({ data: {} })
      .then((result) => setCategories(result.categories))
      .catch(() => setCategories([]));
  }, []);

  useEffect(() => {
    if (!user) {
      setIsAdmin(false);
      setCanClaimAdmin(false);
      return;
    }
    void getMyAccount()
      .then((account) => {
        setIsAdmin(account.platformRole === "admin");
        setCanClaimAdmin(account.canClaimAdmin);
      })
      .catch(() => {
        setIsAdmin(false);
        setCanClaimAdmin(false);
      });
  }, [user]);

  function submitSearch(event: FormEvent) {
    event.preventDefault();
    void navigate({ to: "/", search: { q: headerQ.trim() || undefined, categoria: undefined }, hash: "productos" });
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 bg-card">
        <div className="border-b border-line">
          <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
            <Link to="/" search={{ q: undefined, categoria: undefined }} className="shrink-0 leading-none">
              <span className="font-display text-2xl font-semibold tracking-tight text-olive">Cerca</span>
            </Link>
            <span className="hidden shrink-0 items-center gap-1 text-sm text-muted sm:inline-flex">
              <MapPin className="size-4 text-teal" aria-hidden />
              Rosario
            </span>
            <form onSubmit={submitSearch} className="mx-4 hidden min-w-0 max-w-xl flex-1 md:flex">
              <label className="flex min-h-11 min-w-0 flex-1 items-center gap-2 rounded-full border border-line bg-paper px-3">
                <Search className="size-4 shrink-0 text-muted" aria-hidden />
                <input
                  value={headerQ}
                  onChange={(event) => setHeaderQ(event.target.value)}
                  placeholder="Buscar productos o proveedores"
                  className="min-w-0 flex-1 bg-transparent text-sm outline-none"
                />
              </label>
            </form>
            <nav className="ml-auto flex items-center gap-1">
              <Link
                to="/"
                hash="proveedores"
                search={{ q: undefined, categoria: undefined }}
                className="hidden min-h-11 items-center rounded-full px-3 text-sm font-medium hover:bg-paper lg:inline-flex"
              >
                Proveedores
              </Link>
              <Link
                to="/cotizar"
                className="hidden min-h-11 items-center rounded-full px-3 text-sm font-medium hover:bg-paper lg:inline-flex"
              >
                Necesito esto
              </Link>
              <details className="relative">
                <summary className="flex min-h-11 list-none items-center gap-1.5 rounded-full px-3 text-sm font-medium hover:bg-paper">
                  <ShoppingBag className="size-4" aria-hidden />
                  <span className="hidden sm:inline">Carrito</span>
                </summary>
                <div className="absolute right-0 z-50 mt-2 w-72 rounded-2xl bg-card p-4 shadow-card">
                  <p className="font-display text-lg font-semibold">Sin carrito armado</p>
                  <p className="mt-1 text-sm text-muted">
                    El pedido nace cuando aceptás una cotización. No se mezcla mercadería de varios proveedores en un mismo pago.
                  </p>
                  <div className="mt-3 grid gap-2">
                    <Link to="/cotizaciones" className="inline-flex min-h-11 items-center rounded-full bg-paper px-4 text-sm font-medium">
                      Mis cotizaciones
                    </Link>
                    <Link to="/pedidos" className="inline-flex min-h-11 items-center rounded-full bg-ember px-4 text-sm font-semibold text-ink">
                      Mis pedidos
                    </Link>
                  </div>
                </div>
              </details>
              <SignedOut>
                <Link to="/login" className="inline-flex min-h-11 items-center rounded-full bg-ink px-4 text-sm font-semibold text-paper">
                  Entrar
                </Link>
              </SignedOut>
              <SignedIn>
                <details className="relative">
                  <summary className="flex min-h-11 list-none items-center rounded-full px-3 text-sm font-medium hover:bg-paper">
                    Cuenta
                  </summary>
                  <div className="absolute right-0 z-50 mt-2 grid w-64 gap-1 rounded-2xl bg-card p-2 shadow-card">
                    <UserButton />
                    <Link to="/cuenta" className="inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper">
                      Mi cuenta
                    </Link>
                    <Link to="/panel" className="inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper">
                      Mi negocio
                    </Link>
                    <Link to="/cotizaciones" className="inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper">
                      Mis cotizaciones
                    </Link>
                    <Link to="/pedidos" className="inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper">
                      Mis pedidos
                    </Link>
                    {isAdmin || canClaimAdmin ? (
                      <Link to="/admin" className="inline-flex min-h-11 items-center rounded-xl px-3 text-sm hover:bg-paper">
                        Administración
                      </Link>
                    ) : null}
                  </div>
                </details>
              </SignedIn>
            </nav>
          </div>
          <form onSubmit={submitSearch} className="px-4 pb-3 md:hidden">
            <label className="flex min-h-11 items-center gap-2 rounded-full border border-line bg-paper px-3">
              <Search className="size-4 text-muted" aria-hidden />
              <input
                value={headerQ}
                onChange={(event) => setHeaderQ(event.target.value)}
                placeholder="Buscar productos o proveedores"
                className="min-w-0 flex-1 bg-transparent text-sm outline-none"
              />
            </label>
          </form>
        </div>
        <div className="border-b border-line">
          <div className="mx-auto flex max-w-7xl items-center gap-2 overflow-x-auto px-4 py-2">
            <Link
              to="/categorias"
              className="inline-flex min-h-11 shrink-0 items-center rounded-full bg-ink px-4 text-sm font-semibold text-paper"
            >
              Todas las categorías
            </Link>
            <Link
              to="/cotizar"
              className="inline-flex min-h-11 shrink-0 items-center rounded-full px-3 text-sm font-medium hover:bg-paper lg:hidden"
            >
              Necesito esto
            </Link>
            {(() => {
              const featured = categories.filter((item) => item.featured && !item.parentId);
              const chips = featured.length > 0 ? featured : categories.filter((item) => !item.parentId);
              return chips.map((item) => {
              const active = activeCategory === item.slug;
              return (
                <Link
                  key={item.id}
                  to="/"
                  search={{ q: undefined, categoria: item.slug }}
                  hash="productos"
                  className={`inline-flex min-h-11 shrink-0 items-center rounded-full px-3 text-sm font-medium ${active ? "bg-sun text-ink" : "hover:bg-paper"}`}
                >
                  {item.name}
                </Link>
              );
            });
            })()}
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-4 py-6">{children}</main>
      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4 text-sm text-muted">
          <p>Cerca no da la razón de antemano. La protección sigue la evidencia que quedó en el pedido.</p>
          <Link to="/proteccion" className="font-semibold text-ink">
            Cerca Protección
          </Link>
        </div>
      </footer>
    </div>
  );
}
