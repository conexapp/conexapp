import type { LucideIcon } from "lucide-react";
import { Link } from "@tanstack/react-router";
import {
  Baby,
  BookOpen,
  Briefcase,
  Building2,
  Car,
  Dumbbell,
  Factory,
  Gem,
  Gift,
  Guitar,
  Hammer,
  HeartPulse,
  Landmark,
  Package,
  PawPrint,
  Shirt,
  Smartphone,
  Sofa,
  Sparkles,
  Sprout,
  UtensilsCrossed,
  Boxes,
  BrickWall,
  Droplets,
  HardHat,
  Layers,
  Mountain,
  Paintbrush,
  Wrench,
} from "lucide-react";

const ICONS: Record<string, LucideIcon> = {
  construccion: HardHat,
  "cementos-y-cales": Boxes,
  mamposteria: BrickWall,
  aridos: Mountain,
  hierros: Layers,
  fijaciones: Wrench,
  aislacion: Layers,
  pinturas: Paintbrush,
  sanitarios: Droplets,
};

const GLYPHS: Record<string, LucideIcon> = {
  technology: Smartphone,
  fashion: Shirt,
  home: Sofa,
  food: UtensilsCrossed,
  sports: Dumbbell,
  vehicles: Car,
  beauty: Sparkles,
  tools: Hammer,
  kids: Baby,
  pets: PawPrint,
  property: Building2,
  industry: Factory,
  agro: Sprout,
  health: HeartPulse,
  music: Guitar,
  books: BookOpen,
  jewelry: Gem,
  antiques: Landmark,
  parties: Gift,
  services: Briefcase,
};

export function glyph(icon: string | null | undefined): LucideIcon | null {
  if (!icon) return null;
  return GLYPHS[icon] ?? null;
}

export function categoryIcon(slug: string): LucideIcon {
  return ICONS[slug] ?? Package;
}

const HOME_CATEGORY_LIMIT = 6;

export function browseCategories<T extends { featured?: boolean; parentId?: string | null }>(categories: T[]): T[] {
  const featured = categories.filter((category) => category.featured && !category.parentId);
  if (featured.length > 0) return featured;
  return categories.filter((category) => !category.parentId).slice(0, HOME_CATEGORY_LIMIT);
}

export function CategoryCard({
  slug,
  name,
  icon,
  active = false,
  onSelect,
}: {
  slug: string;
  name: string;
  icon?: string | null;
  active?: boolean;
  onSelect?: () => void;
}) {
  const Glyph = glyph(icon) ?? categoryIcon(slug);
  const className = `group relative flex aspect-[4/3] w-full overflow-hidden rounded-2xl bg-[#e7f6f3] text-left shadow-card ring-2 ring-transparent transition hover:-translate-y-0.5 hover:ring-teal ${active ? "ring-ember" : ""}`;
  const body = (
    <>
      <span className="grid flex-1 place-items-center text-olive">
        <Glyph className="size-14" aria-hidden />
      </span>
      <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/80 to-transparent px-3 pt-8 pb-3 text-sm font-semibold text-white">
        {name}
      </span>
    </>
  );
  if (onSelect) {
    return (
      <button type="button" onClick={onSelect} className={className}>
        {body}
      </button>
    );
  }
  return (
    <Link to="/" search={{ categoria: slug }} hash="productos" className={className}>
      {body}
    </Link>
  );
}

function CategoryArt({ slug }: { slug: string }) {
  return (
    <svg viewBox="0 0 320 240" className="h-full w-full bg-[#e7f6f3]" aria-hidden>
      <rect width="320" height="240" fill="#e7f6f3" />
      <circle cx="250" cy="48" r="36" fill="#FFD600" opacity="0.9" />
      {scene(slug)}
    </svg>
  );
}

function scene(slug: string) {
  switch (slug) {
    case "construccion":
      return (
        <>
          <path d="M78 168 h150 v14 h-150 z" fill="#d7c4a3" />
          <path d="M92 154 h28 v14 h-28 z M128 154 h28 v14 h-28 z M164 154 h28 v14 h-28 z" fill="#c46a4a" />
          <path d="M108 140 h28 v14 h-28 z M144 140 h28 v14 h-28 z" fill="#a8543c" />
          <path d="M210 78 h16 v104 h-16 z" fill="#8d97a3" />
          <path d="M198 86 h40 v10 h-40 z" fill="#FF7A00" />
          <path d="M214 64 h8 v18 h-8 z" fill="#24312e" />
        </>
      );
    case "cementos-y-cales":
      return (
        <>
          <path d="M92 78 h52 l10 16 v86 h-72 v-86 z" fill="#efe6d6" />
          <path d="M92 108 h62" stroke="#05AD98" strokeWidth="8" />
          <path d="M168 98 h48 l8 14 v68 h-64 v-68 z" fill="#05AD98" />
          <path d="M176 126 h40" stroke="#ffffff" strokeWidth="6" />
        </>
      );
    case "mamposteria":
      return (
        <>
          <path d="M64 78 h64 v26 h-64 z M132 78 h64 v26 h-64 z M200 78 h56 v26 h-56 z" fill="#c46a4a" />
          <path d="M64 110 h40 v26 h-40 z M108 110 h64 v26 h-64 z M176 110 h80 v26 h-80 z" fill="#a8543c" />
          <path d="M64 142 h64 v26 h-64 z M132 142 h64 v26 h-64 z M200 142 h56 v26 h-56 z" fill="#c46a4a" />
        </>
      );
    case "aridos":
      return (
        <>
          <path d="M58 176 L118 92 L178 176 Z" fill="#c8b48a" />
          <path d="M150 176 L214 108 L278 176 Z" fill="#05AD98" />
          <circle cx="108" cy="150" r="5" fill="#ffffff" />
          <circle cx="132" cy="158" r="4" fill="#ffffff" />
          <circle cx="206" cy="156" r="5" fill="#FFD600" />
        </>
      );
    case "hierros":
      return (
        <>
          <path d="M86 58 h14 v128 h-14 z M124 78 h14 v108 h-14 z M162 64 h14 v122 h-14 z" fill="#8d97a3" />
          <path d="M78 92 h110" stroke="#FF7A00" strokeWidth="6" />
          <path d="M78 126 h110" stroke="#05AD98" strokeWidth="6" />
        </>
      );
    case "fijaciones":
      return (
        <>
          <path d="M118 62 h36 v16 h-36 z" fill="#24312e" />
          <path d="M130 78 h12 v78 h-12 z" fill="#8d97a3" />
          <path d="M118 148 h36 l-6 16 h-24 z" fill="#24312e" />
          <circle cx="214" cy="118" r="28" fill="none" stroke="#05AD98" strokeWidth="12" />
          <circle cx="214" cy="118" r="8" fill="#FF7A00" />
        </>
      );
    case "aislacion":
      return (
        <>
          <path d="M70 150 c40-70 140-70 180 0 v28 c-40 18-140 18-180 0 z" fill="#05AD98" />
          <path d="M96 146 c28-36 100-36 132 0" fill="none" stroke="#FFD600" strokeWidth="8" />
        </>
      );
    case "pinturas":
      return (
        <>
          <path d="M118 70 h70 v78 h-70 z" fill="#FF7A00" />
          <path d="M138 148 h30 v22 h-30 z" fill="#24312e" />
          <path d="M206 64 h14 v70 h-14 z" fill="#05AD98" />
          <path d="M188 124 h50 v16 h-50 z" fill="#24312e" />
        </>
      );
    case "sanitarios":
      return (
        <>
          <path d="M96 92 h120 v28 h-120 z" fill="#ffffff" stroke="#05AD98" strokeWidth="8" />
          <path d="M118 120 h28 v52 h-28 z" fill="#05AD98" />
          <path d="M168 120 h36 v18 h-36 z" fill="#FF7A00" />
          <path d="M176 138 h8 v36 h-8 z" fill="#8d97a3" />
        </>
      );
    default:
      return <rect x="110" y="70" width="100" height="100" rx="16" fill="#05AD98" />;
  }
}
