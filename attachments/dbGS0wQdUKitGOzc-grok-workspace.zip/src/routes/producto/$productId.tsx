import { useEffect, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Shell } from "@/components/cerca/shell";
import { formatArs } from "@/lib/cerca/domain/money";
import { getListing } from "@/lib/cerca/server/public";
import { createQuoteRequest } from "@/lib/cerca/server/trade";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { toast } from "sonner";

export const Route = createFileRoute("/producto/$productId")({ component: ProductPage });

function ProductPage() {
  const { productId } = Route.useParams();
  const navigate = useNavigate();
  const { user } = useCurrentUserState();
  const [listing, setListing] = useState<Awaited<ReturnType<typeof getListing>> | null>(null);
  const [error, setError] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [delivery, setDelivery] = useState(true);
  const [photo, setPhoto] = useState(0);

  useEffect(() => {
    void getListing({ data: productId })
      .then((next) => {
        setListing(next);
        setDelivery(next.delivery);
      })
      .catch((cause: unknown) => setError(cause instanceof Error ? cause.message : "No se encontró."));
  }, [productId]);

  return (
    <Shell>
      {error ? <p>{error}</p> : null}
      {listing ? (
        <article className="grid gap-6 md:grid-cols-[minmax(0,1fr)_22rem]">
          <div>
            {listing.images[photo] ? (
              <img src={listing.images[photo]} alt={listing.name} className="aspect-square w-full rounded-card border border-line object-cover" />
            ) : (
              <div className="grid aspect-square place-items-center rounded-card border border-line bg-foam text-muted">Sin foto</div>
            )}
            {listing.images.length > 1 ? (
              <div className="mt-2 flex gap-2 overflow-x-auto">
                {listing.images.map((url, index) => (
                  <button key={url} type="button" onClick={() => setPhoto(index)}>
                    <img src={url} alt="" className="h-16 w-16 rounded-xl object-cover" />
                  </button>
                ))}
              </div>
            ) : null}
          </div>
          <div>
            <p className="text-sm text-muted">{listing.categoryName}</p>
            <h1 className="text-4xl">{listing.name}</h1>
            <p className="mt-2 text-muted">{listing.brand} {listing.sku ? `· SKU ${listing.sku}` : ""}</p>
            <p className="mt-3 font-display text-4xl tabular-nums">{formatArs(listing.priceCents)} <span className="text-lg text-muted">/ {listing.unit}</span></p>
            <p className="mt-2 text-sm">Stock {listing.stockUnits}. {listing.delivery ? "Entrega" : "Sin entrega"}. {listing.pickup ? "Retiro" : "Sin retiro"}.</p>
            {listing.delivery ? <p className="text-sm text-muted">Envío publicado: {formatArs(listing.shippingCents)}. El plazo estimado es {listing.leadTimeHours ?? "a confirmar"} horas.</p> : null}
            <p className="mt-3 max-w-xl">{listing.description}</p>
            <p className="mt-3 text-sm">
              Proveedor: <Link to="/negocio/$businessId" params={{ businessId: listing.businessId }} className="text-olive">{listing.businessName}</Link>
              {listing.reviewCount > 0 && listing.avgRating !== null ? ` · ${listing.avgRating.toFixed(1)}` : " · sin calificaciones"}
            </p>
            {listing.siblings.length > 0 ? (
              <div className="mt-4">
                <h2 className="text-xl">Otras ofertas de la misma ancla</h2>
                <ul className="mt-2 grid gap-1 text-sm">
                  {listing.siblings.map((sibling) => (
                    <li key={sibling.id}>
                      <Link to="/producto/$productId" params={{ productId: sibling.id }}>
                        {sibling.businessName} · {formatArs(sibling.priceCents)} · stock {sibling.stockUnits}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ) : null}
            <form
              className="mt-4 grid gap-2"
              onSubmit={(event) => {
                event.preventDefault();
                if (!user) {
                  void navigate({ to: "/login" });
                  return;
                }
                void createQuoteRequest({
                  data: { listingId: listing.id, quantity, notes, address, delivery },
                })
                  .then(async () => {
                    toast.success("Solicitud enviada a este proveedor.");
                    await navigate({ to: "/cotizaciones" });
                  })
                  .catch((cause: unknown) => toast.error(cause instanceof Error ? cause.message : "No se envió."));
              }}
            >
              <h2 className="text-2xl">Pedir cotización</h2>
              <input type="number" min={1} max={listing.stockUnits} value={quantity} onChange={(event) => setQuantity(Number(event.target.value))} className="min-h-11 rounded-2xl border border-line px-3" />
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={delivery} onChange={(event) => setDelivery(event.target.checked)} />
                Quiero entrega
              </label>
              {delivery ? <input required value={address} onChange={(event) => setAddress(event.target.value)} placeholder="Dirección en Rosario" className="min-h-11 rounded-2xl border border-line px-3" /> : null}
              <textarea value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="Aclaraciones" className="min-h-20 rounded-2xl border border-line px-3 py-2" />
              <button className="min-h-11 rounded-full bg-copper text-ink">{user ? "Enviar al proveedor" : "Entrá para cotizar"}</button>
            </form>
          </div>
        </article>
      ) : null}
    </Shell>
  );
}
