import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/cerca/shell";

export const Route = createFileRoute("/cotizar")({ component: CotizarPage });

function CotizarPage() {
  return (
    <Shell>
      <h1 className="text-4xl">Pedir cotización</h1>
      <p className="mt-2 max-w-xl text-sm text-muted">
        La cotización es sobre la publicación de un proveedor, no sobre un producto genérico de Cerca. Buscá, abrí la publicación y pedila desde ahí.
      </p>
      <Link to="/" className="mt-4 inline-flex min-h-11 items-center rounded-full bg-ink px-4 text-paper">Ir a buscar</Link>
    </Shell>
  );
}
