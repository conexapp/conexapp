import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/cerca/shell";
import { getMyAccount, listNotifications, updateMyPhone } from "@/lib/cerca/server/account";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { toast } from "sonner";

export const Route = createFileRoute("/cuenta")({ component: AccountPage });

function AccountPage() {
  const { user, isPending } = useCurrentUserState();
  const [account, setAccount] = useState<Awaited<ReturnType<typeof getMyAccount>> | null>(null);
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState<Awaited<ReturnType<typeof listNotifications>>>([]);

  useEffect(() => {
    if (!user) return;
    void getMyAccount().then((next) => {
      setAccount(next);
      setPhone(next.phone);
    });
    void listNotifications().then(setNotes);
  }, [user]);

  if (!isPending && !user) return <RedirectToSignIn />;

  return (
    <Shell>
      <h1 className="text-4xl">Cuenta</h1>
      {account ? (
        <form
          className="mt-4 grid max-w-md gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            void updateMyPhone({ data: phone })
              .then(() => toast.success("Teléfono guardado."))
              .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se guardó."));
          }}
        >
          <p>{account.name}</p>
          <p className="text-sm text-muted">{account.email}</p>
          <p className="text-sm">Rol de plataforma: {account.platformRole}</p>
          <input value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="Teléfono" className="min-h-12 rounded-2xl border border-line px-3" />
          <button className="min-h-11 rounded-full bg-ink text-paper">Guardar teléfono</button>
          <p className="text-sm text-muted">
            {account.businesses.length > 0 ? (
              <>
                Lo que vendés se elige en <Link to="/panel" className="font-semibold text-ink">Mi negocio</Link>.
              </>
            ) : (
              <>
                Para vender, <Link to="/panel" className="font-semibold text-ink">creá tu negocio</Link> y marcá una o varias categorías.
              </>
            )}
          </p>
        </form>
      ) : null}
      <section className="mt-8 grid gap-2">
        <h2 className="text-2xl">Avisos</h2>
        {notes.length === 0 ? <p className="text-sm text-muted">No hay avisos. El email sale solo si Resend está configurado; si no, queda el aviso interno.</p> : null}
        {notes.map((note) => (
          <article key={note.id} className="rounded-2xl border border-line px-3 py-2">
            <p className="font-medium">{note.title}</p>
            <p className="text-sm text-muted">{note.body}</p>
            <p className="text-xs text-muted">Email: {note.email_status}</p>
          </article>
        ))}
      </section>
    </Shell>
  );
}
