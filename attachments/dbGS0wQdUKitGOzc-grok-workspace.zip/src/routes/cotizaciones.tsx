import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/cerca/shell";
import { acceptQuote, listMyQuoteRequests } from "@/lib/cerca/server/trade";
import { formatArs } from "@/lib/cerca/domain/money";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { toast } from "sonner";

export const Route = createFileRoute("/cotizaciones")({ component: QuotesPage });

function QuotesPage() {
  const { user, isPending } = useCurrentUserState();
  const [data, setData] = useState<Awaited<ReturnType<typeof listMyQuoteRequests>> | null>(null);

  function reload() {
    void listMyQuoteRequests()
      .then(setData)
      .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se pudieron leer."));
  }

  useEffect(() => {
    if (user) reload();
  }, [user]);

  if (!isPending && !user) return <RedirectToSignIn />;

  return (
    <Shell>
      <h1 className="mb-4 text-4xl">Cotizaciones</h1>
      <div className="grid gap-4">
        {data?.requests.map((request) => (
          <article key={request.id} className="rounded-card border border-line bg-foam p-4">
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="text-2xl">{request.title}</h2>
              <span className="text-sm text-muted">{request.status}</span>
            </div>
            <p className="text-sm text-muted">
              {request.quantity} · {request.delivery_required ? request.address_line : "retiro"}
            </p>
            <ul className="mt-3 grid gap-2">
              {data.quotes
                .filter((quote) => quote.request_id === request.id)
                .map((quote) => (
                  <li key={quote.id} className="flex flex-wrap items-center justify-between gap-2 border-t border-line pt-2">
                    <div>
                      <p className="font-medium">{quote.trade_name}</p>
                      <p className="text-sm text-muted">
                        {formatArs(quote.unitPriceCents)} × {quote.quantity}
                        {quote.shippingCents ? ` + envío ${formatArs(quote.shippingCents)}` : ""}
                        {quote.lead_time_hours !== null ? ` · ${quote.lead_time_hours} h` : ""}
                        {" · "}
                        {quote.status}
                      </p>
                    </div>
                    {quote.status === "submitted" && request.status !== "accepted" ? (
                      <button
                        type="button"
                        className="min-h-11 rounded-full bg-ink px-4 text-paper"
                        onClick={() => {
                          void acceptQuote({
                            data: { quoteId: quote.id, idempotencyKey: crypto.randomUUID() },
                          })
                            .then((order) => {
                              toast.success("Cotización aceptada. El pedido quedó pendiente de pago: no se cobró nada.");
                              window.location.href = `/pedidos/${order.orderId}`;
                            })
                            .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se aceptó."));
                        }}
                      >
                        Aceptar {formatArs(quote.totalCents)}
                      </button>
                    ) : null}
                  </li>
                ))}
            </ul>
            {data.quotes.every((quote) => quote.request_id !== request.id) ? (
              <p className="mt-2 text-sm text-muted">Todavía no hay respuestas.</p>
            ) : null}
          </article>
        ))}
        {data && data.requests.length === 0 ? (
          <p className="text-muted">
            No pediste cotizaciones. <Link to="/cotizar" className="text-copper">Empezar</Link>
          </p>
        ) : null}
      </div>
    </Shell>
  );
}
