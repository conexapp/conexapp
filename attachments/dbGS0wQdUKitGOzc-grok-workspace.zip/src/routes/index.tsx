import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { BadgeCheck, Search, SlidersHorizontal, Store, Truck } from "lucide-react";
import { Shell } from "@/components/cerca/shell";
import { categoryIcon, CategoryCard, browseCategories } from "@/components/cerca/category-visual";
import { getBusiness, getPlatformStatus, searchMarketplace, type ListingHit, type SearchResult } from "@/lib/cerca/server/public";
import { MarketMap, validMapPoint, type MapPoint } from "@/components/cerca/market-map";
import { formatArs, parseArsToCents } from "@/lib/cerca/domain/money";
import { loadDevelopmentSeed } from "@/lib/cerca/server/account";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { toast } from "sonner";

type HomeSearch = { q?: string; categoria?: string };

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>): HomeSearch => ({
    q: typeof search.q === "string" && search.q.length > 0 ? search.q.slice(0, 80) : undefined,
    categoria:
      typeof search.categoria === "string" && search.categoria.length > 0
        ? search.categoria.slice(0, 80)
        : undefined,
  }),
  component: Home,
});

function Home() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const { user } = useCurrentUserState();
  const [q, setQ] = useState(search.q ?? "");
  const [category, setCategory] = useState(search.categoria ?? "");
  const [sort, setSort] = useState<"price_asc" | "price_desc" | "distance">("price_asc");
  const [delivery, setDelivery] = useState(false);
  const [pickup, setPickup] = useState(false);
  const [maxPrice, setMaxPrice] = useState("");
  const [maxKm, setMaxKm] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [result, setResult] = useState<SearchResult | null>(null);
  const [demoAllowed, setDemoAllowed] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [placeLabel, setPlaceLabel] = useState<string | null>(null);
  const [spots, setSpots] = useState<Record<string, { lat: number; lng: number } | null>>({});
  const [loading, setLoading] = useState(true);

  async function execute(nextQ: string, nextCategory: string) {
    setLoading(true);
    try {
      const data = await searchMarketplace({
        data: {
          q: nextQ,
          category: nextCategory,
          sort,
          delivery,
          pickup,
          inStock: true,
          maxPriceCents: maxPrice ? parseArsToCents(maxPrice) : null,
          maxDistanceKm: maxKm ? Number(maxKm) : null,
        },
      });
      setResult(data);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "No se pudo buscar.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void getPlatformStatus().then((status) => setDemoAllowed(status.demoSeedAllowed));
  }, []);

  useEffect(() => {
    const nextQ = search.q ?? "";
    const nextCategory = search.categoria ?? "";
    setQ(nextQ);
    setCategory(nextCategory);
    void execute(nextQ, nextCategory);
    // Los filtros locales se aplican con el botón. La URL solo cambia texto y categoría.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search.q, search.categoria]);

  const suppliers = useMemo(() => {
    const seen = new Map<
      string,
      {
        id: string;
        name: string;
        neighborhood: string | null;
        distanceKm: number | null;
        verified: boolean;
        count: number;
        lat: number | null;
        lng: number | null;
        categories: string[];
      }
    >();
    for (const listing of result?.listings ?? []) {
      const current = seen.get(listing.businessId);
      if (!current) {
        seen.set(listing.businessId, {
          id: listing.businessId,
          name: listing.businessName,
          neighborhood: listing.neighborhood,
          distanceKm: listing.distanceKm,
          verified: listing.verified,
          count: 1,
          lat: listing.lat,
          lng: listing.lng,
          categories: [listing.categoryName],
        });
      } else {
        current.count += 1;
        if (!current.categories.includes(listing.categoryName)) current.categories.push(listing.categoryName);
        if (current.lat === null && listing.lat !== null) current.lat = listing.lat;
        if (current.lng === null && listing.lng !== null) current.lng = listing.lng;
      }
    }
    return [...seen.values()];
  }, [result]);

  const points = useMemo<MapPoint[]>(() => {
    const next: MapPoint[] = [];
    for (const supplier of suppliers) {
      const override = Object.prototype.hasOwnProperty.call(spots, supplier.id) ? spots[supplier.id] : undefined;
      const spot = override === undefined ? validMapPoint(supplier.lat, supplier.lng) : override;
      if (!spot) continue;
      next.push({
        id: supplier.id,
        lat: spot.lat,
        lng: spot.lng,
        label: supplier.name,
        place: supplier.neighborhood?.trim() ? supplier.neighborhood.trim() : null,
        distanceKm: supplier.distanceKm,
        categories: supplier.categories,
      });
    }
    return next;
  }, [suppliers, spots]);

  useEffect(() => {
    setSpots({});
    setPlaceLabel(null);
  }, [result]);

  useEffect(() => {
    if (selected && !suppliers.some((supplier) => supplier.id === selected)) {
      setSelected(null);
      setPlaceLabel(null);
    }
  }, [selected, suppliers]);

  useEffect(() => {
    if (!selected) return;
    let cancelled = false;
    void getBusiness({ data: selected })
      .then((business) => {
        if (cancelled) return;
        const spot = validMapPoint(business.lat, business.lng);
        setSpots((current) => ({ ...current, [selected]: spot }));
        const parts = [business.addressLine, business.neighborhood, business.city]
          .map((part) => (typeof part === "string" ? part.trim() : ""))
          .filter((part) => part.length > 0);
        setPlaceLabel(parts.length > 0 ? parts.join(" · ") : null);
        if (!spot) setSelected(null);
      })
      .catch(() => {
        if (!cancelled) setPlaceLabel(null);
      });
    return () => {
      cancelled = true;
    };
  }, [selected, result]);

  const listings = result?.listings ?? [];
  const activeCategoryName = result?.categories.find((item) => item.slug === category)?.name;

  return (
    <Shell>
      <section className="overflow-hidden rounded-3xl border border-line bg-card">
        <div className="h-1.5 bg-sun" />
        <div className="grid gap-8 px-5 py-8 md:px-10 md:py-12 lg:grid-cols-[minmax(0,1.2fr)_minmax(16rem,0.8fr)] lg:items-end">
          <div>
            <p className="text-sm font-semibold text-olive">Marketplace de Rosario</p>
            <h1 className="mt-2 max-w-xl text-4xl leading-tight font-semibold tracking-tight md:text-5xl">
              Todo lo que necesitás, cerca tuyo.
            </h1>
            <p className="mt-3 max-w-lg text-base text-muted">
              Encontrá proveedores, compará ofertas y comprá de forma segura.
            </p>
            <form
              className="mt-6 flex flex-col gap-2 sm:flex-row"
              onSubmit={(event) => {
                event.preventDefault();
                void navigate({
                  to: "/",
                  search: { q: q.trim() || undefined, categoria: category || undefined },
                  hash: "productos",
                });
              }}
            >
              <label className="flex min-h-14 flex-1 items-center gap-3 rounded-full border border-line bg-paper px-5">
                <Search className="size-5 text-teal" aria-hidden />
                <input
                  value={q}
                  onChange={(event) => setQ(event.target.value)}
                  placeholder="¿Qué estás buscando?"
                  className="min-w-0 flex-1 bg-transparent text-base outline-none"
                />
              </label>
              <button type="submit" className="min-h-14 rounded-full bg-ember px-8 text-base font-semibold text-ink">
                Buscar
              </button>
            </form>
          </div>
          <dl className="grid grid-cols-3 gap-2 rounded-2xl bg-paper p-3">
            <Stat label="Publicaciones" value={loading ? "…" : String(listings.length)} />
            <Stat label="Proveedores" value={loading ? "…" : String(suppliers.length)} />
            <Stat label="Ciudad" value="Rosario" />
          </dl>
        </div>
      </section>

      <section className="mt-10">
        <div className="mb-4 flex items-end justify-between gap-3">
          <h2 className="text-2xl font-semibold">Explorá por categoría</h2>
          <Link to="/categorias" className="inline-flex min-h-11 items-center text-sm font-semibold text-olive">
            Ver todas las categorías
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {browseCategories(result?.categories ?? []).map((item) => (
            <CategoryCard
              key={item.id}
              slug={item.slug}
              name={item.name}
              icon={item.icon}
              active={category === item.slug}
              onSelect={() => {
                const next = category === item.slug ? undefined : item.slug;
                void navigate({
                  to: "/",
                  search: { q: q.trim() || undefined, categoria: next },
                  hash: "productos",
                });
              }}
            />
          ))}
        </div>
      </section>

      <section id="productos" className="mt-10 scroll-mt-36">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 className="text-2xl font-semibold">Productos disponibles cerca</h2>
            <p className="mt-1 text-sm text-muted">
              {activeCategoryName ? activeCategoryName : "Publicaciones activas de proveedores aprobados"}
              {search.q ? ` · “${search.q}”` : ""}
            </p>
          </div>
          <button
            type="button"
            className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-card px-4 text-sm font-medium"
            onClick={() => setFiltersOpen((open) => !open)}
            aria-expanded={filtersOpen}
          >
            <SlidersHorizontal className="size-4" aria-hidden />
            Filtros
          </button>
        </div>
        {filtersOpen ? (
          <form
            className="mb-4 grid gap-2 rounded-2xl bg-card p-4 shadow-card sm:grid-cols-2 lg:grid-cols-6"
            onSubmit={(event) => {
              event.preventDefault();
              void navigate({
                to: "/",
                search: { q: q.trim() || undefined, categoria: category || undefined },
                hash: "productos",
              });
              void execute(q.trim(), category);
            }}
          >
            <select
              value={category}
              onChange={(event) => setCategory(event.target.value)}
              className="min-h-11 rounded-full border border-line bg-paper px-3 text-sm"
            >
              <option value="">Todas las categorías</option>
              {result?.categories.map((item) => (
                <option key={item.id} value={item.slug}>
                  {item.name}
                </option>
              ))}
            </select>
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value as typeof sort)}
              className="min-h-11 rounded-full border border-line bg-paper px-3 text-sm"
            >
              <option value="price_asc">Menor precio</option>
              <option value="price_desc">Mayor precio</option>
              <option value="distance">Más cerca del centro</option>
            </select>
            <input
              value={maxPrice}
              onChange={(event) => setMaxPrice(event.target.value)}
              placeholder="Precio máximo"
              className="min-h-11 rounded-full border border-line bg-paper px-3 text-sm"
            />
            <input
              value={maxKm}
              onChange={(event) => setMaxKm(event.target.value)}
              placeholder="Km máx."
              className="min-h-11 rounded-full border border-line bg-paper px-3 text-sm"
            />
            <label className="flex min-h-11 items-center gap-2 rounded-full border border-line px-3 text-sm">
              <input type="checkbox" checked={delivery} onChange={(event) => setDelivery(event.target.checked)} />
              Entrega
            </label>
            <label className="flex min-h-11 items-center gap-2 rounded-full border border-line px-3 text-sm">
              <input type="checkbox" checked={pickup} onChange={(event) => setPickup(event.target.checked)} />
              Retiro
            </label>
            <button type="submit" className="min-h-11 rounded-full bg-teal px-4 text-sm font-semibold text-ink sm:col-span-2 lg:col-span-1">
              Aplicar
            </button>
          </form>
        ) : null}

        {loading ? (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, index) => (
              <div key={index} className="h-72 rounded-2xl bg-card shadow-card" />
            ))}
          </div>
        ) : null}

        {!loading && listings.length === 0 ? (
          <div className="rounded-2xl bg-card p-6 shadow-card">
            <p className="font-display text-2xl font-semibold">Todavía no hay productos publicados en esta búsqueda.</p>
            <p className="mt-2 max-w-xl text-sm text-muted">
              Cerca no precarga un catálogo. Un proveedor crea su negocio, lo aprueban y publica sus propios productos.
            </p>
            {demoAllowed && user ? (
              <button
                type="button"
                className="mt-4 min-h-11 rounded-full border border-ink px-4 text-sm font-medium"
                onClick={() => {
                  void loadDevelopmentSeed()
                    .then(() => {
                      toast.success("Ejemplos guardados como desarrollo. No aparecen en la búsqueda pública.");
                      return execute(q, category);
                    })
                    .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se pudo cargar."));
                }}
              >
                Cargar ejemplos de desarrollo
              </button>
            ) : null}
          </div>
        ) : null}

        {!loading && listings.length > 0 ? (
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
            {listings.map((listing) => (
              <ProductCard key={listing.id} listing={listing} />
            ))}
          </div>
        ) : null}
      </section>

      {(result?.comparisons.length ?? 0) > 0 ? (
        <section className="mt-10">
          <h2 className="text-2xl font-semibold">Mismo producto, varios proveedores</h2>
          <p className="mt-1 text-sm text-muted">Solo se agrupan si cada proveedor usó la misma ancla de catálogo.</p>
          <div className="mt-4 grid gap-3">
            {result?.comparisons.map((group) => (
              <article key={group.standardProductId} className="rounded-2xl bg-card p-4 shadow-card">
                <h3 className="text-xl font-semibold">{group.name}</h3>
                <div className="mt-3 flex gap-3 overflow-x-auto pb-1">
                  {listings
                    .filter((listing) => group.listingIds.includes(listing.id))
                    .map((listing) => (
                      <Link
                        key={listing.id}
                        to="/producto/$productId"
                        params={{ productId: listing.id }}
                        className="w-56 shrink-0 rounded-2xl bg-paper p-3"
                      >
                        <p className="text-sm font-semibold">{listing.businessName}</p>
                        <p className="mt-2 font-display text-2xl tabular-nums">{formatArs(listing.priceCents)}</p>
                        <p className="text-xs text-muted">/ {listing.unit}</p>
                      </Link>
                    ))}
                </div>
              </article>
            ))}
          </div>
        </section>
      ) : null}

      <section id="proveedores" className="mt-10 scroll-mt-36">
        <div className="mb-4">
          <h2 className="text-2xl font-semibold">Proveedores cerca tuyo</h2>
          <p className="mt-1 text-sm text-muted">Ubicación real de los negocios que aparecen en esta búsqueda.</p>
        </div>
        <div className="grid items-start gap-4 md:grid-cols-[minmax(0,1fr)_minmax(16rem,22rem)]">
          <div className="grid gap-3 lg:max-h-80 lg:overflow-y-auto">
            {loading ? <div className="h-28 rounded-2xl bg-card shadow-card" /> : null}
            {!loading && suppliers.length === 0 ? (
              <div className="rounded-2xl bg-card p-4 shadow-card">
                <p className="font-semibold">No hay proveedores en esta búsqueda.</p>
                <p className="mt-1 text-sm text-muted">Cuando un negocio aprobado publique productos, va a aparecer en esta lista y, si tiene coordenadas, en el mapa.</p>
              </div>
            ) : null}
            {suppliers.map((supplier) => {
              const located = points.some((point) => point.id === supplier.id);
              const active = selected === supplier.id;
              return (
                <article
                  key={supplier.id}
                  className={`flex flex-col gap-2 rounded-2xl bg-card p-4 shadow-card ${active ? "ring-2 ring-teal" : ""}`}
                >
                  <button
                    type="button"
                    disabled={!located}
                    onClick={() => setSelected(supplier.id)}
                    className="flex items-start gap-3 text-left disabled:cursor-default"
                  >
                    <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-teal/10 text-olive">
                      <Store className="size-5" aria-hidden />
                    </span>
                    <span>
                      <span className="block font-semibold">{supplier.name}</span>
                      <span className="mt-1 block text-sm text-muted">
                        {supplier.neighborhood ? supplier.neighborhood : null}
                        {supplier.neighborhood && supplier.distanceKm !== null ? " · " : ""}
                        {supplier.distanceKm !== null ? `${supplier.distanceKm} km` : ""}
                        {!located ? `${supplier.neighborhood || supplier.distanceKm !== null ? " · " : ""}sin ubicación en el mapa` : ""}
                      </span>
                      <span className="mt-1 block text-sm">
                        {supplier.count} {supplier.count === 1 ? "publicación" : "publicaciones"}
                        {supplier.verified ? " · verificado" : ""}
                      </span>
                    </span>
                  </button>
                  <Link
                    to="/negocio/$businessId"
                    params={{ businessId: supplier.id }}
                    className="inline-flex min-h-11 items-center self-start rounded-full bg-paper px-4 text-sm font-semibold"
                  >
                    Ver proveedor
                  </Link>
                </article>
              );
            })}
          </div>
          <MarketMap
            points={points}
            selectedId={selected}
            onSelect={setSelected}
            popup
            detailPlace={placeLabel}
            emptyNote={
              loading
                ? null
                : suppliers.length === 0
                  ? "Todavía no hay proveedores para marcar."
                  : points.length === 0
                    ? "Estos proveedores todavía no tienen una ubicación válida."
                    : null
            }
          />
        </div>
      </section>
    </Shell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-card px-2 py-3 text-center">
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="mt-1 font-display text-lg font-semibold tabular-nums">{value}</dd>
    </div>
  );
}

function ProductCard({ listing }: { listing: ListingHit }) {
  const Icon = categoryIcon(listing.categorySlug);
  return (
    <article className="flex flex-col overflow-hidden rounded-2xl bg-card shadow-card">
      <Link to="/producto/$productId" params={{ productId: listing.id }} className="relative block aspect-square bg-paper">
        {listing.imageUrl ? (
          <img
            src={listing.imageUrl}
            alt=""
            className="h-full w-full object-cover outline outline-1 -outline-offset-1 outline-black/10"
          />
        ) : (
          <span className="grid h-full place-items-center text-olive">
            <Icon className="size-10" aria-hidden />
          </span>
        )}
      </Link>
      <div className="flex flex-1 flex-col gap-1 p-3">
        <p className="truncate text-xs text-muted">{listing.brand || listing.categoryName}</p>
        <h3 className="line-clamp-2 text-sm font-semibold">
          <Link to="/producto/$productId" params={{ productId: listing.id }}>
            {listing.name}
          </Link>
        </h3>
        <p className="mt-1 font-display text-xl leading-none font-semibold tabular-nums">{formatArs(listing.priceCents)}</p>
        <p className="text-xs text-muted">/ {listing.unit}</p>
        <p className="mt-1 truncate text-sm">{listing.businessName}</p>
        <p className="truncate text-xs text-muted">
          {listing.neighborhood ?? "Rosario"}
          {listing.distanceKm !== null ? ` · ${listing.distanceKm} km` : ""}
        </p>
        <div className="mt-2 flex flex-wrap gap-1">
          {listing.delivery ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-sun px-2 py-1 text-xs font-medium text-ink">
              <Truck className="size-3" aria-hidden />
              Entrega
            </span>
          ) : null}
          {listing.pickup ? (
            <span className="rounded-full bg-paper px-2 py-1 text-xs font-medium">Retiro</span>
          ) : null}
          {listing.verified ? (
            <span className="inline-flex items-center gap-1 rounded-full bg-teal/15 px-2 py-1 text-xs font-medium text-olive">
              <BadgeCheck className="size-3" aria-hidden />
              Verificado
            </span>
          ) : null}
        </div>
        <Link
          to="/producto/$productId"
          params={{ productId: listing.id }}
          className="mt-3 inline-flex min-h-11 items-center justify-center rounded-full bg-ember text-sm font-semibold text-ink"
        >
          Ver producto
        </Link>
      </div>
    </article>
  );
}
