import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/cerca/shell";
import { formatArs } from "@/lib/cerca/domain/money";
import { getBusiness } from "@/lib/cerca/server/public";
import { MarketMap } from "@/components/cerca/market-map";

export const Route = createFileRoute("/negocio/$businessId")({ component: BusinessPage });

function BusinessPage() {
  const { businessId } = Route.useParams();
  const [business, setBusiness] = useState<Awaited<ReturnType<typeof getBusiness>> | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    void getBusiness({ data: businessId })
      .then(setBusiness)
      .catch((cause: unknown) => setError(cause instanceof Error ? cause.message : "No se encontró."));
  }, [businessId]);

  return (
    <Shell>
      {error ? <p>{error}</p> : null}
      {business ? (
        <div className="grid gap-4 md:grid-cols-[1fr_18rem]">
          <article>
            <p className="text-sm text-muted">{business.neighborhood} · {business.city}{business.isDemo ? " · ejemplo de desarrollo" : ""}</p>
            <h1 className="text-4xl">{business.tradeName}</h1>
            <p className="mt-2 text-muted">{business.description || business.legalName}</p>
            <p className="mt-2 text-sm">{business.verified ? "Verificado por la plataforma" : "Todavía no verificado"}</p>
            <ul className="mt-4 grid gap-2">
              {business.listings.map((listing) => (
                <li key={listing.id} className="flex justify-between rounded-2xl border border-line px-3 py-2">
                  <Link to="/producto/$productId" params={{ productId: listing.id }}>{listing.name}{listing.brand ? ` · ${listing.brand}` : ""}</Link>
                  <span className="tabular-nums">{formatArs(listing.priceCents)} / {listing.unit}</span>
                </li>
              ))}
            </ul>
          </article>
          {business.lat !== null && business.lng !== null ? (
            <div className="overflow-hidden rounded-card border border-line">
              <MarketMap
                points={[{ id: business.id, lat: business.lat, lng: business.lng, label: business.tradeName }]}
                selectedId={business.id}
                onSelect={() => undefined}
              />
            </div>
          ) : null}
        </div>
      ) : null}
    </Shell>
  );
}
