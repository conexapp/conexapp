import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/cerca/shell";
import { CategoryCard } from "@/components/cerca/category-visual";
import { searchMarketplace, type SearchResult } from "@/lib/cerca/server/public";

export const Route = createFileRoute("/categorias")({ component: CategoriesPage });

type Category = SearchResult["categories"][number];

function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    void searchMarketplace({ data: {} })
      .then((result) => setCategories(result.categories))
      .finally(() => setReady(true));
  }, []);

  const roots = categories.filter((category) => category.parentId === null);
  const children = (parentId: string) => categories.filter((category) => category.parentId === parentId);

  return (
    <Shell>
      <h1 className="text-4xl">Todas las categorías</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted">
        El catálogo sale de la base. Una categoría sin publicaciones no inventa productos.
      </p>
      {!ready ? <div className="mt-6 h-40 rounded-2xl bg-card shadow-card" /> : null}
      {ready && roots.length === 0 ? (
        <p className="mt-6 rounded-2xl bg-card p-4 text-sm shadow-card">Todavía no hay categorías activas.</p>
      ) : null}
      <div className="mt-6 grid gap-6">
        {roots.map((root) => {
          const nested = children(root.id);
          return (
            <section key={root.id}>
              <div className="grid gap-3 sm:grid-cols-[12rem_1fr] sm:items-start">
                <CategoryCard slug={root.slug} name={root.name} icon={root.icon} />
                <div>
                  <p className="text-sm text-muted">
                    {nested.length > 0 ? `${nested.length} subcategorías` : "Sin subcategorías"}
                  </p>
                  <Link
                    to="/"
                    search={{ categoria: root.slug }}
                    hash="productos"
                    className="mt-2 inline-flex min-h-11 items-center text-sm font-semibold text-olive"
                  >
                    Ver publicaciones
                  </Link>
                  {nested.length > 0 ? (
                    <ul className="mt-3 flex flex-wrap gap-2">
                      {nested.map((child) => (
                        <li key={child.id}>
                          <Link
                            to="/"
                            search={{ categoria: child.slug }}
                            hash="productos"
                            className="inline-flex min-h-11 items-center rounded-full bg-card px-3 text-sm shadow-card"
                          >
                            {child.name}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  ) : null}
                </div>
              </div>
            </section>
          );
        })}
      </div>
    </Shell>
  );
}
