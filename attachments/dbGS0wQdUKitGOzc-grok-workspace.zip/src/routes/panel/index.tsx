import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/cerca/shell";
import { parseArsToCents } from "@/lib/cerca/domain/money";
import { ROSARIO } from "@/lib/cerca/domain/geo";
import { createBusiness, getMyAccount, setBusinessLocation } from "@/lib/cerca/server/account";
import { setBusinessCategories } from "@/lib/cerca/server/seller-categories";
import { SellerCategoryPicker } from "@/components/cerca/seller-category-picker";
import { disconnectSellerPayments, listSellerPaymentLinks, startSellerOAuth } from "@/lib/cerca/server/payments";
import { listQuoteInbox, submitQuote } from "@/lib/cerca/server/trade";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { toast } from "sonner";

export const Route = createFileRoute("/panel/")({ component: PanelPage });

function PanelPage() {
  const { user, isPending } = useCurrentUserState();
  const [account, setAccount] = useState<Awaited<ReturnType<typeof getMyAccount>> | null>(null);
  const [inbox, setInbox] = useState<Awaited<ReturnType<typeof listQuoteInbox>>>([]);
  const [payments, setPayments] = useState<Awaited<ReturnType<typeof listSellerPaymentLinks>> | null>(null);
  const [tradeName, setTradeName] = useState("");
  const [legalName, setLegalName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [neighborhood, setNeighborhood] = useState("");
  const [categoryIds, setCategoryIds] = useState<string[]>([]);
  const [editIds, setEditIds] = useState<string[]>([]);
  const [businessId, setBusinessId] = useState("");
  const [lat, setLat] = useState(String(ROSARIO.lat));
  const [lng, setLng] = useState(String(ROSARIO.lng));

  function reload() {
    void getMyAccount().then((next) => {
      setAccount(next);
      if (!businessId && next.businesses[0]) setBusinessId(next.businesses[0].id);
    });
    void listQuoteInbox().then(setInbox).catch(() => setInbox([]));
    void listSellerPaymentLinks().then(setPayments).catch(() => setPayments(null));
  }

  useEffect(() => {
    const current = account?.businesses.find((business) => business.id === businessId);
    setEditIds(current?.categoryIds ?? []);
  }, [account, businessId]);

  useEffect(() => {
    if (user) reload();
  }, [user]);

  if (!isPending && !user) return <RedirectToSignIn />;

  return (
    <Shell>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-4xl">Tu negocio</h1>
          <p className="mt-2 max-w-2xl text-sm text-muted">
            Cerca no carga productos. Los publica cada proveedor, después de que el negocio esté aprobado.
          </p>
        </div>
        <Link to="/panel/productos" className="inline-flex min-h-11 items-center rounded-full bg-copper px-4 text-ink">
          Mis productos
        </Link>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <form
          className="grid gap-2 rounded-card border border-line bg-foam p-4"
          onSubmit={(event) => {
            event.preventDefault();
            void createBusiness({ data: { tradeName, legalName, phone, address, neighborhood, categoryIds } })
              .then((created) => {
                toast.success("Negocio enviado a revisión.");
                setBusinessId(created.id);
                reload();
              })
              .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se creó."));
          }}
        >
          <h2 className="text-2xl">Alta</h2>
          <input required value={tradeName} onChange={(event) => setTradeName(event.target.value)} placeholder="Nombre comercial" className="min-h-11 rounded-2xl border border-line px-3" />
          <input required value={legalName} onChange={(event) => setLegalName(event.target.value)} placeholder="Razón social" className="min-h-11 rounded-2xl border border-line px-3" />
          <input required value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="Teléfono" className="min-h-11 rounded-2xl border border-line px-3" />
          <input required value={address} onChange={(event) => setAddress(event.target.value)} placeholder="Dirección" className="min-h-11 rounded-2xl border border-line px-3" />
          <input required value={neighborhood} onChange={(event) => setNeighborhood(event.target.value)} placeholder="Barrio" className="min-h-11 rounded-2xl border border-line px-3" />
          <SellerCategoryPicker selected={categoryIds} onChange={setCategoryIds} />
          <button disabled={categoryIds.length === 0} className="min-h-11 rounded-full bg-ember text-ink disabled:opacity-40">
            {categoryIds.length === 0 ? "Continuar" : "Continuar →"}
          </button>
          <ul className="text-sm text-muted">
            {account?.businesses.map((business) => (
              <li key={business.id}>{business.trade_name} — {business.status}</li>
            ))}
          </ul>
        </form>

        <form
          className="grid gap-2 rounded-card border border-line bg-foam p-4"
          onSubmit={(event) => {
            event.preventDefault();
            void setBusinessLocation({
              data: { businessId, lat: Number(lat), lng: Number(lng), delivery: true, pickup: true },
            })
              .then(() => toast.success("Ubicación guardada."))
              .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se guardó."));
          }}
        >
          <h2 className="text-2xl">Ubicación</h2>
          <select value={businessId} onChange={(event) => setBusinessId(event.target.value)} className="min-h-11 rounded-2xl border border-line px-3">
            {account?.businesses.map((business) => (
              <option key={business.id} value={business.id}>{business.trade_name}</option>
            ))}
          </select>
          <div className="grid grid-cols-2 gap-2">
            <input value={lat} onChange={(event) => setLat(event.target.value)} className="min-h-11 rounded-2xl border border-line px-3" />
            <input value={lng} onChange={(event) => setLng(event.target.value)} className="min-h-11 rounded-2xl border border-line px-3" />
          </div>
          <p className="text-xs text-muted">Latitud y longitud dentro de Rosario. El centro es {ROSARIO.lat}, {ROSARIO.lng}.</p>
          <button className="min-h-11 rounded-full bg-olive text-ink">Guardar punto</button>
        </form>
        {businessId ? (
          <section className="grid gap-3 rounded-card border border-line bg-foam p-4 lg:col-span-2">
            <SellerCategoryPicker
              selected={editIds}
              onChange={setEditIds}
              title="Categorías de este negocio"
              hint="Podés cambiarlas cuando quieras. No reemplazan la categoría de cada producto."
            />
            <button
              type="button"
              disabled={editIds.length === 0}
              className="min-h-11 rounded-full bg-ink px-4 text-paper disabled:opacity-40"
              onClick={() => {
                void setBusinessCategories({ data: { businessId, categoryIds: editIds } })
                  .then(() => {
                    toast.success("Categorías guardadas.");
                    reload();
                  })
                  .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se guardaron."));
              }}
            >
              Guardar categorías
            </button>
          </section>
        ) : null}
      </div>

      <section className="mt-8 grid gap-3 rounded-card border border-line bg-foam p-4">
        <h2 className="text-2xl">Mercado Pago</h2>
        <p className="text-sm text-muted">
          Cada negocio conecta su propia cuenta. Cerca no muestra el token. Sin esa conexión no se puede cobrar.
        </p>
        {payments?.missing.length ? (
          <p className="text-sm">No se puede conectar todavía. Falta: {payments.missing.join(", ")}.</p>
        ) : null}
        {payments?.warning ? <p className="text-sm text-muted">{payments.warning}</p> : null}
        <ul className="grid gap-2">
          {payments?.businesses.map((business) => (
            <li key={business.businessId} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-line px-3 py-2">
              <span>
                <span className="block font-medium">{business.tradeName}</span>
                <span className="text-sm text-muted">
                  {business.connected
                    ? `Conectado${business.liveMode === false ? " · modo de prueba" : ""}.`
                    : business.status === "refresh_failed"
                      ? "Hay que reconectar. El token no se pudo renovar."
                      : "Sin conectar."}
                </span>
              </span>
              {business.connected ? (
                <button
                  type="button"
                  className="min-h-11 rounded-full border border-line px-4"
                  onClick={() => {
                    void disconnectSellerPayments({ data: business.businessId })
                      .then((result) => {
                        toast.success(result.message);
                        reload();
                      })
                      .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se desconectó."));
                  }}
                >
                  Desconectar
                </button>
              ) : (
                <button
                  type="button"
                  className="min-h-11 rounded-full bg-ink px-4 text-paper"
                  onClick={() => {
                    void startSellerOAuth({ data: business.businessId })
                      .then((result) => {
                        if (result.url) {
                          window.location.href = result.url;
                          return;
                        }
                        const missing = result.missing.length ? ` Falta: ${result.missing.join(", ")}.` : "";
                        toast.message(`${result.message}${missing}`);
                      })
                      .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se abrió Mercado Pago."));
                  }}
                >
                  Conectar Mercado Pago
                </button>
              )}
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-8 grid gap-3">
        <h2 className="text-2xl">Solicitudes de tus publicaciones</h2>
        {inbox.length === 0 ? <p className="text-sm text-muted">No hay solicitudes abiertas para productos publicados.</p> : null}
        {inbox.map((request) => (
          <QuoteReply key={request.id} request={request} onDone={reload} />
        ))}
      </section>
    </Shell>
  );
}

function QuoteReply({
  request,
  onDone,
}: {
  request: Awaited<ReturnType<typeof listQuoteInbox>>[number];
  onDone: () => void;
}) {
  const [price, setPrice] = useState("");
  const [shipping, setShipping] = useState("0");
  const [hours, setHours] = useState(48);
  const [notes, setNotes] = useState("");
  return (
    <form
      className="grid gap-2 rounded-card border border-line bg-foam p-4"
      onSubmit={(event) => {
        event.preventDefault();
        const unitPriceCents = parseArsToCents(price);
        const shippingCents = parseArsToCents(shipping) ?? (shipping === "0" ? 0 : null);
        if (!unitPriceCents || shippingCents === null) {
          toast.error("Revisá los importes.");
          return;
        }
        void submitQuote({
          data: {
            requestId: request.id,
            businessId: request.business_id,
            unitPriceCents,
            quantity: request.quantity,
            shippingCents,
            leadTimeHours: hours,
            notes,
          },
        })
          .then(() => {
            toast.success("Cotización enviada.");
            onDone();
          })
          .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se envió."));
      }}
    >
      <h3 className="text-xl">{request.title}</h3>
      <p className="text-sm text-muted">Cantidad pedida: {request.quantity}. {request.notes}</p>
      <input value={price} onChange={(event) => setPrice(event.target.value)} placeholder="Precio unitario" className="min-h-11 rounded-2xl border border-line px-3" />
      <input value={shipping} onChange={(event) => setShipping(event.target.value)} placeholder="Envío (0 si no cobra)" className="min-h-11 rounded-2xl border border-line px-3" />
      <input type="number" value={hours} onChange={(event) => setHours(Number(event.target.value))} className="min-h-11 rounded-2xl border border-line px-3" />
      <input value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="Condiciones" className="min-h-11 rounded-2xl border border-line px-3" />
      <button className="min-h-11 rounded-full bg-copper text-ink">Enviar cotización</button>
    </form>
  );
}
