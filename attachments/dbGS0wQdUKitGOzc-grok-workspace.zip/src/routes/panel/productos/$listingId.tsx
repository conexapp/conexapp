import { useEffect, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Shell } from "@/components/cerca/shell";
import { formatArs, parseArsToCents } from "@/lib/cerca/domain/money";
import { getMyAccount } from "@/lib/cerca/server/account";
import {
  confirmListingImage,
  createListing,
  deleteListingImage,
  getMyListing,
  listListingOptions,
  moveListingImage,
  prepareListingImage,
  publishListing,
  removeListing,
  saveListingImage,
  setListingStatus,
  setPrimaryImage,
  updateListing,
} from "@/lib/cerca/server/listings";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { toast } from "sonner";

export const Route = createFileRoute("/panel/productos/$listingId")({ component: EditorPage });

type Options = Awaited<ReturnType<typeof listListingOptions>>;

function EditorPage() {
  const { listingId } = Route.useParams();
  const creating = listingId === "nuevo";
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [options, setOptions] = useState<Options | null>(null);
  const [businessId, setBusinessId] = useState("");
  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [sku, setSku] = useState("");
  const [description, setDescription] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [standardProductId, setStandardProductId] = useState("");
  const [price, setPrice] = useState("");
  const [unit, setUnit] = useState("unidad");
  const [stock, setStock] = useState(0);
  const [minStock, setMinStock] = useState(0);
  const [pickup, setPickup] = useState(true);
  const [delivery, setDelivery] = useState(false);
  const [shipping, setShipping] = useState("0");
  const [hours, setHours] = useState(48);
  const [status, setStatus] = useState("draft");
  const [images, setImages] = useState<Awaited<ReturnType<typeof getMyListing>>["images"]>([]);

  function payload(priceCents: number, shippingCents: number) {
    return {
      businessId,
      name,
      description,
      brand,
      model,
      sku,
      categoryId,
      standardProductId: standardProductId || null,
      priceCents,
      unit,
      referenceUnit: "",
      referencePriceCents: null,
      stockUnits: stock,
      minStock,
      pickup,
      delivery,
      shippingCents,
      leadTimeHours: hours,
    };
  }

  async function reload(id = listingId) {
    if (id === "nuevo") return;
    const listing = await getMyListing({ data: id });
    setBusinessId(listing.business_id);
    setName(listing.name);
    setBrand(listing.brand);
    setModel(listing.model);
    setSku(listing.sku);
    setDescription(listing.description);
    setCategoryId(listing.category_id);
    setStandardProductId(listing.standard_product_id ?? "");
    setPrice(centsToInput(listing.priceCents));
    setUnit(listing.unit);
    setStock(listing.stock_units);
    setMinStock(listing.min_stock);
    setPickup(listing.pickup);
    setDelivery(listing.delivery);
    setShipping(centsToInput(listing.shippingCents));
    setHours(listing.lead_time_hours ?? 48);
    setStatus(listing.status);
    setImages(listing.images);
  }

  useEffect(() => {
    if (!user) return;
    void listListingOptions().then(setOptions);
    void getMyAccount().then((account) => {
      if (creating && account.businesses[0]) setBusinessId(account.businesses[0].id);
    });
    if (!creating) {
      void reload().catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se pudo abrir."));
    }
  }, [user, listingId]);

  if (!isPending && !user) return <RedirectToSignIn />;

  async function save(publish: boolean) {
    const priceCents = parseArsToCents(price);
    const shippingCents = parseArsToCents(shipping) ?? (shipping.trim() === "0" ? 0 : null);
    if (!priceCents || shippingCents === null) {
      toast.error("Revisá precio y envío.");
      return;
    }
    const body = payload(priceCents, shippingCents);
    try {
      if (creating) {
        const created = await createListing({ data: body });
        toast.success("Borrador guardado. Ahora podés subir las fotos.");
        await navigate({ to: "/panel/productos/$listingId", params: { listingId: created.id } });
        return;
      }
      const updated = await updateListing({ data: { listingId, ...body } });
      setStatus(updated.status);
      if (publish) {
        const published = await publishListing({ data: listingId });
        setStatus(published.status);
        toast.success("Producto publicado.");
      } else {
        toast.success("Cambios guardados. Los pedidos anteriores no cambian.");
      }
      await reload();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "No se guardó.");
    }
  }

  async function upload(file: File) {
    if (creating) {
      toast.error("Guardá el borrador antes de subir fotos.");
      return;
    }
    const prepared = await prepareListingImage({
      data: { listingId, contentType: file.type || "application/octet-stream", byteSize: file.size },
    });
    if (prepared.mode === "direct") {
      const base64 = await fileToBase64(file);
      await saveListingImage({ data: { imageId: prepared.imageId, base64 } });
    } else {
      const response = await fetch(prepared.uploadUrl, {
        method: "PUT",
        headers: prepared.headers,
        body: file,
      });
      if (!response.ok) throw new Error("El almacenamiento rechazó la imagen.");
      await confirmListingImage({ data: prepared.imageId });
    }
    await reload();
  }

  return (
    <Shell>
      <p className="text-sm text-muted">{creating ? "Nuevo borrador" : `Estado: ${status}`}</p>
      <h1 className="mb-4 text-4xl">{creating ? "Agregar producto" : name || "Editar producto"}</h1>
      <form
        className="grid gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          void save(false);
        }}
      >
        <BusinessSelect businessId={businessId} onChange={setBusinessId} disabled={!creating} />
        <input required value={name} onChange={(event) => setName(event.target.value)} placeholder="Nombre del producto" className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
        <div className="grid gap-2 sm:grid-cols-3">
          <input value={brand} onChange={(event) => setBrand(event.target.value)} placeholder="Marca" className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
          <input value={model} onChange={(event) => setModel(event.target.value)} placeholder="Modelo" className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
          <input value={sku} onChange={(event) => setSku(event.target.value)} placeholder="SKU / código interno" className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
        </div>
        <textarea value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Descripción" className="min-h-28 rounded-2xl border border-line bg-foam px-3 py-2" />
        <select required value={categoryId} onChange={(event) => setCategoryId(event.target.value)} className="min-h-11 rounded-2xl border border-line bg-foam px-3">
          <option value="">Categoría</option>
          {options?.categories.map((category) => (
            <option key={category.id} value={category.id}>{category.parent_name} → {category.name}</option>
          ))}
        </select>
        <select value={standardProductId} onChange={(event) => setStandardProductId(event.target.value)} className="min-h-11 rounded-2xl border border-line bg-foam px-3">
          <option value="">Sin ancla de comparación</option>
          {options?.standards.map((standard) => (
            <option key={standard.id} value={standard.id}>{standard.name} ({standard.unit}) — no es tu producto</option>
          ))}
        </select>
        <div className="grid gap-2 sm:grid-cols-2">
          <input required value={price} onChange={(event) => setPrice(event.target.value)} placeholder="Precio, por ejemplo 10500" className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
          <input required value={unit} onChange={(event) => setUnit(event.target.value)} placeholder="Unidad: bolsa, m3, unidad" className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
          <input type="number" min={0} value={stock} onChange={(event) => setStock(Number(event.target.value))} className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
          <input type="number" min={0} value={minStock} onChange={(event) => setMinStock(Number(event.target.value))} placeholder="Stock mínimo" className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
        </div>
        <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={pickup} onChange={(event) => setPickup(event.target.checked)} />Retiro en el local</label>
        <label className="flex min-h-11 items-center gap-2 text-sm"><input type="checkbox" checked={delivery} onChange={(event) => setDelivery(event.target.checked)} />Envío</label>
        <input value={shipping} onChange={(event) => setShipping(event.target.value)} placeholder="Costo de envío" className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
        <input type="number" min={0} value={hours} onChange={(event) => setHours(Number(event.target.value))} className="min-h-11 rounded-2xl border border-line bg-foam px-3" />
        <p className="text-xs text-muted">
          Almacenamiento: {options?.storage === "r2" ? "Cloudflare R2" : options?.storage === "local" ? "disco local de desarrollo" : "no configurado"}.
          JPEG, PNG o WebP, hasta 4 MB y 8 fotos.
        </p>
        <div className="flex flex-wrap gap-2">
          <button className="min-h-11 rounded-full bg-ink px-4 text-paper">Guardar borrador</button>
          {!creating ? (
            <button type="button" className="min-h-11 rounded-full bg-copper px-4 text-ink" onClick={() => void save(true)}>Publicar</button>
          ) : null}
        </div>
      </form>

      {!creating ? (
        <section className="mt-6 grid gap-3">
          <h2 className="text-2xl">Imágenes</h2>
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="text-sm"
            onChange={(event) => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (!file) return;
              void upload(file).catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se subió."));
            }}
          />
          <ul className="grid gap-2">
            {images.map((image) => (
              <li key={image.id} className="flex flex-wrap items-center gap-2 rounded-2xl border border-line p-2">
                {image.url ? <img src={image.url} alt="" className="h-16 w-16 rounded-xl object-cover" /> : <span className="text-sm">Pendiente</span>}
                <span className="text-sm">{image.isPrimary ? "Principal" : image.status}</span>
                {image.status === "ready" ? (
                  <button type="button" className="min-h-10 rounded-full border border-line px-3" onClick={() => void setPrimaryImage({ data: image.id }).then(() => reload())}>Principal</button>
                ) : null}
                <button type="button" className="min-h-10 rounded-full border border-line px-3" onClick={() => void moveListingImage({ data: { imageId: image.id, direction: "up" } }).then(() => reload())}>Subir</button>
                <button type="button" className="min-h-10 rounded-full border border-line px-3" onClick={() => void moveListingImage({ data: { imageId: image.id, direction: "down" } }).then(() => reload())}>Bajar</button>
                <button type="button" className="min-h-10 rounded-full border border-line px-3" onClick={() => void deleteListingImage({ data: image.id }).then(() => reload()).catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se borró."))}>Quitar</button>
              </li>
            ))}
          </ul>
          <div className="flex flex-wrap gap-2">
            {status === "published" || status === "out_of_stock" ? (
              <button type="button" className="min-h-11 rounded-full border border-ink px-4" onClick={() => void setListingStatus({ data: { listingId, action: "pause" } }).then(() => reload())}>Pausar</button>
            ) : null}
            {status === "paused" ? (
              <button type="button" className="min-h-11 rounded-full bg-olive px-4 text-ink" onClick={() => void setListingStatus({ data: { listingId, action: "reactivate" } }).then(() => reload()).catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se reactivó."))}>Reactivar</button>
            ) : null}
            <button
              type="button"
              className="min-h-11 rounded-full border border-line px-4"
              onClick={() => {
                void removeListing({ data: listingId })
                  .then(async (result) => {
                    toast.message(result.message);
                    if (result.deleted) await navigate({ to: "/panel/productos" });
                    else await reload();
                  })
                  .catch((error: unknown) => toast.error(error instanceof Error ? error.message : "No se eliminó."));
              }}
            >
              Eliminar
            </button>
          </div>
          {price ? <p className="text-sm text-muted">Precio actual de la publicación: {formatArs(parseArsToCents(price) ?? 0)}. Un pedido ya creado conserva el precio del momento de la compra.</p> : null}
        </section>
      ) : null}
    </Shell>
  );
}

function BusinessSelect({
  businessId,
  onChange,
  disabled,
}: {
  businessId: string;
  onChange: (value: string) => void;
  disabled: boolean;
}) {
  const [businesses, setBusinesses] = useState<Array<{ id: string; trade_name: string; status: string }>>([]);
  useEffect(() => {
    void getMyAccount().then((account) => setBusinesses(account.businesses));
  }, []);
  return (
    <select required value={businessId} onChange={(event) => onChange(event.target.value)} className="min-h-11 rounded-2xl border border-line bg-foam px-3" disabled={disabled}>
      <option value="">Elegí el negocio</option>
      {businesses.map((business) => (
        <option key={business.id} value={business.id}>{business.trade_name} ({business.status})</option>
      ))}
    </select>
  );
}

function centsToInput(cents: number): string {
  const whole = Math.trunc(cents / 100);
  const frac = Math.abs(cents % 100);
  if (frac === 0) return String(whole);
  return `${whole},${String(frac).padStart(2, "0")}`;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("No se pudo leer la imagen."));
    reader.onload = () => {
      const value = String(reader.result ?? "");
      const encoded = value.split(",")[1];
      if (!encoded) reject(new Error("No se pudo leer la imagen."));
      else resolve(encoded);
    };
    reader.readAsDataURL(file);
  });
}
